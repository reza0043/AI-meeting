import React, { useState, useEffect, useRef, useMemo } from "react";
import { Header } from "./components/Header";
import { SidebarControls } from "./components/SidebarControls";
import { ImageCropperCanvas } from "./components/ImageCropperCanvas";
import { ComparativeChart } from "./components/ComparativeChart";
import { ResultsTable } from "./components/ResultsTable";
import { PatternExtremaTargetsPanel } from "./components/PatternExtremaTargetsPanel";
import { SettingsModal } from "./components/SettingsModal";
import { CandleChartModal } from "./components/CandleChartModal";
import { MyDNAModal } from "./components/MyDNAModal";

import {
  MarketDataset,
  MatchResult,
  SearchConfig,
  MyDNAPattern,
  TrendBreakdown,
  CustomPatternMatch,
} from "./engine/types";
import { PRESET_PATTERNS, TALIB_STANDARD_PATTERNS, convertTALibToMyDNA } from "./engine/presetPatterns";
import { PatternMatcher } from "./engine/matcher";
import {
  extractPatternExtrema,
  calculateForwardScenarios,
  PatternExtremaAnalysis,
  ForwardScenarioAnalysis,
} from "./engine/patternExtrema";
import { PriceScaleCalibration } from "./engine/priceScaleDetector";
import { CropRect } from "./components/ImageCropperCanvas";
import { LanguageCode, getTranslation } from "./i18n/languages";
import { ThemeId, getTheme, applyThemeVariables } from "./theme/themes";
import { FontId, loadSavedFont, saveFont, applyFontToDocument } from "./theme/fonts";
import {
  loadDatasetsFromStorage,
  saveDatasetsToStorage,
  loadSelectedDatasetIdsFromStorage,
  saveSelectedDatasetIdsToStorage,
} from "./engine/datasetStorage";

const DEFAULT_CONFIG: SearchConfig = {
  threshold: 75,
  patternLength: 60,
  extractorPointCount: 500,
  futureCandles: 70,
  beforeCandles: 40,
  topResults: 50,
  rangeTolerance: 1.0,
  skipOverlap: true,
  weights: {
    pearson: 0.4,
    dtw: 0.3,
    slope: 0.15,
    structural: 0.15,
  },
};

export const App: React.FC = () => {
  // 1. Language State & Persistence (Default to Persian 'fa' as user's native language)
  const [activeLanguage, setActiveLanguage] = useState<LanguageCode>(() => {
    try {
      const saved = localStorage.getItem("chartdna_language");
      if (saved && ["en", "fa", "ar", "es", "fr", "de", "ru", "zh", "tr", "ja"].includes(saved)) {
        return saved as LanguageCode;
      }
    } catch (e) {}
    return "fa";
  });

  // 2. Theme State & Persistence (10 distinct themes)
  const [activeTheme, setActiveTheme] = useState<ThemeId>(() => {
    try {
      const saved = localStorage.getItem("chartdna_theme");
      if (saved) {
        return saved as ThemeId;
      }
    } catch (e) {}
    return "cyber-obsidian";
  });

  // 3. Font Typography State & Persistence (Persian & Coding fonts)
  const [activeFont, setActiveFont] = useState<FontId>(() => loadSavedFont());

  // Save Language to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem("chartdna_language", activeLanguage);
    } catch (e) {}
    const dir = activeLanguage === "fa" || activeLanguage === "ar" ? "rtl" : "ltr";
    document.documentElement.dir = dir;
    document.documentElement.lang = activeLanguage;
  }, [activeLanguage]);

  // Save Theme to LocalStorage & HTML data attribute & CSS variables
  useEffect(() => {
    try {
      localStorage.setItem("chartdna_theme", activeTheme);
    } catch (e) {}
    document.documentElement.setAttribute("data-theme", activeTheme);
    const currentDef = getTheme(activeTheme);
    applyThemeVariables(currentDef);
  }, [activeTheme]);

  // Save & Apply Font Family
  useEffect(() => {
    saveFont(activeFont);
    applyFontToDocument(activeFont);
  }, [activeFont]);

  // Datasets (Loaded from IndexedDB storage asynchronously)
  const [datasets, setDatasets] = useState<MarketDataset[]>([]);
  const [selectedDatasetIds, setSelectedDatasetIds] = useState<string[]>([]);
  const isInitialLoadDone = useRef(false);

  // Load initial datasets from IndexedDB
  useEffect(() => {
    let isMounted = true;
    loadDatasetsFromStorage().then((loadedDatasets) => {
      if (!isMounted) return;
      setDatasets(loadedDatasets);

      const savedSelectedIds = loadSelectedDatasetIdsFromStorage();
      if (savedSelectedIds && savedSelectedIds.length > 0) {
        // Only keep IDs that exist in loaded datasets
        const validIds = savedSelectedIds.filter((id) =>
          loadedDatasets.some((d) => d.id === id)
        );
        setSelectedDatasetIds(validIds.length > 0 ? validIds : loadedDatasets.map((d) => d.id));
      } else {
        setSelectedDatasetIds(loadedDatasets.map((d) => d.id));
      }
      isInitialLoadDone.current = true;
    });

    return () => {
      isMounted = false;
    };
  }, []);

  // Save Datasets & Selected IDs to IndexedDB storage
  useEffect(() => {
    if (!isInitialLoadDone.current) return;
    saveDatasetsToStorage(datasets).catch((err) => {
      console.warn("Could not save datasets:", err);
    });
  }, [datasets]);

  useEffect(() => {
    if (!isInitialLoadDone.current) return;
    saveSelectedDatasetIdsToStorage(selectedDatasetIds);
  }, [selectedDatasetIds]);

  // Engine Configuration (Persistent) with robust merging
  const [config, setConfig] = useState<SearchConfig>(() => {
    try {
      const fromStorage = localStorage.getItem("chartdna_config");
      if (fromStorage) {
        const parsed = JSON.parse(fromStorage);
        return {
          ...DEFAULT_CONFIG,
          ...parsed,
          weights: {
            ...DEFAULT_CONFIG.weights,
            ...(parsed?.weights || {}),
          },
        };
      }
    } catch (e) {}
    return DEFAULT_CONFIG;
  });

  useEffect(() => {
    try {
      localStorage.setItem("chartdna_config", JSON.stringify(config));
    } catch (e) {}
  }, [config]);

  // Active Reference Pattern (80 normalized values)
  const [referencePattern, setReferencePattern] = useState<number[] | null>(null);
  const [referenceRelativeCoords, setReferenceRelativeCoords] = useState<{ relX: number; relY: number }[] | null>(null);
  const [referencePatternName, setReferencePatternName] = useState<string>("");

  // Chart Image Source
  const [imageSrc, setImageSrc] = useState<string | null>(null);

  // Saved My DNA Patterns Library (Persistent)
  const [savedPatterns, setSavedPatterns] = useState<MyDNAPattern[]>(() => {
    try {
      const fromStorage = localStorage.getItem("chartdna_saved_patterns");
      if (fromStorage) {
        const parsed = JSON.parse(fromStorage);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {}
    // Initial library from presets
    return PRESET_PATTERNS.map((p) => ({
      id: p.id,
      name: p.name,
      category: p.category,
      createdAt: "2024-01-01",
      points: p.points,
      normalizedPoints: p.points,
      notes: p.description,
    }));
  });

  // Save Patterns to LocalStorage safely
  useEffect(() => {
    try {
      localStorage.setItem("chartdna_saved_patterns", JSON.stringify(savedPatterns));
    } catch (e) {}
  }, [savedPatterns]);

  // Search and Matching Results State
  const [includeCustomPatternsInSearch, setIncludeCustomPatternsInSearch] = useState<boolean>(() => {
    try {
      const fromStorage = localStorage.getItem("chartdna_include_custom_patterns");
      if (fromStorage !== null) {
        return JSON.parse(fromStorage);
      }
    } catch (e) {}
    return true;
  });

  useEffect(() => {
    try {
      localStorage.setItem("chartdna_include_custom_patterns", JSON.stringify(includeCustomPatternsInSearch));
    } catch (e) {}
  }, [includeCustomPatternsInSearch]);

  // Standard TA-Lib Trading Library Search State
  const [includeTALibPatternsInSearch, setIncludeTALibPatternsInSearch] = useState<boolean>(() => {
    try {
      const fromStorage = localStorage.getItem("chartdna_include_talib_patterns");
      if (fromStorage !== null) {
        return JSON.parse(fromStorage);
      }
    } catch (e) {}
    return true;
  });

  useEffect(() => {
    try {
      localStorage.setItem("chartdna_include_talib_patterns", JSON.stringify(includeTALibPatternsInSearch));
    } catch (e) {}
  }, [includeTALibPatternsInSearch]);

  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [progressPercent, setProgressPercent] = useState<number>(0);
  const [results, setResults] = useState<MatchResult[]>([]);
  const [customMatches, setCustomMatches] = useState<CustomPatternMatch[]>([]);
  const [selectedMatchIndex, setSelectedMatchIndex] = useState<number | null>(null);
  const [trendBreakdown, setTrendBreakdown] = useState<TrendBreakdown | null>(null);

  // Dynamically re-classify existing search results if rangeTolerance changes
  useEffect(() => {
    if (results.length > 0) {
      const tol = config.rangeTolerance ?? 1.0;
      let hasChange = false;
      const updated = results.map((m) => {
        const newTrend = PatternMatcher.classifyTrend(m.pattern, m.future, tol);
        if (newTrend !== m.trend) hasChange = true;
        return { ...m, trend: newTrend };
      });
      if (hasChange) {
        setResults(updated);
        setTrendBreakdown(PatternMatcher.computeTrendBreakdown(updated));
      }
    }
  }, [config.rangeTolerance]);
  const [priceCalibration, setPriceCalibration] = useState<PriceScaleCalibration | null>(null);
  const [cropBox, setCropBox] = useState<CropRect | null>(null);
  const [extractTriggerCounter, setExtractTriggerCounter] = useState<number>(0);
  const [priceScaleTriggerCounter, setPriceScaleTriggerCounter] = useState<number>(0);

  // Global Reference Price (Reference point for all patterns, calculations & future scenarios)
  const [referencePrice, setReferencePrice] = useState<number | null>(() => {
    try {
      const saved = localStorage.getItem("chartdna_reference_price");
      if (saved) {
        const parsed = parseFloat(saved);
        if (!isNaN(parsed) && parsed > 0) return parsed;
      }
    } catch (e) {}
    return null;
  });

  useEffect(() => {
    try {
      if (referencePrice != null && referencePrice > 0) {
        localStorage.setItem("chartdna_reference_price", String(referencePrice));
      } else {
        localStorage.removeItem("chartdna_reference_price");
      }
    } catch (e) {}
  }, [referencePrice]);

  // Extrema (Peaks & Valleys) extraction on reference pattern with real price calibration if present
  const patternExtrema = useMemo<PatternExtremaAnalysis | null>(() => {
    if (!referencePattern || referencePattern.length < 5) return null;
    return extractPatternExtrema(
      referencePattern,
      cropBox,
      priceCalibration,
      referenceRelativeCoords,
      referencePrice
    );
  }, [referencePattern, cropBox, priceCalibration, referenceRelativeCoords, referencePrice]);

  // Forward Scenarios & Probability Targets (Bullish, Bearish, Range)
  const forwardScenarios = useMemo<ForwardScenarioAnalysis | null>(() => {
    if (!referencePattern || !patternExtrema) return null;
    const futureCandlesList = results
      .map((r) => r.future)
      .filter((f): f is number[] => !!f && f.length > 0);
    return calculateForwardScenarios(referencePattern, futureCandlesList, patternExtrema, referencePrice);
  }, [referencePattern, results, patternExtrema, referencePrice]);

  // Cancellation token ref
  const shouldStopRef = useRef<boolean>(false);

  // Modals state
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [settingsTab, setSettingsTab] = useState<"themes" | "languages" | "algorithm" | "weights" | "data" | "patternExtractor">("themes");
  const [isMyDNAOpen, setIsMyDNAOpen] = useState(false);
  const [candleModalResult, setCandleModalResult] = useState<MatchResult | null>(null);

  // Calculate total candles across active datasets
  const activeDatasets = datasets.filter((d) => selectedDatasetIds.includes(d.id));
  const totalCandlesCount = activeDatasets.reduce((acc, d) => acc + d.candles.length, 0);
  const isCustomPatternsActive = includeCustomPatternsInSearch && savedPatterns.length > 0;
  const isTALibPatternsActive = includeTALibPatternsInSearch && TALIB_STANDARD_PATTERNS.length > 0;
  const hasSearchableTargets = activeDatasets.length > 0 || isCustomPatternsActive || isTALibPatternsActive;

  const currentTheme = getTheme(activeTheme);
  const isRtl = activeLanguage === "fa" || activeLanguage === "ar";

  // Core Search Engine Function
  const executeAnalysis = async (patternToSearch: number[], patternLabel?: string) => {
    if (!patternToSearch || patternToSearch.length < 5 || !hasSearchableTargets) return;

    setIsAnalyzing(true);
    setProgressPercent(0);
    shouldStopRef.current = false;
    setSelectedMatchIndex(null);

    try {
      let customAsMatchResults: MatchResult[] = [];
      let talibAsMatchResults: MatchResult[] = [];
      let foundCustomMatches: CustomPatternMatch[] = [];

      // 1. Search in user's saved DNA patterns library if enabled
      if (isCustomPatternsActive) {
        foundCustomMatches = PatternMatcher.findMatchesInCustomPatterns(
          patternToSearch,
          savedPatterns,
          config
        );
        setCustomMatches(foundCustomMatches);

        // Convert custom pattern matches to MatchResult format
        customAsMatchResults = foundCustomMatches.map((cm) => ({
          rank: 0,
          datasetId: `custom_dna_${cm.patternId}`,
          fileName: isRtl ? "کتابخانه الگوهای من" : "My DNA Library",
          symbol: `🖼️ ${cm.name}`,
          timeframe: cm.category || "DNA",
          startIndex: 0,
          endIndex: cm.points.length - 1,
          startTime: cm.createdAt || (isRtl ? "الگوی ثبت‌شده" : "Saved Pattern"),
          endTime: isRtl ? "کتابخانه تصویری" : "Image Library",
          similarity: cm.similarity,
          pattern: cm.points,
          future: cm.points.slice(-Math.min(cm.points.length, 15)),
          trend: cm.trend,
          rawMatchIndices: { start: 0, end: cm.points.length - 1 },
        }));
      } else {
        setCustomMatches([]);
      }

      // 2. Search in standard TA-Lib & Technical Pattern Library if enabled
      if (isTALibPatternsActive) {
        const talibDNAPatterns = TALIB_STANDARD_PATTERNS.map(convertTALibToMyDNA);
        const foundTALibMatches = PatternMatcher.findMatchesInCustomPatterns(
          patternToSearch,
          talibDNAPatterns,
          config
        );

        talibAsMatchResults = foundTALibMatches.map((tm) => ({
          rank: 0,
          datasetId: `talib_${tm.patternId}`,
          fileName: isRtl ? "کتابخانه استاندارد TA-Lib" : "TA-Lib Standard Library",
          symbol: `📚 ${tm.name}`,
          timeframe: tm.category || "TA-Lib",
          startIndex: 0,
          endIndex: tm.points.length - 1,
          startTime: "TA-Lib Standard",
          endTime: "Technical Quant",
          similarity: tm.similarity,
          pattern: tm.points,
          future: tm.points.slice(-Math.min(tm.points.length, 15)),
          trend: tm.trend,
          rawMatchIndices: { start: 0, end: tm.points.length - 1 },
        }));
      }

      // 3. Search in all active symbol datasets (if any are selected)
      let foundMarketMatches: MatchResult[] = [];
      if (activeDatasets.length > 0) {
        foundMarketMatches = await PatternMatcher.analyzeMultiDatasets(
          patternToSearch,
          activeDatasets,
          config,
          (pct) => setProgressPercent(pct),
          () => shouldStopRef.current
        );
      } else {
        setProgressPercent(100);
      }

      // Merge results, sort descending by similarity, and limit to configured topResults
      const mergedMatches = [...customAsMatchResults, ...talibAsMatchResults, ...foundMarketMatches]
        .sort((a, b) => b.similarity - a.similarity)
        .slice(0, config.topResults);

      mergedMatches.forEach((m, idx) => {
        m.rank = idx + 1;
      });

      setResults(mergedMatches);
      setTrendBreakdown(PatternMatcher.computeTrendBreakdown(mergedMatches));
      if (mergedMatches.length > 0) {
        setSelectedMatchIndex(0);
      }
    } catch (err) {
      console.error("Analysis Error:", err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Handler: Start Analysis with current reference pattern
  const handleStartAnalysis = async () => {
    if (!referencePattern) return;
    await executeAnalysis(referencePattern, referencePatternName);
  };

  // Handler: Run Search directly with a specific pattern (e.g. from Extractor or Library)
  const handleRunSearchWithPattern = (points: number[], name: string) => {
    setReferencePattern(points);
    setReferenceRelativeCoords(null);
    setReferencePatternName(name);
    executeAnalysis(points, name);
  };

  // Handler: Stop Analysis
  const handleStopAnalysis = () => {
    shouldStopRef.current = true;
    setIsAnalyzing(false);
  };

  // Handler: Clear All
  const handleClearAll = () => {
    setImageSrc(null);
    setReferencePattern(null);
    setReferenceRelativeCoords(null);
    setReferencePatternName("");
    setResults([]);
    setCustomMatches([]);
    setSelectedMatchIndex(null);
    setTrendBreakdown(null);
    setProgressPercent(0);
  };

  const selectedMatch =
    selectedMatchIndex !== null && results[selectedMatchIndex]
      ? results[selectedMatchIndex]
      : results[0] || null;

  return (
    <div
      id="chart-dna-app"
      data-theme={activeTheme}
      dir={isRtl ? "rtl" : "ltr"}
      className={`min-h-screen text-slate-100 flex flex-col transition-colors duration-300 ${
        isRtl ? "rtl" : "ltr"
      }`}
      style={{
        backgroundColor: "var(--theme-bg, #060913)",
        color: "var(--theme-text, #f8fafc)",
        fontFamily: "var(--app-font-family, 'Vazirmatn', sans-serif)",
      }}
    >
      {/* App Header */}
      <Header
        activeSymbol={activeDatasets[0]?.symbol || (isCustomPatternsActive ? "DNA Library" : "EURUSD")}
        onOpenSettings={() => {
          setSettingsTab("themes");
          setIsSettingsOpen(true);
        }}
        activeLanguage={activeLanguage}
        onSelectLanguage={(lang) => setActiveLanguage(lang)}
        activeTheme={activeTheme}
        onSelectTheme={(themeId) => setActiveTheme(themeId)}
        activeFont={activeFont}
        onSelectFont={(fontId) => setActiveFont(fontId)}
      />

      {/* Main Workspace Layout */}
      <main className="w-full max-w-[1920px] mx-auto px-2.5 sm:px-4 lg:px-6 py-3.5 flex-1 flex flex-col lg:flex-row gap-4 items-stretch">
        {/* Sidebar: Command Cockpit + Image Workspace */}
        <div className="w-full lg:w-[380px] xl:w-[420px] 2xl:w-[460px] shrink-0 flex flex-col">
          <SidebarControls
            cropperSlot={
              <ImageCropperCanvas
                imageSrc={imageSrc}
                onImageLoaded={() => {}}
                onCropChange={(crop) => setCropBox(crop)}
                onPriceScaleDetected={(calib) => setPriceCalibration(calib)}
                extractorPointCount={config.extractorPointCount ?? 500}
                triggerExtractPattern={extractTriggerCounter}
                triggerPriceScaleModal={priceScaleTriggerCounter}
                referencePrice={referencePrice}
                onUpdateReferencePrice={(price) => setReferencePrice(price)}
                onPatternExtracted={(pat, relCoords) => {
                  setReferencePattern(pat);
                  setReferenceRelativeCoords(relCoords || null);
                  setReferencePatternName("Extracted from Crop");
                }}
                activeLanguage={activeLanguage}
                activeTheme={activeTheme}
              />
            }
            onSelectImageClick={() => {
              const input = document.createElement("input");
              input.type = "file";
              input.accept = "image/*";
              input.onchange = (e: any) => {
                const file = e.target.files?.[0];
                if (!file) return;
                const reader = new FileReader();
                reader.onload = (ev) => {
                  setImageSrc(ev.target?.result as string);
                };
                reader.readAsDataURL(file);
              };
              input.click();
            }}
            onClearAll={handleClearAll}
            onExtractPattern={() => {
              setExtractTriggerCounter((c) => c + 1);
            }}
            onOpenPriceScaleModal={() => {
              setPriceScaleTriggerCounter((c) => c + 1);
            }}
            onStartAnalysis={handleStartAnalysis}
            onStopAnalysis={handleStopAnalysis}
            isAnalyzing={isAnalyzing}
            progressPercent={progressPercent}
            hasImage={!!imageSrc}
            hasPattern={!!referencePattern && referencePattern.length > 5}
            hasDatasets={hasSearchableTargets}
            trendBreakdown={trendBreakdown}
            futureCandles={config.futureCandles ?? 70}
            selectedDatasetsCount={activeDatasets.length}
            totalCandlesCount={totalCandlesCount}
            customPatternsCount={isCustomPatternsActive ? savedPatterns.length : 0}
            extractorPointCount={config.extractorPointCount ?? 500}
            patternAnalysisSlot={
              <PatternExtremaTargetsPanel
                imageSrc={imageSrc}
                cropBox={cropBox}
                extrema={patternExtrema}
                scenarios={forwardScenarios}
                futureCandlesCount={config.futureCandles}
                referencePrice={referencePrice}
                onUpdateReferencePrice={(price) => setReferencePrice(price)}
                activeLanguage={activeLanguage}
                activeTheme={activeTheme}
              />
            }
            activeTheme={activeTheme}
            onOpenSettings={(tab) => {
              setSettingsTab((tab as any) || "general");
              setIsSettingsOpen(true);
            }}
            activeLanguage={activeLanguage}
          />
        </div>

        {/* Main Content Workspace */}
        <div className="flex-1 flex flex-col gap-4 min-w-0">
          {/* 1. پنجره اطلاعات الگوی کشف شده (Comparative Overlay & Discovery Visualizer) - Full Width under Header */}
          <ComparativeChart
            referencePattern={referencePattern}
            selectedMatch={selectedMatch}
            referencePrice={referencePrice}
            extractorPointCount={config.extractorPointCount ?? 500}
            onOpenCandleChart={(match) => setCandleModalResult(match)}
            activeLanguage={activeLanguage}
            activeTheme={activeTheme}
          />

          {/* 2. پنجره نتایج تطبیق الگوهای تاریخی (Historical Pattern Similarity Results Table) */}
          <ResultsTable
            results={results}
            customMatches={customMatches}
            selectedIndex={selectedMatchIndex}
            referencePrice={referencePrice}
            onUpdateReferencePrice={(price) => setReferencePrice(price)}
            onSelectResult={(idx) => setSelectedMatchIndex(idx)}
            onOpenCandleChart={(match) => setCandleModalResult(match)}
            onApplyCustomPattern={(pat, name) => handleRunSearchWithPattern(pat, name)}
            activeLanguage={activeLanguage}
            activeTheme={activeTheme}
          />
        </div>
      </main>

      {/* Settings & Data Modal (Themes, Languages, Algorithm, Weights, Data, Pattern Extractor) */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        initialTab={settingsTab}
        config={config}
        onUpdateConfig={(newConf) => setConfig(newConf)}
        datasets={datasets}
        onUpdateDatasets={(newDatasets) => setDatasets(newDatasets)}
        selectedDatasetIds={selectedDatasetIds}
        onToggleDatasetId={(id) => {
          setSelectedDatasetIds((prev) =>
            prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
          );
        }}
        onSetSelectedDatasetIds={(ids) => setSelectedDatasetIds(ids)}
        onSelectAllDatasets={(selectAll) => {
          setSelectedDatasetIds(selectAll ? datasets.map((d) => d.id) : []);
        }}
        savedPatterns={savedPatterns}
        onSavePattern={(newPat) => {
          setSavedPatterns((prev) => [newPat, ...prev]);
        }}
        onDeletePattern={(id) => {
          setSavedPatterns((prev) => prev.filter((p) => p.id !== id));
        }}
        onApplyAsActiveReference={(pat, name) => {
          setReferencePattern(pat);
          setReferenceRelativeCoords(null);
          setReferencePatternName(name);
        }}
        onRunSearchWithPattern={(pat, name) => {
          handleRunSearchWithPattern(pat, name);
        }}
        includeCustomPatternsInSearch={includeCustomPatternsInSearch}
        onToggleIncludeCustomPatterns={(inc) => setIncludeCustomPatternsInSearch(inc)}
        includeTALibPatternsInSearch={includeTALibPatternsInSearch}
        onToggleIncludeTALibPatterns={(inc) => setIncludeTALibPatternsInSearch(inc)}
        activeTheme={activeTheme}
        onSelectTheme={(th) => setActiveTheme(th)}
        activeFont={activeFont}
        onSelectFont={(f) => setActiveFont(f)}
        activeLanguage={activeLanguage}
        onSelectLanguage={(lang) => setActiveLanguage(lang)}
      />

      {/* My DNA Library Modal */}
      <MyDNAModal
        isOpen={isMyDNAOpen}
        onClose={() => setIsMyDNAOpen(false)}
        savedPatterns={savedPatterns}
        onApplyPattern={(pat, name) => {
          setReferencePattern(pat);
          setReferenceRelativeCoords(null);
          setReferencePatternName(name);
        }}
        onDeletePattern={(id) => {
          setSavedPatterns((prev) => prev.filter((p) => p.id !== id));
        }}
        onImportLibrary={(imported) => {
          setSavedPatterns(imported);
        }}
        activeLanguage={activeLanguage}
        activeTheme={activeTheme}
      />

      {/* Candlestick Modal */}
      <CandleChartModal
        isOpen={!!candleModalResult}
        onClose={() => setCandleModalResult(null)}
        result={candleModalResult}
        datasets={datasets}
        config={config}
        referencePattern={referencePattern}
        referencePrice={referencePrice}
        onUpdateReferencePrice={setReferencePrice}
        activeLanguage={activeLanguage}
        activeTheme={activeTheme}
      />
    </div>
  );
};

export default App;

