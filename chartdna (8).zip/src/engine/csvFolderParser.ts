import { Candle, MarketDataset } from "./types";
import { resampleCandles, TIMEFRAME_MINUTES } from "./timeframeBuilder";

/**
 * Normalizes symbol names (e.g. removes prefix/suffix like "EURUSD.pro" -> "EURUSD", "FX:EURUSD" -> "EURUSD")
 */
export function cleanSymbolName(raw: string): string {
  let s = raw.trim().toUpperCase();
  // Remove file extension
  s = s.replace(/\.[^/.]+$/, "");
  // Remove common broker suffixes like .pro, .raw, .ecn, _i, .m, .fx
  s = s.replace(/(\.PRO|\.RAW|\.ECN|_I|\.M|\.FX|\.STD)$/i, "");
  // Remove prefixes like FX:, BINANCE:, COINBASE:, OANDA:
  s = s.replace(/^[A-Z0-9_-]+:/i, "");
  // Replace underscores or dashes with clean text
  return s || "CUSTOM";
}

/**
 * Intelligent extraction of Symbol and Timeframe from filename and folder path
 */
export function extractSymbolAndTimeframe(
  filePath: string,
  fileName: string
): { symbol: string; timeframe: string } {
  const cleanPath = filePath.replace(/\\/g, "/");
  const baseName = fileName.replace(/\.[^/.]+$/, ""); // strip extension
  const pathParts = cleanPath.split("/").filter(Boolean);

  // Timeframe regex patterns
  const tfPatterns: { regex: RegExp; tf: string }[] = [
    { regex: /[-_.\s]?(M1|1M|1MIN|1MINUTES?)\b/i, tf: "M1" },
    { regex: /[-_.\s]?(M5|5M|5MIN|5MINUTES?)\b/i, tf: "M5" },
    { regex: /[-_.\s]?(M15|15M|15MIN|15MINUTES?)\b/i, tf: "M15" },
    { regex: /[-_.\s]?(M30|30M|30MIN|30MINUTES?)\b/i, tf: "M30" },
    { regex: /[-_.\s]?(H1|1H|60M|60MIN|1HOUR|60)\b/i, tf: "H1" },
    { regex: /[-_.\s]?(H4|4H|240M|240MIN|4HOURS?|240)\b/i, tf: "H4" },
    { regex: /[-_.\s]?(D1|1D|DAILY|1DAY|1440M|1440)\b/i, tf: "D1" },
    { regex: /[-_.\s]?(W1|1W|WEEKLY|1WEEK)\b/i, tf: "W1" },
    { regex: /[-_.\s]?(MN|MN1|1MN|MONTHLY)\b/i, tf: "MN" },
  ];

  let detectedTimeframe = "M1";
  let symbolCandidate = baseName;

  // 1. Check if folder contains symbol (e.g. /EURUSD/M1.csv or /Forex/XAUUSD/H1.csv)
  if (pathParts.length >= 2) {
    const parentFolder = pathParts[pathParts.length - 2];
    const isParentTf = tfPatterns.some((p) => p.regex.test(parentFolder));
    if (!isParentTf && parentFolder.length >= 3 && parentFolder.length <= 12) {
      symbolCandidate = parentFolder;
    }
  }

  // 2. Check filename or path for timeframe matches
  const targetToMatch = `${cleanPath} ${baseName}`;
  for (const { regex, tf } of tfPatterns) {
    if (regex.test(targetToMatch)) {
      detectedTimeframe = tf;
      // Strip TF token from symbolCandidate if it was in filename
      symbolCandidate = symbolCandidate.replace(regex, "");
      break;
    }
  }

  // 3. Handle MT4 numbers like EURUSD1, EURUSD5, EURUSD15, EURUSD60, EURUSD240, EURUSD1440
  const mt4Match = symbolCandidate.match(/^([A-Za-z0-9_]+?)(1|5|15|30|60|240|1440)$/);
  if (mt4Match) {
    const num = mt4Match[2];
    symbolCandidate = mt4Match[1];
    if (num === "1") detectedTimeframe = "M1";
    else if (num === "5") detectedTimeframe = "M5";
    else if (num === "15") detectedTimeframe = "M15";
    else if (num === "30") detectedTimeframe = "M30";
    else if (num === "60") detectedTimeframe = "H1";
    else if (num === "240") detectedTimeframe = "H4";
    else if (num === "1440") detectedTimeframe = "D1";
  }

  const cleanSymbol = cleanSymbolName(symbolCandidate);
  return {
    symbol: cleanSymbol || "SYMBOL",
    timeframe: detectedTimeframe,
  };
}

/**
 * Parses CSV raw text into a MarketDataset
 */
export function parseCSVToDataset(
  csvText: string,
  fileName: string,
  filePath: string = ""
): MarketDataset {
  // Strip BOM if present
  let cleanText = csvText;
  if (cleanText.charCodeAt(0) === 0xfeff) {
    cleanText = cleanText.slice(1);
  }

  const lines = cleanText
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  if (lines.length < 2) {
    throw new Error(`File ${fileName} does not contain enough data rows.`);
  }

  const { symbol, timeframe } = extractSymbolAndTimeframe(filePath || fileName, fileName);

  // Determine delimiter
  const headerCandidate = lines[0];
  let delimiter = ",";
  if (headerCandidate.includes("\t")) {
    delimiter = "\t";
  } else if (headerCandidate.includes(";")) {
    delimiter = ";";
  } else if (headerCandidate.includes("|")) {
    delimiter = "|";
  } else if (!headerCandidate.includes(",") && headerCandidate.split(/\s+/).length >= 4) {
    delimiter = " ";
  }

  const splitLine = (l: string) =>
    delimiter === " "
      ? l.trim().split(/\s+/).map((c) => c.replace(/["']/g, "").trim())
      : l.split(delimiter).map((c) => c.replace(/["']/g, "").trim());

  const headers = splitLine(headerCandidate).map((h) => h.toLowerCase());

  let dateIdx = -1;
  let timeIdx = -1;
  let openIdx = -1;
  let highIdx = -1;
  let lowIdx = -1;
  let closeIdx = -1;
  let volIdx = -1;

  // Header detection
  for (let i = 0; i < headers.length; i++) {
    const h = headers[i];
    if (h === "open" || h === "<open>" || h === "o") openIdx = i;
    else if (h === "high" || h === "<high>" || h === "h") highIdx = i;
    else if (h === "low" || h === "<low>" || h === "l") lowIdx = i;
    else if (h === "close" || h === "<close>" || h === "c") closeIdx = i;
    else if (h.includes("vol") || h === "<vol>" || h === "<volume>" || h === "v") volIdx = i;
    else if (h === "date" || h === "<date>" || h === "d") dateIdx = i;
    else if (h === "time" || h === "<time>" || h === "t") timeIdx = i;
    else if (h.includes("datetime") || h.includes("timestamp") || h.includes("open_time")) dateIdx = i;
  }

  const hasHeader = openIdx !== -1 && closeIdx !== -1;
  const startRow = hasHeader ? 1 : 0;

  // If no header, use default MetaTrader structure: [Date, Time, Open, High, Low, Close, Volume] or [DateTime, Open, High, Low, Close]
  if (!hasHeader) {
    const firstCols = splitLine(lines[0]);
    if (firstCols.length >= 6) {
      dateIdx = 0;
      timeIdx = 1;
      openIdx = 2;
      highIdx = 3;
      lowIdx = 4;
      closeIdx = 5;
      volIdx = firstCols.length >= 7 ? 6 : -1;
    } else if (firstCols.length === 5) {
      dateIdx = 0;
      timeIdx = -1;
      openIdx = 1;
      highIdx = 2;
      lowIdx = 3;
      closeIdx = 4;
    } else {
      openIdx = 0;
      highIdx = 1;
      lowIdx = 2;
      closeIdx = 3;
    }
  }

  const candles: Candle[] = [];
  const maxAllowedRows = 60000; // Cap single dataset at 60k most recent candles to maintain speed & memory health
  const startIndex = lines.length - startRow > maxAllowedRows ? lines.length - maxAllowedRows : startRow;

  for (let i = startIndex; i < lines.length; i++) {
    const cols = splitLine(lines[i]);
    if (cols.length < 4) continue;

    const open = parseFloat(cols[openIdx]);
    const high = parseFloat(cols[highIdx >= 0 ? highIdx : openIdx]);
    const low = parseFloat(cols[lowIdx >= 0 ? lowIdx : openIdx]);
    const close = parseFloat(cols[closeIdx]);
    const vol = volIdx >= 0 ? parseFloat(cols[volIdx]) : undefined;

    if (isNaN(open) || isNaN(close)) continue;

    let timestampStr = `Candle ${i + 1}`;
    if (dateIdx >= 0 && timeIdx >= 0 && cols[dateIdx] && cols[timeIdx]) {
      timestampStr = `${cols[dateIdx]} ${cols[timeIdx]}`;
    } else if (dateIdx >= 0 && cols[dateIdx]) {
      timestampStr = cols[dateIdx];
    }

    candles.push({
      timestamp: timestampStr,
      open,
      high: isNaN(high) ? Math.max(open, close) : high,
      low: isNaN(low) ? Math.min(open, close) : low,
      close,
      volume: !isNaN(vol!) ? vol : undefined,
    });
  }

  if (candles.length === 0) {
    throw new Error(`No valid candle data found in ${fileName}`);
  }

  const datasetId = `${symbol.toLowerCase()}_${timeframe.toLowerCase()}_${Date.now()}_${Math.floor(Math.random() * 1000)}`;

  return {
    id: datasetId,
    name: `${symbol} - ${timeframe}`,
    symbol,
    timeframe,
    candles,
  };
}

/**
 * Reads a File object and parses it into a MarketDataset
 */
export async function readAndParseFile(file: File): Promise<MarketDataset> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result as string;
        const relativePath = (file as any).webkitRelativePath || file.name;
        const dataset = parseCSVToDataset(text, file.name, relativePath);
        resolve(dataset);
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = () => reject(new Error(`Failed to read file ${file.name}`));
    reader.readAsText(file);
  });
}
