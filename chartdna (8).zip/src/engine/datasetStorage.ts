import { MarketDataset } from "./types";
import { BUILTIN_DATASETS } from "./sampleData";

const DB_NAME = "ChartDNA_Storage";
const DB_VERSION = 1;
const STORE_DATASETS = "market_datasets";
const STORE_META = "metadata";

/**
 * Opens or initializes the IndexedDB database
 */
function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === "undefined" || !window.indexedDB) {
      return reject(new Error("IndexedDB is not supported in this environment"));
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_DATASETS)) {
        db.createObjectStore(STORE_DATASETS, { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains(STORE_META)) {
        db.createObjectStore(STORE_META, { keyPath: "key" });
      }
    };

    request.onsuccess = () => {
      resolve(request.result);
    };

    request.onerror = () => {
      reject(request.error || new Error("Failed to open IndexedDB"));
    };
  });
}

/**
 * Loads all market datasets from IndexedDB (with fallback to LocalStorage/Built-in datasets)
 */
export async function loadDatasetsFromStorage(): Promise<MarketDataset[]> {
  try {
    const db = await openDB();
    return new Promise((resolve) => {
      try {
        const tx = db.transaction(STORE_DATASETS, "readonly");
        const store = tx.objectStore(STORE_DATASETS);
        const req = store.getAll();

        req.onsuccess = () => {
          const results = req.result as MarketDataset[];
          if (results && results.length > 0) {
            resolve(results);
          } else {
            // Check legacy localStorage if any exists
            try {
              const legacy = localStorage.getItem("chartdna_datasets");
              if (legacy) {
                const parsed = JSON.parse(legacy);
                if (Array.isArray(parsed) && parsed.length > 0) {
                  // Migrate to IndexedDB
                  saveDatasetsToStorage(parsed).catch(console.error);
                  try {
                    localStorage.removeItem("chartdna_datasets");
                  } catch (e) {}
                  return resolve(parsed);
                }
              }
            } catch (e) {}

            // Default to built-in datasets
            resolve(BUILTIN_DATASETS);
          }
        };

        req.onerror = () => {
          console.warn("Error reading from IndexedDB, fallback to samples:", req.error);
          resolve(BUILTIN_DATASETS);
        };
      } catch (err) {
        console.warn("Transaction error in IndexedDB:", err);
        resolve(BUILTIN_DATASETS);
      }
    });
  } catch (err) {
    console.warn("IndexedDB unavailable, checking fallback:", err);
    try {
      const legacy = localStorage.getItem("chartdna_datasets");
      if (legacy) {
        return JSON.parse(legacy);
      }
    } catch (e) {}
    return BUILTIN_DATASETS;
  }
}

/**
 * Saves market datasets into IndexedDB asynchronously without blocking UI or hitting 5MB quota
 */
export async function saveDatasetsToStorage(datasets: MarketDataset[]): Promise<void> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      try {
        const tx = db.transaction(STORE_DATASETS, "readwrite");
        const store = tx.objectStore(STORE_DATASETS);

        // Clear previous items and write new ones
        const clearReq = store.clear();
        clearReq.onsuccess = () => {
          for (const dataset of datasets) {
            store.put(dataset);
          }
        };

        tx.oncomplete = () => {
          resolve();
        };

        tx.onerror = () => {
          reject(tx.error || new Error("Failed to save datasets in IndexedDB"));
        };
      } catch (err) {
        reject(err);
      }
    });
  } catch (err) {
    console.warn("IndexedDB save failed, attempting minimal safe cache:", err);
    // If IndexedDB completely fails (e.g. strict private mode), avoid localStorage quota crash
    try {
      // Only store metadata without huge candle arrays to prevent QuotaExceededError
      const lightMetadata = datasets.map((d) => ({
        id: d.id,
        name: d.name,
        symbol: d.symbol,
        timeframe: d.timeframe,
        candlesCount: d.candles.length,
      }));
      localStorage.setItem("chartdna_datasets_meta", JSON.stringify(lightMetadata));
    } catch (e) {
      console.warn("Storage full / unavailable:", e);
    }
  }
}

/**
 * Loads selected dataset IDs safely
 */
export function loadSelectedDatasetIdsFromStorage(): string[] {
  try {
    const fromStorage = localStorage.getItem("chartdna_selected_dataset_ids");
    if (fromStorage) {
      const parsed = JSON.parse(fromStorage);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch (e) {
    console.error("Error reading selected dataset IDs:", e);
  }
  return [];
}

/**
 * Saves selected dataset IDs safely
 */
export function saveSelectedDatasetIdsToStorage(ids: string[]): void {
  try {
    localStorage.setItem("chartdna_selected_dataset_ids", JSON.stringify(ids));
  } catch (e) {
    console.warn("Failed to write selected dataset IDs to localStorage:", e);
  }
}
