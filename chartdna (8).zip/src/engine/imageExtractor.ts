import { normalizeShape, resampleSeries } from "./normalizer";

export interface ExtractedPatternResult {
  normalizedShape: number[]; // Resampled & normalized [-1, 1] series for search engine
  relativeCoords: { relX: number; relY: number }[]; // Exact relative positions [0..1] in the crop box
  rawYValues: number[];
  firstValidX: number;
  lastValidX: number;
}

interface ColumnSegment {
  yStart: number;
  yEnd: number;
  yCenter: number;
  height: number;
  isSaturated: boolean;
  isBottomVolume: boolean;
  isTopBanner: boolean;
  weight: number;
  candleScore: number;
}

/**
 * Advanced multi-pass financial chart pattern extractor.
 * Handles candlesticks, line charts, wicks, volume bars suppression,
 * and eliminates false top UI/header/watermark/grid noise spikes at pattern boundaries.
 */
export function extractPatternFromImageData(
  imageData: ImageData,
  targetPointCount: number = 80
): ExtractedPatternResult | null {
  const { width, height, data } = imageData;
  if (width < 8 || height < 8) return null;

  const numPoints = Math.max(10, Math.min(2000, targetPointCount || 80));

  // Step 1: Detect background brightness & theme
  let totalBrightness = 0;
  const totalPixels = width * height;

  for (let i = 0; i < data.length; i += 4) {
    totalBrightness += (data[i] + data[i + 1] + data[i + 2]) / 3;
  }

  const avgBrightness = totalBrightness / totalPixels;
  const isDarkBackground = avgBrightness < 145;

  // Step 2: Extract candidate pixels & group them into vertical runs per column
  const columnSegments: ColumnSegment[][] = [];
  const strongCandleYPositions: number[] = [];

  for (let x = 0; x < width; x++) {
    const isMatchingY: boolean[] = new Array(height).fill(false);
    const pixelWeights: number[] = new Array(height).fill(0);
    const pixelCandleScores: number[] = new Array(height).fill(0);

    for (let y = 0; y < height; y++) {
      const idx = (y * width + x) * 4;
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];

      const max = Math.max(r, g, b);
      const min = Math.min(r, g, b);
      const saturation = max - min;
      const lum = 0.299 * r + 0.587 * g + 0.114 * b;

      // Bullish candle / cyan / green / lime
      const isGreenBullish = g > r + 12 && g > b - 15 && g > 55;
      // Bearish candle / red / orange / pink
      const isRedBearish = r > g + 12 && r > b - 15 && r > 55;
      // Vibrant indicator or trend line
      const isSaturatedLine = saturation > 35 && max > 70;
      // White / neon / bright candle or wick on dark chart
      const isBrightWick = isDarkBackground && r > 165 && g > 165 && b > 165;
      // Dark ink / black candle or wick on light chart
      const isDarkInk = !isDarkBackground && r < 105 && g < 105 && b < 105;

      let isMatch = false;
      let weight = 1;
      let candleScore = 0;

      if (isDarkBackground) {
        if (isGreenBullish || isRedBearish) {
          isMatch = true;
          weight = 4.0;
          candleScore = 3.0;
          strongCandleYPositions.push(y);
        } else if (isSaturatedLine) {
          isMatch = true;
          weight = 3.5;
          candleScore = 2.5;
          strongCandleYPositions.push(y);
        } else if (isBrightWick) {
          isMatch = true;
          weight = 2.0;
          candleScore = 1.0;
        } else if (lum > avgBrightness + 45 && lum > 85) {
          isMatch = true;
          weight = 1.0;
          candleScore = 0.5;
        }
      } else {
        if (isGreenBullish || isRedBearish) {
          isMatch = true;
          weight = 4.0;
          candleScore = 3.0;
          strongCandleYPositions.push(y);
        } else if (isSaturatedLine) {
          isMatch = true;
          weight = 3.5;
          candleScore = 2.5;
          strongCandleYPositions.push(y);
        } else if (isDarkInk) {
          isMatch = true;
          weight = 2.0;
          candleScore = 1.0;
        } else if (lum < avgBrightness - 45 && lum < 175) {
          isMatch = true;
          weight = 1.0;
          candleScore = 0.5;
        }
      }

      if (isMatch) {
        isMatchingY[y] = true;
        pixelWeights[y] = weight;
        pixelCandleScores[y] = candleScore;
      }
    }

    // Group matching pixels into vertical segments
    const segments: ColumnSegment[] = [];
    let runStart = -1;
    let runWeightSum = 0;
    let runScoreSum = 0;

    for (let y = 0; y < height; y++) {
      if (isMatchingY[y]) {
        if (runStart === -1) {
          runStart = y;
          runWeightSum = pixelWeights[y];
          runScoreSum = pixelCandleScores[y];
        } else {
          runWeightSum += pixelWeights[y];
          runScoreSum += pixelCandleScores[y];
        }
      } else {
        if (runStart !== -1) {
          const runEnd = y - 1;
          const segHeight = runEnd - runStart + 1;
          const center = (runStart + runEnd) / 2;

          // Identify bottom volume bar or top header/watermark/UI text
          const isBottomVolume =
            runEnd >= height - 4 || (center > height * 0.78 && segHeight > 4);
          const isTopBanner =
            runStart <= 6 || (center < height * 0.18 && segHeight <= 14);

          segments.push({
            yStart: runStart,
            yEnd: runEnd,
            yCenter: center,
            height: segHeight,
            isSaturated: runScoreSum > 0,
            isBottomVolume,
            isTopBanner,
            weight: runWeightSum,
            candleScore: runScoreSum,
          });

          runStart = -1;
          runWeightSum = 0;
          runScoreSum = 0;
        }
      }
    }

    if (runStart !== -1) {
      const runEnd = height - 1;
      const segHeight = runEnd - runStart + 1;
      const center = (runStart + runEnd) / 2;

      segments.push({
        yStart: runStart,
        yEnd: runEnd,
        yCenter: center,
        height: segHeight,
        isSaturated: runScoreSum > 0,
        isBottomVolume: true,
        isTopBanner: false,
        weight: runWeightSum,
        candleScore: runScoreSum,
      });
    }

    // Step 2b: Filter out top banner/header text and bottom volume
    const cleanCandleSegments = segments.filter(
      (s) => !s.isBottomVolume && !s.isTopBanner
    );

    if (cleanCandleSegments.length > 0) {
      columnSegments.push(cleanCandleSegments);
    } else if (segments.length > 0) {
      // If only volume/banner exist, prefer candle segments or lower segments
      const nonTopSegments = segments.filter((s) => !s.isTopBanner);
      if (nonTopSegments.length > 0) {
        columnSegments.push(nonTopSegments);
      } else {
        // Tag remaining top banner segments with low weight so they don't dominate
        columnSegments.push(
          segments.map((s) => ({ ...s, weight: Math.min(s.weight, 0.5) }))
        );
      }
    } else {
      columnSegments.push([]);
    }
  }

  // Step 3: Find active horizontal range (first and last valid columns with real chart data)
  const validCols: number[] = [];
  columnSegments.forEach((segs, x) => {
    if (segs.length > 0) validCols.push(x);
  });

  const minRequiredCols = Math.max(6, Math.floor(width * 0.05));
  if (validCols.length < minRequiredCols) {
    // Fallback to edge contrast extractor
    const fallbackCurve = extractPathByLuminanceEdges(imageData, numPoints);
    if (!fallbackCurve) return null;

    const n = fallbackCurve.length;
    const relativeCoords = fallbackCurve.map((val, idx) => ({
      relX: idx / (n - 1),
      relY: 0.5 - val * 0.4,
    }));

    return {
      normalizedShape: fallbackCurve,
      relativeCoords,
      rawYValues: relativeCoords.map((c) => c.relY * height),
      firstValidX: 0,
      lastValidX: width - 1,
    };
  }

  const firstValidX = validCols[0];
  const lastValidX = validCols[validCols.length - 1];
  const activeWidth = lastValidX - firstValidX + 1;

  if (activeWidth < 6) return null;

  // Step 3b: Calculate starting baseline Y from the first 5-15 columns that have strong candle scores
  let startCandleYSum = 0;
  let startCandleCount = 0;
  const startWindowCols = Math.min(activeWidth, Math.max(8, Math.floor(activeWidth * 0.15)));

  for (let c = 0; c < startWindowCols; c++) {
    const origX = firstValidX + c;
    const segs = columnSegments[origX] || [];
    for (const seg of segs) {
      if (seg.candleScore > 0 && !seg.isTopBanner && !seg.isBottomVolume) {
        startCandleYSum += seg.yCenter * seg.weight;
        startCandleCount += seg.weight;
      }
    }
  }

  const startingAnchorY =
    startCandleCount > 0
      ? startCandleYSum / startCandleCount
      : strongCandleYPositions.length > 0
      ? strongCandleYPositions[Math.floor(strongCandleYPositions.length / 2)]
      : height * 0.5;

  // Step 4: Dynamic Programming (Viterbi) Path Finding across the chart
  interface DPState {
    y: number;
    cost: number;
    prevIndex: number;
  }

  const dpLayers: DPState[][] = [];

  for (let col = 0; col < activeWidth; col++) {
    const origX = firstValidX + col;
    const segs = columnSegments[origX];

    const layerCandidates: DPState[] = [];

    if (segs.length > 0) {
      segs.forEach((seg) => {
        // Preference for strong candle body centers
        let baseCost = 80 / Math.max(0.5, seg.weight);
        if (seg.candleScore > 0) baseCost *= 0.5; // High priority for candle colors
        if (seg.isBottomVolume) baseCost += 300; // Heavy penalty for volume
        if (seg.isTopBanner) baseCost += 350; // Heavy penalty for top UI/header text

        // Extra penalty for segments near top border (y < 0.15 * height) if far from starting anchor
        if (seg.yCenter < height * 0.15 && Math.abs(seg.yCenter - startingAnchorY) > height * 0.25) {
          baseCost += 400;
        }

        // At column 0, anchor cost prevents starting at top border noise
        if (col === 0) {
          const startDist = Math.abs(seg.yCenter - startingAnchorY);
          baseCost += (startDist * startDist) / Math.max(1, height * 0.3);
        }

        layerCandidates.push({
          y: seg.yCenter,
          cost: baseCost,
          prevIndex: -1,
        });
      });
    }

    // If no candidate, add virtual candidates spaced across height
    if (layerCandidates.length === 0) {
      if (dpLayers.length > 0) {
        const prevLayer = dpLayers[dpLayers.length - 1];
        let bestPrev = prevLayer[0];
        for (let k = 1; k < prevLayer.length; k++) {
          if (prevLayer[k].cost < bestPrev.cost) bestPrev = prevLayer[k];
        }
        layerCandidates.push({
          y: bestPrev.y,
          cost: bestPrev.cost + 5,
          prevIndex: 0,
        });
      } else {
        layerCandidates.push({
          y: startingAnchorY,
          cost: 30,
          prevIndex: -1,
        });
      }
    }

    if (col === 0) {
      dpLayers.push(layerCandidates);
    } else {
      const prevLayer = dpLayers[col - 1];

      layerCandidates.forEach((curr) => {
        let bestCost = Infinity;
        let bestPrevIdx = -1;

        prevLayer.forEach((prev, pIdx) => {
          const dy = Math.abs(curr.y - prev.y);
          // Quadratic transition cost to enforce continuous price movement
          const transitionCost = (dy * dy) / Math.max(1, height * 0.45);
          const totalCost = prev.cost + curr.cost + transitionCost;

          if (totalCost < bestCost) {
            bestCost = totalCost;
            bestPrevIdx = pIdx;
          }
        });

        curr.cost = bestCost;
        curr.prevIndex = bestPrevIdx;
      });

      dpLayers.push(layerCandidates);
    }
  }

  // Step 5: Backtrack optimal path
  const bestPathY: number[] = new Array(activeWidth);
  const lastLayer = dpLayers[activeWidth - 1];
  let bestEndIdx = 0;
  let minFinalCost = Infinity;

  lastLayer.forEach((cand, idx) => {
    if (cand.cost < minFinalCost) {
      minFinalCost = cand.cost;
      bestEndIdx = idx;
    }
  });

  let curIdx = bestEndIdx;
  for (let col = activeWidth - 1; col >= 0; col--) {
    const cand = dpLayers[col][curIdx];
    bestPathY[col] = cand.y;
    curIdx = cand.prevIndex >= 0 ? cand.prevIndex : 0;
  }

  // Step 6: Robust Endpoint Outlier Cleaning (Eliminate any edge jump/spike)
  const cleanedPathY: number[] = [...bestPathY];

  // Clean starting edge (points 0, 1, 2)
  if (activeWidth >= 6) {
    const startSub = cleanedPathY.slice(2, Math.min(8, activeWidth)).sort((a, b) => a - b);
    const startRefMedian = startSub[Math.floor(startSub.length / 2)];
    const maxAllowedEdgeDelta = height * 0.22;

    if (Math.abs(cleanedPathY[0] - startRefMedian) > maxAllowedEdgeDelta) {
      // Extrapolate point 0 smoothly from points 1, 2, 3
      cleanedPathY[0] = 2 * cleanedPathY[1] - cleanedPathY[2];
      // Clamp to image bounds and realistic range
      if (Math.abs(cleanedPathY[0] - startRefMedian) > maxAllowedEdgeDelta) {
        cleanedPathY[0] = startRefMedian;
      }
    }

    if (Math.abs(cleanedPathY[1] - startRefMedian) > maxAllowedEdgeDelta) {
      cleanedPathY[1] = (cleanedPathY[0] + cleanedPathY[2]) / 2;
    }
  }

  // Clean ending edge
  if (activeWidth >= 6) {
    const endSub = cleanedPathY.slice(Math.max(0, activeWidth - 8), activeWidth - 2).sort((a, b) => a - b);
    const endRefMedian = endSub[Math.floor(endSub.length / 2)];
    const maxAllowedEdgeDelta = height * 0.22;
    const lastIdx = activeWidth - 1;

    if (Math.abs(cleanedPathY[lastIdx] - endRefMedian) > maxAllowedEdgeDelta) {
      cleanedPathY[lastIdx] = 2 * cleanedPathY[lastIdx - 1] - cleanedPathY[lastIdx - 2];
      if (Math.abs(cleanedPathY[lastIdx] - endRefMedian) > maxAllowedEdgeDelta) {
        cleanedPathY[lastIdx] = endRefMedian;
      }
    }
  }

  // 1. Median filter with boundary extension (radius 1)
  const medianFiltered: number[] = new Array(activeWidth);
  for (let i = 0; i < activeWidth; i++) {
    const pPrev = i > 0 ? cleanedPathY[i - 1] : cleanedPathY[i];
    const pCurr = cleanedPathY[i];
    const pNext = i < activeWidth - 1 ? cleanedPathY[i + 1] : cleanedPathY[i];
    const trio = [pPrev, pCurr, pNext].sort((a, b) => a - b);
    medianFiltered[i] = trio[1];
  }

  // 2. Adaptive Gaussian / Moving Average Smoothing (preserves genuine extrema)
  const smoothWindow = Math.max(3, Math.min(9, Math.floor(activeWidth / 35)));
  const smoothedY = smoothPreservingEnds(medianFiltered, smoothWindow);

  // Step 7: Resample to target points count (default 80, configurable from 20 to 1000)
  const resampledY = resampleSeries(smoothedY, numPoints);

  // Step 8: Build relative coordinates [0..1] for pixel-perfect chart overlay
  const relativeCoords: { relX: number; relY: number }[] = [];

  for (let i = 0; i < numPoints; i++) {
    const t = i / (numPoints - 1);
    const origX = firstValidX + t * (lastValidX - firstValidX);
    const relX = origX / (width - 1 || 1);
    const relY = Math.max(0, Math.min(1, resampledY[i] / (height - 1 || 1)));

    relativeCoords.push({ relX, relY });
  }

  // Invert Y for price series: lower Y pixel is higher price
  const priceLikeSeries = resampledY.map((y) => -y);
  const normalizedShape = normalizeShape(priceLikeSeries);

  return {
    normalizedShape,
    relativeCoords,
    rawYValues: resampledY,
    firstValidX,
    lastValidX,
  };
}

/**
 * Standard backward-compatible extractor returning number[] for search engine
 */
export function extractPathFromImageData(
  imageData: ImageData,
  targetPointCount: number = 80
): number[] | null {
  const result = extractPatternFromImageData(imageData, targetPointCount);
  if (!result) return null;
  return result.normalizedShape;
}

/**
 * Smooths series while keeping original endpoints fixed to avoid drooping at chart edges
 */
function smoothPreservingEnds(series: number[], windowSize: number): number[] {
  const n = series.length;
  if (n <= windowSize) return [...series];

  const half = Math.floor(windowSize / 2);
  const result: number[] = new Array(n);

  for (let i = 0; i < n; i++) {
    // Near ends, reduce window symmetrically
    const currentRadius = Math.min(half, i, n - 1 - i);
    let sum = 0;
    let count = 0;

    for (let j = -currentRadius; j <= currentRadius; j++) {
      sum += series[i + j];
      count++;
    }

    result[i] = sum / count;
  }

  return result;
}

function extractPathByLuminanceEdges(
  imageData: ImageData,
  targetPointCount: number = 80
): number[] | null {
  const { width, height, data } = imageData;
  const colCenters: number[] = [];

  for (let x = 0; x < width; x++) {
    let weightedYSum = 0;
    let weightSum = 0;

    for (let y = 0; y < height; y++) {
      const idx = (y * width + x) * 4;
      const lum = data[idx] * 0.299 + data[idx + 1] * 0.587 + data[idx + 2] * 0.114;
      const weight = Math.abs(lum - 128);
      if (weight > 30) {
        weightedYSum += y * weight;
        weightSum += weight;
      }
    }

    colCenters.push(weightSum > 0 ? -(weightedYSum / weightSum) : 0);
  }

  const numPoints = Math.max(10, Math.min(2000, targetPointCount || 80));
  return normalizeShape(resampleSeries(colCenters, numPoints));
}

