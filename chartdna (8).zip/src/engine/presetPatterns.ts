import { normalizeShape, resampleSeries } from "./normalizer";
import { MyDNAPattern } from "./types";

export interface TALibPatternPreset {
  id: string;
  name: string;
  nameFa: string;
  category: "Reversal" | "Continuation" | "Harmonic" | "Candlestick" | "Wyckoff";
  description: string;
  descriptionFa: string;
  libraryOrigin: "TA-Lib Standard" | "Classic Price Action" | "Harmonic Quant";
  points: number[];
}

export const TALIB_STANDARD_PATTERNS: TALibPatternPreset[] = [
  {
    id: "talib_head_and_shoulders",
    name: "Head & Shoulders (TA-Lib)",
    nameFa: "سر و شانه سقف (الگوی استاندارد)",
    category: "Reversal",
    libraryOrigin: "TA-Lib Standard",
    description: "Classic major bearish reversal: Left shoulder, higher head, right shoulder, then breakdown.",
    descriptionFa: "الگوی بازگشتی ماژور نزولی: شانه چپ، سر بالاتر، شانه راست و سپس شکست خط گردن.",
    points: [
      0.0, 0.4, 0.7, 0.4, 0.2, 0.5, 0.9, 1.0, 0.9, 0.4, 0.2, 0.4, 0.68, 0.4, 0.1, -0.2
    ],
  },
  {
    id: "talib_inv_head_and_shoulders",
    name: "Inverted Head & Shoulders",
    nameFa: "سر و شانه معکوس (کف)",
    category: "Reversal",
    libraryOrigin: "TA-Lib Standard",
    description: "Classic major bullish reversal: Left trough, lower head, right trough, then breakout.",
    descriptionFa: "الگوی بازگشتی ماژور صعودی: کف چپ، سر پایین‌تر، کف راست و شکست مقاومت گردن.",
    points: [
      0.0, -0.4, -0.7, -0.4, -0.2, -0.5, -0.9, -1.0, -0.9, -0.4, -0.2, -0.4, -0.68, -0.4, -0.1, 0.2
    ],
  },
  {
    id: "talib_double_top",
    name: "Double Top (M-Pattern)",
    nameFa: "سقف دوقلو (الگوی M)",
    category: "Reversal",
    libraryOrigin: "TA-Lib Standard",
    description: "Two distinct peaks at equal resistance level with a neckline trough between them.",
    descriptionFa: "دو قله متوالی در یک سطح مقاومتی با یک دره میانی و شکست رو به پایین.",
    points: [
      -0.5, 0.0, 0.6, 0.95, 0.6, 0.1, -0.1, 0.2, 0.65, 0.95, 0.6, 0.0, -0.4, -0.8
    ],
  },
  {
    id: "talib_double_bottom",
    name: "Double Bottom (W-Pattern)",
    nameFa: "کف دوقلو (الگوی W)",
    category: "Reversal",
    libraryOrigin: "TA-Lib Standard",
    description: "Two distinct troughs at equal support level with a central peak between them.",
    descriptionFa: "دو کف متوالی در یک تراز حمایتی با یک قله میانی و شکست رو به بالا.",
    points: [
      0.5, 0.0, -0.6, -0.95, -0.6, -0.1, 0.1, -0.2, -0.65, -0.95, -0.6, 0.0, 0.4, 0.8
    ],
  },
  {
    id: "talib_triple_top",
    name: "Triple Top (Resistance Test)",
    nameFa: "سقف سه‌قلو (تست مقاومت)",
    category: "Reversal",
    libraryOrigin: "Classic Price Action",
    description: "Three consecutive failed attempts to break resistance followed by strong downward breakdown.",
    descriptionFa: "سه برخورد متوالی به سقف مقاومتی بدون توان عبور و شروع ریزش سنگین.",
    points: [
      -0.4, 0.2, 0.9, 0.3, -0.1, 0.4, 0.92, 0.3, -0.1, 0.35, 0.9, 0.2, -0.2, -0.7
    ],
  },
  {
    id: "talib_triple_bottom",
    name: "Triple Bottom (Support Rebound)",
    nameFa: "کف سه‌قلو (بازگشت از حمایت)",
    category: "Reversal",
    libraryOrigin: "Classic Price Action",
    description: "Three consecutive tests of solid support floor followed by robust upward rally.",
    descriptionFa: "سه برخورد متوالی به کف حمایتی مستحکم و جهش قدرتمند صعودی.",
    points: [
      0.4, -0.2, -0.9, -0.3, 0.1, -0.4, -0.92, -0.3, 0.1, -0.35, -0.9, -0.2, 0.2, 0.7
    ],
  },
  {
    id: "talib_bull_flag",
    name: "Bull Flag & Pole",
    nameFa: "پرچم صعودی (Bull Flag)",
    category: "Continuation",
    libraryOrigin: "Classic Price Action",
    description: "Impulsive upward flagpole followed by tight downward sloping consolidation channel.",
    descriptionFa: "میله پرچم پرقدرت صعودی همراه با کانال اصلاحی فشرده رو به پایین.",
    points: [
      -0.9, -0.5, 0.0, 0.6, 0.95, 1.0, 0.85, 0.7, 0.8, 0.65, 0.75, 0.6, 0.7, 0.55, 0.68, 0.9
    ],
  },
  {
    id: "talib_bear_flag",
    name: "Bear Flag & Pole",
    nameFa: "پرچم نزولی (Bear Flag)",
    category: "Continuation",
    libraryOrigin: "Classic Price Action",
    description: "Impulsive downward drop followed by shallow upward drifting consolidation channel.",
    descriptionFa: "ریزش شارپ و پرچم استراحتی با شیب ملایم رو به بالا قبل از ریزش بعدی.",
    points: [
      0.9, 0.5, 0.0, -0.6, -0.95, -1.0, -0.85, -0.7, -0.8, -0.65, -0.75, -0.6, -0.7, -0.55, -0.68, -0.9
    ],
  },
  {
    id: "talib_cup_and_handle",
    name: "Cup & Handle (Bullish)",
    nameFa: "کاپ و دسته صعودی",
    category: "Continuation",
    libraryOrigin: "Classic Price Action",
    description: "U-shaped rounded bottom recovery followed by a slight downward drift handle and breakout.",
    descriptionFa: "کف‌سازی گرد U شکل و اصلاح فشرده در قالب دسته قبل از جهش قیمتی.",
    points: [
      0.8, 0.4, 0.0, -0.4, -0.7, -0.85, -0.85, -0.7, -0.4, 0.0, 0.4, 0.78, 0.65, 0.58, 0.68, 0.95
    ],
  },
  {
    id: "talib_ascending_triangle",
    name: "Ascending Triangle",
    nameFa: "مثلث افزایشی",
    category: "Continuation",
    libraryOrigin: "TA-Lib Standard",
    description: "Horizontal upper resistance ceiling with rising higher lows compressing into a breakout.",
    descriptionFa: "سقف افقی مقاومتی با کف‌های بالاتر متوالی که نشانه فشار خریداران است.",
    points: [
      -0.8, -0.2, 0.6, 0.9, 0.2, -0.3, 0.4, 0.9, 0.0, 0.5, 0.9, 0.3, 0.7, 0.92, 1.05
    ],
  },
  {
    id: "talib_descending_triangle",
    name: "Descending Triangle",
    nameFa: "مثلث کاهشی",
    category: "Continuation",
    libraryOrigin: "TA-Lib Standard",
    description: "Horizontal lower support floor with falling lower highs compressing into breakdown.",
    descriptionFa: "کف حمایتی افقی با قله‌های نزولی متوالی که نشانه برتری فروشندگان است.",
    points: [
      0.8, 0.2, -0.6, -0.9, -0.2, 0.3, -0.4, -0.9, 0.0, -0.5, -0.9, -0.3, -0.7, -0.92, -1.05
    ],
  },
  {
    id: "talib_falling_wedge",
    name: "Falling Wedge (Bullish Reversal)",
    nameFa: "کنج نزولی (Falling Wedge)",
    category: "Reversal",
    libraryOrigin: "Classic Price Action",
    description: "Downward sloping converging trendlines with diminishing volatility and explosive upside breakout.",
    descriptionFa: "کانال همگرای نزولی با کاهش حجم و نوسان و شکست انفجاری رو به بالا.",
    points: [
      0.9, 0.2, -0.4, 0.3, -0.2, -0.6, -0.1, -0.45, -0.75, -0.4, -0.6, -0.8, -0.55, -0.1, 0.4
    ],
  },
  {
    id: "talib_rising_wedge",
    name: "Rising Wedge (Bearish Reversal)",
    nameFa: "کنج صعودی (Rising Wedge)",
    category: "Reversal",
    libraryOrigin: "Classic Price Action",
    description: "Upward sloping converging trendlines with momentum exhaustion and sharp downside breakdown.",
    descriptionFa: "حرکت صعودی همگرا با افت مومنتوم و ریزش ناگهانی رو به پایین.",
    points: [
      -0.9, -0.2, 0.4, -0.3, 0.2, 0.6, 0.1, 0.45, 0.75, 0.4, 0.6, 0.8, 0.55, 0.1, -0.4
    ],
  },
  {
    id: "talib_wyckoff_spring",
    name: "Wyckoff Spring & Test",
    nameFa: "اسپرینگ وایکوف (Wyckoff Spring)",
    category: "Wyckoff",
    libraryOrigin: "Harmonic Quant",
    description: "Accumulation phase false break below support to shake out stops before explosive markup.",
    descriptionFa: "فاز جمع‌آوری و فیک بریک زیر حمایت جهت جمع‌آوری استاپ‌ها و آغاز رشد بزرگ.",
    points: [
      0.3, -0.2, -0.6, -0.5, 0.1, -0.4, -0.55, 0.2, -0.3, -0.95, -0.4, -0.1, 0.4, 0.8, 1.1
    ],
  },
  {
    id: "talib_wyckoff_upthrust",
    name: "Wyckoff Upthrust (UTAD)",
    nameFa: "آپ‌ترست توزیع وایکوف (UTAD)",
    category: "Wyckoff",
    libraryOrigin: "Harmonic Quant",
    description: "Distribution phase bull trap peak above resistance to trigger fomo before major markdown.",
    descriptionFa: "سقف فریبنده بالای مقاومت در فاز توزیع قبل از ریزش سنگین مارک‌داون.",
    points: [
      -0.3, 0.2, 0.6, 0.5, -0.1, 0.4, 0.55, -0.2, 0.3, 0.95, 0.4, 0.1, -0.4, -0.8, -1.1
    ],
  },
  {
    id: "talib_gartley_222",
    name: "Gartley 222 Harmonic Pattern",
    nameFa: "الگوی هارمونیک گارتلی (Gartley 222)",
    category: "Harmonic",
    libraryOrigin: "Harmonic Quant",
    description: "XABCD harmonic retracement with precise 0.618 B-point and 0.786 D-point PRZ reversal.",
    descriptionFa: "الگوی هارمونیک با تراز فیبوناچی ۰.۶۱۸ و نقطه D در ۰.۷۸۶ و بازگشت صعودی.",
    points: [
      -0.8, 0.8, 0.3, 0.55, -0.5, 0.2, 0.7
    ],
  },
  {
    id: "talib_bat_pattern",
    name: "Bat Harmonic Pattern",
    nameFa: "الگوی هارمونیک خفاش (Bat Pattern)",
    category: "Harmonic",
    libraryOrigin: "Harmonic Quant",
    description: "Deep 0.886 D-point harmonic reversal structure offering high risk-to-reward inflection.",
    descriptionFa: "الگوی بازگشتی هارمونیک با نقطه D در تراز ۰.۸۸۶ فیبوناچی و نسبت سود به زیان بالا.",
    points: [
      -0.9, 0.7, 0.1, 0.45, -0.7, 0.1, 0.8
    ],
  },
  {
    id: "talib_three_white_soldiers",
    name: "Three White Soldiers (TA-Lib CDL)",
    nameFa: "سه سرباز سفید (TA-Lib CDL)",
    category: "Candlestick",
    libraryOrigin: "TA-Lib Standard",
    description: "Three consecutive long bullish candles opening within prior body and closing higher.",
    descriptionFa: "سه کندل متوالی پرقدرت صعودی که نشانه چرخش قاطع مومنتوم به نفع خریداران است.",
    points: [
      -0.8, -0.85, -0.6, -0.55, -0.1, -0.05, 0.4, 0.45, 0.9
    ],
  },
  {
    id: "talib_three_black_crows",
    name: "Three Black Crows (TA-Lib CDL)",
    nameFa: "سه کلاغ سیاه (TA-Lib CDL)",
    category: "Candlestick",
    libraryOrigin: "TA-Lib Standard",
    description: "Three consecutive long bearish candles opening within prior body and closing lower.",
    descriptionFa: "سه کندل متوالی پرقدرت نزولی که نشانه آغاز ریزش پایدار است.",
    points: [
      0.8, 0.85, 0.6, 0.55, 0.1, 0.05, -0.4, -0.45, -0.9
    ],
  },
  {
    id: "talib_morning_star",
    name: "Morning Star (TA-Lib CDL)",
    nameFa: "ستاره صبحگاهی (TA-Lib CDL)",
    category: "Candlestick",
    libraryOrigin: "TA-Lib Standard",
    description: "Three-candle bullish bottom reversal pattern: Long bear, indecision gap, strong bull candle.",
    descriptionFa: "الگوی ۳ کندلی بازگشت کف: کندل نزولی قوی، دوجی یا کندل ستاره کوچک، و کندل صعودی قدرتمند.",
    points: [
      0.6, 0.1, -0.5, -0.8, -0.85, -0.75, -0.2, 0.3, 0.75
    ],
  },
];

export const PRESET_PATTERNS = TALIB_STANDARD_PATTERNS;

export function convertTALibToMyDNA(preset: TALibPatternPreset): MyDNAPattern {
  const norm = normalizeShape(resampleSeries(preset.points, 80));
  return {
    id: preset.id,
    name: preset.name,
    category: preset.category,
    createdAt: "TA-Lib Standard",
    points: preset.points,
    normalizedPoints: norm,
    notes: `${preset.libraryOrigin}: ${preset.descriptionFa || preset.description}`,
  };
}
