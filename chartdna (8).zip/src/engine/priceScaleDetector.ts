/**
 * Price Scale Detector & Coordinate Calibration Engine
 * Analyzes the vertical price axis on the right or left edge of uncropped chart screenshots
 * and maps pixel heights to real financial prices.
 */

export interface PriceScaleLabel {
  y: number; // Y coordinate on the uncropped image
  price: number; // Detected price value
  rawText: string;
}

export interface PriceScaleCalibration {
  detected: boolean;
  side: "right" | "left" | "none";
  minScalePrice: number | null; // Price at the very bottom of the image
  maxScalePrice: number | null; // Price at the very top of the image
  currencySymbol?: string;
  decimals: number;
  priceLabels: PriceScaleLabel[];
  imageHeight: number;
  cropBox?: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
}

/**
 * Fast client-side regex and heuristic extractor for price strings
 */
export function parsePriceNumber(text: string): number | null {
  if (!text) return null;
  // Clean common noise characters from OCR
  let cleaned = text
    .replace(/[^\d.,kKmM]/g, "")
    .trim();

  if (!cleaned) return null;

  // Handle 'k' / 'K' suffixes (e.g. 65k -> 65000)
  const isK = /[kK]/.test(cleaned);
  cleaned = cleaned.replace(/[kK]/g, "");

  // Handle thousand separators vs decimal dots
  // Examples: "64,250.50", "1.08500", "2,350", "64.250,50"
  if (cleaned.includes(",") && cleaned.includes(".")) {
    if (cleaned.lastIndexOf(".") > cleaned.lastIndexOf(",")) {
      // Standard US: 64,250.50 -> 64250.50
      cleaned = cleaned.replace(/,/g, "");
    } else {
      // European: 64.250,50 -> 64250.50
      cleaned = cleaned.replace(/\./g, "").replace(",", ".");
    }
  } else if (cleaned.includes(",")) {
    // If only comma: check if it's 3 decimal digits or thousand separator
    const parts = cleaned.split(",");
    if (parts.length === 2 && parts[1].length !== 3) {
      cleaned = cleaned.replace(",", ".");
    } else {
      cleaned = cleaned.replace(/,/g, "");
    }
  }

  const num = parseFloat(cleaned);
  if (isNaN(num) || num <= 0 || !isFinite(num)) return null;

  return isK ? num * 1000 : num;
}

/**
 * Preprocesses scale canvas with multi-mode thresholding (normal & inverted)
 */
function createPreprocessedCanvases(
  sourceCanvas: HTMLCanvasElement,
  width: number,
  height: number
): HTMLCanvasElement[] {
  const ctx = sourceCanvas.getContext("2d");
  if (!ctx) return [sourceCanvas];

  const imgData = ctx.getImageData(0, 0, width, height);
  const data = imgData.data;

  // Calculate average luminance to see if chart is dark or light theme
  let totalLum = 0;
  for (let i = 0; i < data.length; i += 4) {
    totalLum += 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
  }
  const avgLum = totalLum / (data.length / 4);
  const isDarkTheme = avgLum < 128;

  // Canvas 1: High contrast tuned for theme
  const canvas1 = document.createElement("canvas");
  canvas1.width = width;
  canvas1.height = height;
  const ctx1 = canvas1.getContext("2d")!;
  const imgData1 = ctx1.createImageData(width, height);
  const d1 = imgData1.data;

  const threshold = isDarkTheme ? 90 : 160;

  for (let i = 0; i < data.length; i += 4) {
    const lum = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
    // Invert so text is always dark on white background for optimal OCR
    const isText = isDarkTheme ? lum > threshold : lum < threshold;
    const val = isText ? 0 : 255;
    d1[i] = val;
    d1[i + 1] = val;
    d1[i + 2] = val;
    d1[i + 3] = 255;
  }
  ctx1.putImageData(imgData1, 0, 0);

  return [canvas1, sourceCanvas];
}

/**
 * Detect price scale from an HTML5 Image Element using client-side canvas analysis
 */
export async function detectPriceScaleFromImage(
  img: HTMLImageElement
): Promise<PriceScaleCalibration> {
  const width = img.naturalWidth || img.width;
  const height = img.naturalHeight || img.height;

  if (width < 50 || height < 50) {
    return createEmptyCalibration(height);
  }

  try {
    // 1. We test both the right margin (up to 20% width) and left margin (up to 20% width)
    const rightStripWidth = Math.max(40, Math.min(220, Math.round(width * 0.20)));
    const rightStripX = width - rightStripWidth;

    const leftStripWidth = Math.max(40, Math.min(220, Math.round(width * 0.20)));
    const leftStripX = 0;

    // Offscreen canvas for right strip
    const canvasRight = document.createElement("canvas");
    canvasRight.width = rightStripWidth;
    canvasRight.height = height;
    const ctxRight = canvasRight.getContext("2d");

    if (ctxRight) {
      ctxRight.drawImage(img, rightStripX, 0, rightStripWidth, height, 0, 0, rightStripWidth, height);
    }

    // Try Tesseract OCR
    const Tesseract = (window as any).Tesseract || (await import("tesseract.js")).default || (await import("tesseract.js"));
    
    if (Tesseract && Tesseract.recognize) {
      try {
        const [processedRight] = createPreprocessedCanvases(canvasRight, rightStripWidth, height);

        const resRight = await Tesseract.recognize(processedRight, "eng", {
          tessedit_char_whitelist: "0123456789.,kK$€£¥-",
        } as any);

        const labelsRight = parseLabelsFromTesseract(resRight, 0);
        if (labelsRight.length >= 2) {
          return buildCalibrationFromLabels(labelsRight, height, "right");
        }

        // Try raw right strip if preprocessed was too aggressive
        const resRightRaw = await Tesseract.recognize(canvasRight, "eng", {
          tessedit_char_whitelist: "0123456789.,kK$€£¥-",
        } as any);
        const labelsRightRaw = parseLabelsFromTesseract(resRightRaw, 0);
        if (labelsRightRaw.length >= 2) {
          return buildCalibrationFromLabels(labelsRightRaw, height, "right");
        }

        // If right strip failed, try left strip (for MT4 or inverted charts)
        const canvasLeft = document.createElement("canvas");
        canvasLeft.width = leftStripWidth;
        canvasLeft.height = height;
        const ctxLeft = canvasLeft.getContext("2d");
        if (ctxLeft) {
          ctxLeft.drawImage(img, leftStripX, 0, leftStripWidth, height, 0, 0, leftStripWidth, height);
          const [processedLeft] = createPreprocessedCanvases(canvasLeft, leftStripWidth, height);
          const resLeft = await Tesseract.recognize(processedLeft, "eng", {
            tessedit_char_whitelist: "0123456789.,kK$€£¥-",
          } as any);
          const labelsLeft = parseLabelsFromTesseract(resLeft, 0);
          if (labelsLeft.length >= 2) {
            return buildCalibrationFromLabels(labelsLeft, height, "left");
          }
        }
      } catch (ocrErr) {
        console.warn("Tesseract OCR price scan fallback:", ocrErr);
      }
    }
  } catch (err) {
    console.warn("Price scale auto-detection skipped:", err);
  }

  return createEmptyCalibration(height);
}

/**
 * Parses word and line blocks from Tesseract OCR response
 */
function parseLabelsFromTesseract(ocrResult: any, yOffset: number): PriceScaleLabel[] {
  const labels: PriceScaleLabel[] = [];
  if (!ocrResult || !ocrResult.data) return labels;

  const lines = ocrResult.data.lines || [];
  for (const line of lines) {
    const text = (line.text || "").trim();
    const price = parsePriceNumber(text);
    if (price !== null && line.bbox) {
      const centerY = (line.bbox.y0 + line.bbox.y1) / 2 + yOffset;
      labels.push({
        y: centerY,
        price,
        rawText: text,
      });
    }
  }

  // Deduplicate and sort by vertical Y coordinate
  labels.sort((a, b) => a.y - b.y);

  // Filter out any obvious non-monotonic noise (price must decrease down the screen)
  const filtered: PriceScaleLabel[] = [];
  for (let i = 0; i < labels.length; i++) {
    if (filtered.length === 0) {
      filtered.push(labels[i]);
    } else {
      const prev = filtered[filtered.length - 1];
      if (labels[i].y - prev.y > 10 && labels[i].price < prev.price) {
        filtered.push(labels[i]);
      }
    }
  }

  return filtered;
}

/**
 * Builds linear price calibration from detected labels using linear regression
 */
export function buildCalibrationFromLabels(
  labels: PriceScaleLabel[],
  imageHeight: number,
  side: "right" | "left" = "right"
): PriceScaleCalibration {
  if (labels.length < 2) {
    return createEmptyCalibration(imageHeight);
  }

  // Linear Regression: Price = Slope * y + Intercept
  // On charts, as y increases (going down), price decreases, so Slope should be negative.
  let sumY = 0;
  let sumP = 0;
  let sumYY = 0;
  let sumYP = 0;
  const n = labels.length;

  for (const item of labels) {
    sumY += item.y;
    sumP += item.price;
    sumYY += item.y * item.y;
    sumYP += item.y * item.price;
  }

  const denominator = n * sumYY - sumY * sumY;
  let slope = 0;
  let intercept = 0;

  if (Math.abs(denominator) > 1e-6) {
    slope = (n * sumYP - sumY * sumP) / denominator;
    intercept = (sumP - slope * sumY) / n;
  } else {
    const first = labels[0];
    const last = labels[labels.length - 1];
    slope = (last.price - first.price) / (last.y - first.y || 1);
    intercept = first.price - slope * first.y;
  }

  // Price at y = 0 (top of image)
  const maxScalePrice = intercept;
  // Price at y = imageHeight (bottom of image)
  const minScalePrice = slope * imageHeight + intercept;

  if (maxScalePrice <= minScalePrice || isNaN(maxScalePrice) || isNaN(minScalePrice)) {
    return createEmptyCalibration(imageHeight);
  }

  // Determine decimal places from detected prices
  const strPrices = labels.map((l) => l.price.toString());
  let maxDecimals = 2;
  strPrices.forEach((sp) => {
    if (sp.includes(".")) {
      maxDecimals = Math.max(maxDecimals, sp.split(".")[1].length);
    }
  });

  return {
    detected: true,
    side,
    minScalePrice: Math.max(0, minScalePrice),
    maxScalePrice,
    decimals: Math.min(6, maxDecimals),
    priceLabels: labels,
    imageHeight,
  };
}

/**
 * Creates manual or fallback calibration with user-defined min/max price
 */
export function createManualCalibration(
  minPrice: number,
  maxPrice: number,
  imageHeight: number,
  side: "right" | "left" = "right"
): PriceScaleCalibration {
  return {
    detected: true,
    side,
    minScalePrice: minPrice,
    maxScalePrice: maxPrice,
    decimals: maxPrice > 100 ? 2 : 4,
    priceLabels: [
      { y: 0, price: maxPrice, rawText: maxPrice.toString() },
      { y: imageHeight, price: minPrice, rawText: minPrice.toString() },
    ],
    imageHeight,
  };
}

export function createEmptyCalibration(imageHeight: number = 600): PriceScaleCalibration {
  return {
    detected: false,
    side: "none",
    minScalePrice: null,
    maxScalePrice: null,
    decimals: 2,
    priceLabels: [],
    imageHeight,
  };
}

/**
 * Maps a relative point inside a crop box to the real dollar / unit price
 */
export function calculateRealPriceForPoint(
  normalizedPointValue: number, // between minVal and maxVal in the extracted curve
  minCurveVal: number,
  maxCurveVal: number,
  cropBox: { x: number; y: number; width: number; height: number } | null,
  calibration: PriceScaleCalibration | null
): number | null {
  if (!calibration || !calibration.detected || calibration.minScalePrice === null || calibration.maxScalePrice === null) {
    return null;
  }

  const imageHeight = calibration.imageHeight || 600;
  const totalScaleRange = calibration.maxScalePrice - calibration.minScalePrice;

  if (totalScaleRange <= 0) return null;

  if (!cropBox) {
    // If no crop box, map curve directly across whole image height
    const t = (normalizedPointValue - minCurveVal) / (maxCurveVal - minCurveVal || 1);
    return calibration.minScalePrice + t * totalScaleRange;
  }

  // With Crop Box:
  // In the crop box, the top is at y = cropBox.y, bottom is at y = cropBox.y + cropBox.height
  // normalizedPointValue: highest curve value is at the top of the crop box
  const t = (normalizedPointValue - minCurveVal) / (maxCurveVal - minCurveVal || 1); // 0 (bottom) to 1 (top of crop)
  const yPixelInImage = cropBox.y + (1 - t) * cropBox.height;

  // Linear mapping from image yPixel to price (y=0 -> maxPrice, y=imageHeight -> minPrice)
  const yRatio = Math.max(0, Math.min(1, yPixelInImage / imageHeight));
  const realPrice = calibration.maxScalePrice - yRatio * totalScaleRange;

  return realPrice;
}

/**
 * Format real price neatly (e.g. 64,250.50 or 1.0845)
 */
export function formatRealPrice(price: number | null | undefined, decimals: number = 2): string {
  if (price === null || price === undefined || isNaN(price)) return "";
  return price.toLocaleString(undefined, {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}
