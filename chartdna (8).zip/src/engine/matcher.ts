import { normalizeShape, resampleSeries } from "./normalizer";
import { combinedSimilarity } from "./similarity";
import {
  Candle,
  MarketDataset,
  MatchResult,
  SearchConfig,
  TrendBreakdown,
  MyDNAPattern,
  CustomPatternMatch,
  FutureExtremum,
} from "./types";

export class PatternMatcher {
  /**
   * Extracts up to 4 significant swing peaks and valleys from future candles
   */
  /**
   * Identifies true Swing Highs (Peaks) and Swing Lows (Valleys) using a
   * Zigzag Wave segmentation algorithm:
   * - Peak: Highest apex after an upward price run and before a downward swing.
   * - Valley: Lowest trough after a downward price run and before an upward swing.
   * - Strict wave alternation: Peak <-> Valley <-> Peak <-> Valley
   */
  public static extractZigzagSwings(
    futureCandlesSlice: Candle[],
    basePrice: number
  ): {
    futureExtrema: FutureExtremum[];
    futurePeaks: FutureExtremum[];
    futureValleys: FutureExtremum[];
  } {
    if (!futureCandlesSlice || futureCandlesSlice.length === 0 || basePrice <= 0) {
      return { futureExtrema: [], futurePeaks: [], futureValleys: [] };
    }

    const n = futureCandlesSlice.length;
    // Build price series including base point (candle 0 = basePrice)
    const highs = [basePrice, ...futureCandlesSlice.map((c) => (c.high !== undefined ? c.high : c.close))];
    const lows = [basePrice, ...futureCandlesSlice.map((c) => (c.low !== undefined ? c.low : c.close))];

    // Calculate dynamic threshold based on volatility / range of future candles
    let totalRange = 0;
    for (let i = 1; i <= n; i++) {
      totalRange += Math.abs(highs[i] - lows[i]);
    }
    const avgBarRange = n > 0 ? totalRange / n : basePrice * 0.005;
    const minSwingDelta = Math.max(avgBarRange * 0.4, basePrice * 0.001);

    // Multi-pass pivot identification:
    // Pass 1: Identify local fractal pivots (where High >= neighbors, or Low <= neighbors)
    interface RawPivot {
      candleIndex: number; // 1-based (1 to n)
      type: "peak" | "valley";
      price: number;
      timestamp?: string;
    }

    const rawPivots: RawPivot[] = [];

    for (let i = 1; i <= n; i++) {
      const cHigh = highs[i];
      const cLow = lows[i];
      const prevHigh = highs[i - 1];
      const nextHigh = i < n ? highs[i + 1] : -Infinity;
      const prevLow = lows[i - 1];
      const nextLow = i < n ? lows[i + 1] : Infinity;

      const isLocalHigh = cHigh >= prevHigh && (i === n || cHigh >= nextHigh) && cHigh > lows[i - 1];
      const isLocalLow = cLow <= prevLow && (i === n || cLow <= nextLow) && cLow < highs[i - 1];

      if (isLocalHigh && (!isLocalLow || cHigh - basePrice >= basePrice - cLow)) {
        rawPivots.push({
          candleIndex: i,
          type: "peak",
          price: cHigh,
          timestamp: futureCandlesSlice[i - 1]?.timestamp,
        });
      } else if (isLocalLow) {
        rawPivots.push({
          candleIndex: i,
          type: "valley",
          price: cLow,
          timestamp: futureCandlesSlice[i - 1]?.timestamp,
        });
      }
    }

    // Pass 2: Zigzag wave alternation & apex tracking
    const zigzag: RawPivot[] = [];

    for (const pivot of rawPivots) {
      if (zigzag.length === 0) {
        if (Math.abs(pivot.price - basePrice) >= minSwingDelta * 0.3) {
          zigzag.push(pivot);
        }
        continue;
      }

      const last = zigzag[zigzag.length - 1];

      if (pivot.type === last.type) {
        // Same type in a row: retain the true summit / floor
        if (pivot.type === "peak") {
          if (pivot.price > last.price) {
            zigzag[zigzag.length - 1] = pivot; // Higher high in ongoing upward wave
          }
        } else {
          if (pivot.price < last.price) {
            zigzag[zigzag.length - 1] = pivot; // Lower low in ongoing downward wave
          }
        }
      } else {
        // Alternating wave transition: check swing delta
        const delta = Math.abs(pivot.price - last.price);
        if (delta >= minSwingDelta * 0.3) {
          zigzag.push(pivot);
        }
      }
    }

    // Ensure global extremes are represented if missing
    let maxHigh = -Infinity;
    let maxHighIdx = -1;
    let minLow = Infinity;
    let minLowIdx = -1;

    for (let i = 1; i <= n; i++) {
      if (highs[i] > maxHigh) {
        maxHigh = highs[i];
        maxHighIdx = i;
      }
      if (lows[i] < minLow) {
        minLow = lows[i];
        minLowIdx = i;
      }
    }

    if (maxHighIdx > 0 && maxHigh > basePrice && !zigzag.some((z) => z.type === "peak" && z.candleIndex === maxHighIdx)) {
      zigzag.push({
        candleIndex: maxHighIdx,
        type: "peak",
        price: maxHigh,
        timestamp: futureCandlesSlice[maxHighIdx - 1]?.timestamp,
      });
    }

    if (minLowIdx > 0 && minLow < basePrice && !zigzag.some((z) => z.type === "valley" && z.candleIndex === minLowIdx)) {
      zigzag.push({
        candleIndex: minLowIdx,
        type: "valley",
        price: minLow,
        timestamp: futureCandlesSlice[minLowIdx - 1]?.timestamp,
      });
    }

    // Sort chronologically
    zigzag.sort((a, b) => a.candleIndex - b.candleIndex);

    // Final clean-up: enforce strict alternation in the sorted sequence
    const cleanZigzag: RawPivot[] = [];
    for (const item of zigzag) {
      if (cleanZigzag.length === 0) {
        cleanZigzag.push(item);
        continue;
      }
      const last = cleanZigzag[cleanZigzag.length - 1];
      if (last.type === item.type) {
        if (item.type === "peak" && item.price > last.price) {
          cleanZigzag[cleanZigzag.length - 1] = item;
        } else if (item.type === "valley" && item.price < last.price) {
          cleanZigzag[cleanZigzag.length - 1] = item;
        }
      } else {
        cleanZigzag.push(item);
      }
    }

    const peaks: FutureExtremum[] = cleanZigzag
      .filter((z) => z.type === "peak")
      .slice(0, 4)
      .map((z) => ({
        type: "peak",
        candleIndex: z.candleIndex,
        historicalPrice: z.price,
        percentChange: basePrice > 0 ? ((z.price - basePrice) / basePrice) * 100 : 0,
        timestamp: z.timestamp,
      }));

    const valleys: FutureExtremum[] = cleanZigzag
      .filter((z) => z.type === "valley")
      .slice(0, 4)
      .map((z) => ({
        type: "valley",
        candleIndex: z.candleIndex,
        historicalPrice: z.price,
        percentChange: basePrice > 0 ? ((z.price - basePrice) / basePrice) * 100 : 0,
        timestamp: z.timestamp,
      }));

    const combined: FutureExtremum[] = cleanZigzag
      .slice(0, 4)
      .map((z) => ({
        type: z.type,
        candleIndex: z.candleIndex,
        historicalPrice: z.price,
        percentChange: basePrice > 0 ? ((z.price - basePrice) / basePrice) * 100 : 0,
        timestamp: z.timestamp,
      }));

    return {
      futureExtrema: combined,
      futurePeaks: peaks,
      futureValleys: valleys,
    };
  }

  public static extractFutureExtrema(
    futureCandlesSlice: Candle[],
    basePrice: number
  ): FutureExtremum[] {
    return this.extractZigzagSwings(futureCandlesSlice, basePrice).futureExtrema;
  }

  public static extractFutureExtremaDetails(
    futureCandlesSlice: Candle[],
    basePrice: number
  ): {
    futureExtrema: FutureExtremum[];
    futurePeaks: FutureExtremum[];
    futureValleys: FutureExtremum[];
  } {
    return this.extractZigzagSwings(futureCandlesSlice, basePrice);
  }

  /**
   * Scans a single market dataset for pattern matches using sliding window.
   */
  public static findMatchesInDataset(
    referencePattern: number[],
    dataset: MarketDataset,
    config: SearchConfig,
    onProgress?: (progressPercent: number, statusText: string) => void,
    shouldStop?: () => boolean
  ): MatchResult[] {
    const { threshold, futureCandles, patternLength, skipOverlap, weights, rangeTolerance = 1.0 } = config;
    const candles = dataset.candles;
    const requiredLength = patternLength + futureCandles;

    if (candles.length < requiredLength || referencePattern.length < 5) {
      return [];
    }

    // Resample reference pattern to the search pattern length and normalize
    const resampledRef = resampleSeries(referencePattern, patternLength);
    const normalizedRef = normalizeShape(resampledRef);

    const closePrices = candles.map((c) => c.close);
    const maxStart = candles.length - requiredLength;
    const matches: MatchResult[] = [];

    // Scan step (optimized for long series)
    const scanStep = 1;
    let lastMatchedEnd = -1;

    const progressEvery = Math.max(10, Math.floor(maxStart / 20));

    for (let i = 0; i <= maxStart; i += scanStep) {
      if (shouldStop && shouldStop()) {
        break;
      }

      if (i % progressEvery === 0 && onProgress) {
        const percent = Math.min(100, Math.round((i / maxStart) * 100));
        onProgress(percent, `Scanning ${dataset.name} (${i}/${maxStart} windows)`);
      }

      // Skip overlapping windows if match was already found nearby
      if (skipOverlap && i < lastMatchedEnd) {
        continue;
      }

      const windowSlice = closePrices.slice(i, i + patternLength);
      const normalizedWindow = normalizeShape(windowSlice);

      const simScore = combinedSimilarity(normalizedRef, normalizedWindow, weights);
      const simPercent = simScore * 100;

      if (simPercent >= threshold) {
        const endIndex = i + patternLength - 1;
        const futureSlice = closePrices.slice(i + patternLength, i + requiredLength);
        const futureCandlesSlice = candles.slice(i + patternLength, i + requiredLength);
        const trend = this.classifyTrend(windowSlice, futureSlice, rangeTolerance);

        const histStartPrice = candles[i]?.open !== undefined ? candles[i].open : windowSlice[0];
        const histEndPrice = candles[endIndex]?.close !== undefined ? candles[endIndex].close : windowSlice[windowSlice.length - 1];

        // Extract the 4 key future extrema (peaks & valleys)
        const { futureExtrema, futurePeaks, futureValleys } = this.extractFutureExtremaDetails(
          futureCandlesSlice,
          histEndPrice
        );

        matches.push({
          rank: 0, // Assigned later
          datasetId: dataset.id,
          fileName: dataset.name,
          symbol: dataset.symbol || dataset.name,
          timeframe: dataset.timeframe || "M1",
          startIndex: i,
          endIndex: endIndex,
          startTime: candles[i]?.timestamp || String(i),
          endTime: candles[endIndex]?.timestamp || String(endIndex),
          similarity: simPercent,
          pattern: windowSlice,
          future: futureSlice,
          trend: trend,
          rawMatchIndices: { start: i, end: endIndex },
          historicalStartPrice: histStartPrice,
          historicalEndPrice: histEndPrice,
          futureExtrema,
          futurePeaks,
          futureValleys,
        });

        if (skipOverlap) {
          lastMatchedEnd = i + Math.floor(patternLength * 0.5);
        }
      }
    }

    return matches;
  }

  /**
   * Scans multiple datasets, sorts and ranks top matches.
   */
  public static async analyzeMultiDatasets(
    referencePattern: number[],
    datasets: MarketDataset[],
    config: SearchConfig,
    onProgress?: (progressPercent: number, message: string) => void,
    shouldStop?: () => boolean
  ): Promise<MatchResult[]> {
    if (datasets.length === 0) return [];

    let allMatches: MatchResult[] = [];
    const totalDatasets = datasets.length;

    for (let idx = 0; idx < totalDatasets; idx++) {
      if (shouldStop && shouldStop()) break;

      const dataset = datasets[idx];
      const startPct = (idx / totalDatasets) * 100;
      const endPct = ((idx + 1) / totalDatasets) * 100;

      const datasetMatches = this.findMatchesInDataset(
        referencePattern,
        dataset,
        config,
        (innerPct, status) => {
          if (onProgress) {
            const overallPct = startPct + ((endPct - startPct) * innerPct) / 100;
            onProgress(Math.min(99, Math.round(overallPct)), status);
          }
        },
        shouldStop
      );

      allMatches = allMatches.concat(datasetMatches);

      // Yield control briefly to keep UI responsive
      await new Promise((r) => setTimeout(r, 0));
    }

    // Sort descending by similarity
    allMatches.sort((a, b) => b.similarity - a.similarity);

    // Limit to top results and assign ranks
    const topMatches = allMatches.slice(0, config.topResults);
    topMatches.forEach((m, i) => {
      m.rank = i + 1;
    });

    if (onProgress) {
      onProgress(100, `Analysis complete. Found ${topMatches.length} pattern matches.`);
    }

    return topMatches;
  }

  /**
   * Classifies post-pattern trend (Up / Down / Range)
   * purely based on the net percentage change of future price relative to pattern end price
   * compared to the user's range tolerance percentage (0% to 30%).
   */
  public static classifyTrend(
    pattern: number[],
    future: number[],
    rangeTolerance: number = 1.0
  ): "up" | "down" | "range" {
    if (!pattern.length || !future.length) return "range";

    const lastPatternPrice = pattern[pattern.length - 1];
    if (lastPatternPrice <= 0) return "range";

    const futureFinalPrice = future[future.length - 1];
    const netPercentChange = ((futureFinalPrice - lastPatternPrice) / lastPatternPrice) * 100;
    const tolerance = Math.max(0, rangeTolerance ?? 0);

    // If tolerance is 0 or price change is within [-tolerance%, +tolerance%], classify as range
    if (tolerance > 0 && Math.abs(netPercentChange) <= tolerance) {
      return "range";
    }

    if (netPercentChange > tolerance) {
      return "up";
    } else if (netPercentChange < -tolerance) {
      return "down";
    }

    return "range";
  }

  /**
   * Computes percentage breakdown of Bullish, Bearish, and Range results.
   */
  public static computeTrendBreakdown(results: MatchResult[]): TrendBreakdown {
    let up = 0;
    let down = 0;
    let range = 0;

    for (const r of results) {
      if (r.trend === "up") up++;
      else if (r.trend === "down") down++;
      else range++;
    }

    const total = results.length;
    if (total === 0) {
      return {
        pctUp: 0,
        pctDown: 0,
        pctRange: 0,
        countUp: 0,
        countDown: 0,
        countRange: 0,
        total: 0,
      };
    }

    return {
      pctUp: (up / total) * 100,
      pctDown: (down / total) * 100,
      pctRange: (range / total) * 100,
      countUp: up,
      countDown: down,
      countRange: range,
      total: total,
    };
  }

  /**
   * Compares the reference pattern with the user's custom saved patterns library
   */
  public static findMatchesInCustomPatterns(
    referencePattern: number[],
    savedPatterns: MyDNAPattern[],
    config: SearchConfig
  ): CustomPatternMatch[] {
    if (!referencePattern || referencePattern.length < 5 || savedPatterns.length === 0) {
      return [];
    }

    const { weights, threshold } = config;
    const resampledRef = resampleSeries(referencePattern, 60);
    const normalizedRef = normalizeShape(resampledRef);

    const matches: CustomPatternMatch[] = [];

    for (const pat of savedPatterns) {
      const rawPoints = pat.normalizedPoints || pat.points;
      if (!rawPoints || rawPoints.length < 5) continue;

      const resampledPat = resampleSeries(rawPoints, 60);
      const normalizedPat = normalizeShape(resampledPat);

      const simScore = combinedSimilarity(normalizedRef, normalizedPat, weights);
      const simPercent = Math.round(simScore * 1000) / 10; // e.g. 92.4%

      // Slope and trend of the custom pattern
      const slope = normalizedPat[normalizedPat.length - 1] - normalizedPat[0];
      const trend: "up" | "down" | "range" = slope > 0.25 ? "up" : slope < -0.25 ? "down" : "range";

      // If matches above a relaxed threshold (or min 60% for user patterns)
      const minThresh = Math.min(threshold, 60);
      if (simPercent >= minThresh) {
        matches.push({
          patternId: pat.id,
          name: pat.name,
          category: pat.category,
          similarity: simPercent,
          trend: trend,
          points: rawPoints,
          notes: pat.notes,
          createdAt: pat.createdAt,
        });
      }
    }

    // Sort descending by similarity
    matches.sort((a, b) => b.similarity - a.similarity);
    return matches;
  }
}
