export interface Candle {
  timestamp: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

export interface MarketDataset {
  id: string;
  name: string;
  symbol: string;
  timeframe: string;
  candles: Candle[];
}

export interface FutureExtremum {
  type: "peak" | "valley";
  candleIndex: number; // offset after pattern end (e.g. 1 for next candle, 4 for 4th candle)
  historicalPrice: number;
  percentChange: number; // percentage change relative to pattern end price
  timestamp?: string;
  projectedPrice?: number; // calculated if reference price is provided
}

export interface MatchResult {
  rank: number;
  datasetId?: string;
  fileName: string;
  symbol: string;
  timeframe: string;
  startIndex: number;
  endIndex: number;
  startTime: string;
  endTime: string;
  similarity: number; // 0 to 100 percentage
  pattern: number[];
  future: number[];
  trend: "up" | "down" | "range";
  rawMatchIndices?: { start: number; end: number };
  historicalStartPrice?: number;
  historicalEndPrice?: number;
  futureExtrema?: FutureExtremum[]; // 4 major future peaks and valleys
  futurePeaks?: FutureExtremum[]; // 4 future peaks
  futureValleys?: FutureExtremum[]; // 4 future valleys
}

export interface SimilarityWeights {
  pearson: number;
  dtw: number;
  slope: number;
  structural: number;
}

export interface SearchConfig {
  threshold: number; // 70 to 100
  futureCandles: number; // e.g. 20 (after pattern)
  beforeCandles?: number; // e.g. 40 (before pattern for chart view)
  patternLength: number; // e.g. 60
  extractorPointCount?: number; // e.g. 80, 500, or user-selected points for image extraction & curve resolution
  topResults: number; // e.g. 50
  rangeTolerance: number; // 0% to 30% (e.g. 1.0%)
  rangeLookback?: number; // legacy optional
  skipOverlap: boolean;
  weights: SimilarityWeights;
  includeCustomPatterns?: boolean;
}

export interface CustomPatternMatch {
  patternId: string;
  name: string;
  category?: string;
  similarity: number; // 0 to 100 percentage
  trend: "up" | "down" | "range";
  points: number[];
  notes?: string;
  createdAt?: string;
}

export interface MyDNAPattern {
  id: string;
  name: string;
  category?: string;
  createdAt: string;
  points: number[];
  normalizedPoints: number[];
  previewSvg?: string;
  notes?: string;
}

export interface TrendBreakdown {
  pctUp: number;
  pctDown: number;
  pctRange: number;
  countUp: number;
  countDown: number;
  countRange: number;
  total: number;
}

export interface CandleWindowData {
  fileName: string;
  symbol: string;
  timeframe: string;
  beforeCount: number;
  afterCount: number;
  patternStart: number;
  patternEnd: number;
  timestamps: string[];
  open: number[];
  high: number[];
  low: number[];
  close: number[];
  volume?: number[];
}
