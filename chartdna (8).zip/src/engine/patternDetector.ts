/**
 * Peak and Valley detection & Structural similarity matching.
 * Ported from engine_core/pattern_detector.py
 */

export interface TurningPoint {
  index: number;
  value: number;
  type: "peak" | "valley";
}

export function findPeaksAndValleys(series: number[], order: number = 3): { peaks: number[]; valleys: number[] } {
  const peaks: number[] = [];
  const valleys: number[] = [];
  const n = series.length;

  if (n < 2 * order + 1) {
    return { peaks, valleys };
  }

  for (let i = order; i < n - order; i++) {
    const current = series[i];
    let isPeak = true;
    let isValley = true;

    for (let j = 1; j <= order; j++) {
      if (series[i - j] >= current || series[i + j] >= current) {
        isPeak = false;
      }
      if (series[i - j] <= current || series[i + j] <= current) {
        isValley = false;
      }
    }

    if (isPeak) peaks.push(i);
    if (isValley) valleys.push(i);
  }

  return { peaks, valleys };
}

export function keyTurningPoints(series: number[], order: number = 3): TurningPoint[] {
  const { peaks, valleys } = findPeaksAndValleys(series, order);
  const points: TurningPoint[] = [];

  for (const idx of peaks) {
    points.push({ index: idx, value: series[idx], type: "peak" });
  }
  for (const idx of valleys) {
    points.push({ index: idx, value: series[idx], type: "valley" });
  }

  return points.sort((a, b) => a.index - b.index);
}

export function structuralSimilarity(p1: number[], p2: number[]): number {
  if (!p1.length || !p2.length) return 0;

  const points1 = keyTurningPoints(p1, Math.max(2, Math.floor(p1.length / 15)));
  const points2 = keyTurningPoints(p2, Math.max(2, Math.floor(p2.length / 15)));

  if (points1.length === 0 && points2.length === 0) return 0.95; // both flat/smooth
  if (points1.length === 0 || points2.length === 0) return 0.3;

  // Compare structural sequence of types
  const seq1 = points1.map((p) => (p.type === "peak" ? 1 : -1));
  const seq2 = points2.map((p) => (p.type === "peak" ? 1 : -1));

  // Count type matches
  const minLen = Math.min(seq1.length, seq2.length);
  const maxLen = Math.max(seq1.length, seq2.length);
  let matches = 0;

  for (let i = 0; i < minLen; i++) {
    if (seq1[i] === seq2[i]) matches++;
  }

  const sequenceScore = matches / maxLen;
  const countRatio = minLen / maxLen;

  return 0.6 * sequenceScore + 0.4 * countRatio;
}
