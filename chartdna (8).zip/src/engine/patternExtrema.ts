import {
  PriceScaleCalibration,
  calculateRealPriceForPoint,
} from "./priceScaleDetector";

export interface PatternExtremum {
  index: number;
  value: number;
  percentFromCurrent: number; // Percent relative to current market price (pattern end)
  percentFromStart: number;   // Backward compatibility
  type: "peak" | "valley";
  isMajor: boolean;
  label: string;
  labelFa: string;
  realPrice?: number | null; // Real price in currency/units calculated with reference price
  realDifferenceFromCurrent?: number | null; // Price change in real units from current price
}

export interface PatternExtremaAnalysis {
  pattern: number[];
  relativeCoords?: { relX: number; relY: number }[];
  minPrice: number;
  maxPrice: number;
  peaks: PatternExtremum[];
  valleys: PatternExtremum[];
  highestPeak: PatternExtremum | null;
  lowestValley: PatternExtremum | null;
  currentPrice: number;
  startPrice: number;
  totalRange: number;
  totalRangePercent: number;
  isRealPriceAvailable: boolean;
  realCurrentPrice?: number | null;
  realStartPrice?: number | null;
  realMaxPrice?: number | null;
  realMinPrice?: number | null;
  decimals: number;
}

export interface ForwardScenarioTarget {
  label: string;
  labelFa: string;
  targetPrice: number;
  percentChange: number;
  type: "bullish_target" | "bearish_target" | "range_bound";
  confidence: number;
  realPrice?: number | null; // Exact real dollar/currency price
  realPriceDifference?: number | null;
}

export interface ForwardScenarioAnalysis {
  isRealPriceAvailable: boolean;
  decimals: number;
  bullish: {
    target1: ForwardScenarioTarget;
    target2: ForwardScenarioTarget;
    avgGainPercent: number;
    maxGainPercent: number;
  };
  bearish: {
    support1: ForwardScenarioTarget;
    support2: ForwardScenarioTarget;
    avgDropPercent: number;
    maxDropPercent: number;
  };
  range: {
    upperBound: number;
    lowerBound: number;
    upperPercent: number;
    lowerPercent: number;
    channelWidthPercent: number;
    upperRealPrice?: number | null;
    lowerRealPrice?: number | null;
    channelWidthRealAmount?: number | null;
  };
}

/**
 * Extract peaks and valleys from 1D reference pattern, mapping to real prices based strictly on current market price
 */
export function extractPatternExtrema(
  pattern: number[],
  cropBox?: { x: number; y: number; width: number; height: number } | null,
  calibration?: PriceScaleCalibration | null,
  relativeCoords?: { relX: number; relY: number }[] | null,
  overrideReferencePrice?: number | null
): PatternExtremaAnalysis {
  if (!pattern || pattern.length === 0) {
    return {
      pattern: [],
      relativeCoords: relativeCoords || undefined,
      minPrice: 0,
      maxPrice: 0,
      peaks: [],
      valleys: [],
      highestPeak: null,
      lowestValley: null,
      currentPrice: 0,
      startPrice: 0,
      totalRange: 0,
      totalRangePercent: 0,
      isRealPriceAvailable: false,
      decimals: 2,
    };
  }

  const n = pattern.length;
  const startPrice = pattern[0];
  const currentPrice = pattern[n - 1]; // Current market price at the end of the chart

  let minVal = pattern[0];
  let maxVal = pattern[0];
  let minIdx = 0;
  let maxIdx = 0;

  for (let i = 0; i < n; i++) {
    if (pattern[i] < minVal) {
      minVal = pattern[i];
      minIdx = i;
    }
    if (pattern[i] > maxVal) {
      maxVal = pattern[i];
      maxIdx = i;
    }
  }

  const totalRange = maxVal - minVal;
  const baselineCurrent = Math.abs(currentPrice) > 1e-6 ? Math.abs(currentPrice) : 1;
  const totalRangePercent = (totalRange / baselineCurrent) * 100;

  const isOCRDetected = !!(
    calibration &&
    calibration.detected &&
    calibration.minScalePrice !== null &&
    calibration.maxScalePrice !== null
  );

  const ocrCurrentPrice = isOCRDetected
    ? calculateRealPriceForPoint(currentPrice, minVal, maxVal, cropBox || null, calibration || null)
    : null;
  const ocrStartPrice = isOCRDetected
    ? calculateRealPriceForPoint(startPrice, minVal, maxVal, cropBox || null, calibration || null)
    : null;
  const ocrMaxPrice = isOCRDetected
    ? calculateRealPriceForPoint(maxVal, minVal, maxVal, cropBox || null, calibration || null)
    : null;
  const ocrMinPrice = isOCRDetected
    ? calculateRealPriceForPoint(minVal, minVal, maxVal, cropBox || null, calibration || null)
    : null;

  const hasManualRef = overrideReferencePrice != null && overrideReferencePrice > 0;
  const effectiveRefPrice = hasManualRef ? overrideReferencePrice! : ocrCurrentPrice;
  const isRealPriceAvailable = effectiveRefPrice != null && effectiveRefPrice > 0;

  const decimals = hasManualRef
    ? overrideReferencePrice! < 10
      ? 4
      : overrideReferencePrice! < 1000
      ? 2
      : 2
    : calibration?.decimals ?? 2;

  // Helper to get real price and percentage from CURRENT price for any point in the pattern
  const computePointMetrics = (val: number) => {
    let pctFromCurrent = 0;
    let ptRealPrice: number | null = null;

    if (isOCRDetected && ocrCurrentPrice !== null && ocrCurrentPrice > 0) {
      const ptOCR = calculateRealPriceForPoint(val, minVal, maxVal, cropBox || null, calibration || null);
      if (ptOCR !== null) {
        pctFromCurrent = ((ptOCR - ocrCurrentPrice) / ocrCurrentPrice) * 100;
        ptRealPrice = hasManualRef ? overrideReferencePrice! * (1 + pctFromCurrent / 100) : ptOCR;
      }
    } else if (hasManualRef) {
      // Scale relative to current point on the pattern
      if (currentPrice > 10) {
        pctFromCurrent = ((val - currentPrice) / currentPrice) * 100;
      } else {
        const span = maxVal - minVal || 1;
        const normRatio = (val - currentPrice) / span;
        pctFromCurrent = normRatio * (cropBox ? (cropBox.height / (calibration?.imageHeight || 600)) * 8 : 5);
      }
      ptRealPrice = overrideReferencePrice! * (1 + pctFromCurrent / 100);
    } else {
      pctFromCurrent = currentPrice !== 0 ? ((val - currentPrice) / baselineCurrent) * 100 : 0;
      ptRealPrice = null;
    }

    const pctFromStart = startPrice !== 0 ? ((val - startPrice) / Math.abs(startPrice)) * 100 : 0;
    const diffFromCurrent =
      ptRealPrice !== null && effectiveRefPrice !== null ? ptRealPrice - effectiveRefPrice : null;

    return {
      pctFromCurrent,
      pctFromStart,
      ptRealPrice,
      diffFromCurrent,
    };
  };

  const realCurrentPrice = effectiveRefPrice;
  const realStartPrice = computePointMetrics(startPrice).ptRealPrice ?? ocrStartPrice;
  const realMaxPrice = computePointMetrics(maxVal).ptRealPrice ?? ocrMaxPrice;
  const realMinPrice = computePointMetrics(minVal).ptRealPrice ?? ocrMinPrice;

  // Window radius for local extrema detection (adaptive based on pattern length)
  const radius = Math.max(1, Math.floor(n / 12));
  const peaks: PatternExtremum[] = [];
  const valleys: PatternExtremum[] = [];

  for (let i = 0; i < n; i++) {
    const val = pattern[i];
    const left = Math.max(0, i - radius);
    const right = Math.min(n - 1, i + radius);

    let isPeak = true;
    let isValley = true;

    for (let j = left; j <= right; j++) {
      if (j === i) continue;
      if (pattern[j] >= val) isPeak = false;
      if (pattern[j] <= val) isValley = false;
    }

    const metrics = computePointMetrics(val);

    if (isPeak) {
      const isMajor = i === maxIdx || Math.abs(val - maxVal) < 0.15 * totalRange;
      peaks.push({
        index: i,
        value: val,
        percentFromCurrent: metrics.pctFromCurrent,
        percentFromStart: metrics.pctFromStart,
        type: "peak",
        isMajor,
        label: `Peak @ #${i + 1}`,
        labelFa: `سقف نقطه ${i + 1}`,
        realPrice: metrics.ptRealPrice,
        realDifferenceFromCurrent: metrics.diffFromCurrent,
      });
    }

    if (isValley) {
      const isMajor = i === minIdx || Math.abs(val - minVal) < 0.15 * totalRange;
      valleys.push({
        index: i,
        value: val,
        percentFromCurrent: metrics.pctFromCurrent,
        percentFromStart: metrics.pctFromStart,
        type: "valley",
        isMajor,
        label: `Valley @ #${i + 1}`,
        labelFa: `کف نقطه ${i + 1}`,
        realPrice: metrics.ptRealPrice,
        realDifferenceFromCurrent: metrics.diffFromCurrent,
      });
    }
  }

  // Ensure absolute highest and lowest are always included
  if (!peaks.some((p) => p.index === maxIdx)) {
    const maxMetrics = computePointMetrics(maxVal);
    peaks.push({
      index: maxIdx,
      value: maxVal,
      percentFromCurrent: maxMetrics.pctFromCurrent,
      percentFromStart: maxMetrics.pctFromStart,
      type: "peak",
      isMajor: true,
      label: `Highest Peak @ #${maxIdx + 1}`,
      labelFa: `بالاترین سقف (نقطه ${maxIdx + 1})`,
      realPrice: realMaxPrice,
      realDifferenceFromCurrent: maxMetrics.diffFromCurrent,
    });
  }

  if (!valleys.some((v) => v.index === minIdx)) {
    const minMetrics = computePointMetrics(minVal);
    valleys.push({
      index: minIdx,
      value: minVal,
      percentFromCurrent: minMetrics.pctFromCurrent,
      percentFromStart: minMetrics.pctFromStart,
      type: "valley",
      isMajor: true,
      label: `Lowest Trough @ #${minIdx + 1}`,
      labelFa: `پایین‌ترین کف (نقطه ${minIdx + 1})`,
      realPrice: realMinPrice,
      realDifferenceFromCurrent: minMetrics.diffFromCurrent,
    });
  }

  peaks.sort((a, b) => a.index - b.index);
  valleys.sort((a, b) => a.index - b.index);

  const highestMetrics = computePointMetrics(maxVal);
  const lowestMetrics = computePointMetrics(minVal);

  const highestPeak: PatternExtremum = {
    index: maxIdx,
    value: maxVal,
    percentFromCurrent: highestMetrics.pctFromCurrent,
    percentFromStart: highestMetrics.pctFromStart,
    type: "peak",
    isMajor: true,
    label: `Major Peak`,
    labelFa: `سقف ماژور`,
    realPrice: realMaxPrice,
    realDifferenceFromCurrent: highestMetrics.diffFromCurrent,
  };

  const lowestValley: PatternExtremum = {
    index: minIdx,
    value: minVal,
    percentFromCurrent: lowestMetrics.pctFromCurrent,
    percentFromStart: lowestMetrics.pctFromStart,
    type: "valley",
    isMajor: true,
    label: `Major Valley`,
    labelFa: `کف ماژور`,
    realPrice: realMinPrice,
    realDifferenceFromCurrent: lowestMetrics.diffFromCurrent,
  };

  return {
    pattern,
    relativeCoords: relativeCoords || undefined,
    minPrice: minVal,
    maxPrice: maxVal,
    peaks,
    valleys,
    highestPeak,
    lowestValley,
    currentPrice,
    startPrice,
    totalRange,
    totalRangePercent,
    isRealPriceAvailable,
    realCurrentPrice,
    realStartPrice,
    realMaxPrice,
    realMinPrice,
    decimals,
  };
}

/**
 * Calculate Forward Scenario Projections (Bullish, Bearish, Range targets)
 * with real currency numbers mapped when price scale is detected.
 */
export function calculateForwardScenarios(
  pattern: number[],
  futureCandlesList: number[][],
  extrema: PatternExtremaAnalysis,
  referencePrice?: number | null
): ForwardScenarioAnalysis {
  const currentPrice = pattern && pattern.length > 0 ? pattern[pattern.length - 1] : 100;
  const basePrice = Math.abs(currentPrice) > 1e-6 ? currentPrice : 1;
  const realCurrent =
    referencePrice && referencePrice > 0
      ? referencePrice
      : extrema.isRealPriceAvailable && extrema.realCurrentPrice != null
      ? extrema.realCurrentPrice
      : null;
  const isRealPriceAvailable = realCurrent != null;
  const decimals = extrema.decimals || 2;

  // 1. Gather all future candles percentage moves relative to pattern end
  const futureReturnGains: number[] = [];
  const futureReturnDrops: number[] = [];
  const futureMaxHighs: number[] = [];
  const futureMinLows: number[] = [];

  futureCandlesList.forEach((future) => {
    if (!future || future.length === 0) return;
    const fStart = future[0];
    const fEnd = future[future.length - 1];
    const fMax = Math.max(...future);
    const fMin = Math.min(...future);

    const fBase = Math.abs(fStart) > 1e-6 ? fStart : 1;
    const netChangePct = ((fEnd - fStart) / fBase) * 100;
    const maxGainPct = ((fMax - fStart) / fBase) * 100;
    const maxDropPct = ((fMin - fStart) / fBase) * 100;

    if (netChangePct >= 0) {
      futureReturnGains.push(netChangePct);
    } else {
      futureReturnDrops.push(Math.abs(netChangePct));
    }

    if (maxGainPct > 0) futureMaxHighs.push(maxGainPct);
    if (maxDropPct < 0) futureMinLows.push(Math.abs(maxDropPct));
  });

  // Calculate empirical statistics or structural fallback if future dataset matches are few
  const avgEmpiricalGain =
    futureReturnGains.length > 0
      ? futureReturnGains.reduce((a, b) => a + b, 0) / futureReturnGains.length
      : 2.8;

  const maxEmpiricalGain =
    futureMaxHighs.length > 0
      ? futureMaxHighs.reduce((a, b) => a + b, 0) / futureMaxHighs.length
      : Math.max(avgEmpiricalGain * 1.6, 4.5);

  const avgEmpiricalDrop =
    futureReturnDrops.length > 0
      ? futureReturnDrops.reduce((a, b) => a + b, 0) / futureReturnDrops.length
      : 2.5;

  const maxEmpiricalDrop =
    futureMinLows.length > 0
      ? futureMinLows.reduce((a, b) => a + b, 0) / futureMinLows.length
      : Math.max(avgEmpiricalDrop * 1.5, 4.2);

  // Structural targets derived from pattern swing heights
  const patternExtremaHeightPct =
    extrema.totalRangePercent > 0.5 ? extrema.totalRangePercent : 3.5;

  const target1GainPct = Math.max(0.6, Math.min(avgEmpiricalGain, patternExtremaHeightPct * 0.65));
  const target2GainPct = Math.max(target1GainPct * 1.5, maxEmpiricalGain, patternExtremaHeightPct * 1.25);

  const target1DropPct = Math.max(0.5, Math.min(avgEmpiricalDrop, patternExtremaHeightPct * 0.6));
  const target2DropPct = Math.max(target1DropPct * 1.5, maxEmpiricalDrop, patternExtremaHeightPct * 1.2);

  const rangeUpperPct = Math.max(0.4, target1GainPct * 0.6);
  const rangeLowerPct = Math.max(0.4, target1DropPct * 0.6);

  // Real prices calculation
  const calcRealTarget = (pct: number, isGain: boolean) => {
    if (!isRealPriceAvailable || realCurrent === null) return { realPrice: null, realDiff: null };
    const multiplier = isGain ? 1 + pct / 100 : 1 - pct / 100;
    const targetP = realCurrent * multiplier;
    const diff = targetP - realCurrent;
    return { realPrice: targetP, realDiff: diff };
  };

  const t1 = calcRealTarget(target1GainPct, true);
  const t2 = calcRealTarget(target2GainPct, true);
  const s1 = calcRealTarget(target1DropPct, false);
  const s2 = calcRealTarget(target2DropPct, false);

  const rangeUpReal = calcRealTarget(rangeUpperPct, true).realPrice;
  const rangeDownReal = calcRealTarget(rangeLowerPct, false).realPrice;
  const rangeWidthReal =
    rangeUpReal !== null && rangeDownReal !== null ? rangeUpReal - rangeDownReal : null;

  return {
    isRealPriceAvailable,
    decimals,
    bullish: {
      target1: {
        label: "Target 1 (Minor Resistance)",
        labelFa: "سقف ۱ (مقاومت اول)",
        targetPrice: basePrice * (1 + target1GainPct / 100),
        percentChange: target1GainPct,
        type: "bullish_target",
        confidence: 82,
        realPrice: t1.realPrice,
        realPriceDifference: t1.realDiff,
      },
      target2: {
        label: "Target 2 (Major Peak)",
        labelFa: "سقف ۲ (سقف ماژور)",
        targetPrice: basePrice * (1 + target2GainPct / 100),
        percentChange: target2GainPct,
        type: "bullish_target",
        confidence: 68,
        realPrice: t2.realPrice,
        realPriceDifference: t2.realDiff,
      },
      avgGainPercent: target1GainPct,
      maxGainPercent: target2GainPct,
    },
    bearish: {
      support1: {
        label: "Support 1 (Minor Support)",
        labelFa: "کف ۱ (حمایت اول)",
        targetPrice: basePrice * (1 - target1DropPct / 100),
        percentChange: target1DropPct,
        type: "bearish_target",
        confidence: 80,
        realPrice: s1.realPrice,
        realPriceDifference: s1.realDiff,
      },
      support2: {
        label: "Support 2 (Major Trough)",
        labelFa: "کف ۲ (کف ماژور)",
        targetPrice: basePrice * (1 - target2DropPct / 100),
        percentChange: target2DropPct,
        type: "bearish_target",
        confidence: 65,
        realPrice: s2.realPrice,
        realPriceDifference: s2.realDiff,
      },
      avgDropPercent: target1DropPct,
      maxDropPercent: target2DropPct,
    },
    range: {
      upperBound: basePrice * (1 + rangeUpperPct / 100),
      lowerBound: basePrice * (1 - rangeLowerPct / 100),
      upperPercent: rangeUpperPct,
      lowerPercent: rangeLowerPct,
      channelWidthPercent: rangeUpperPct + rangeLowerPct,
      upperRealPrice: rangeUpReal,
      lowerRealPrice: rangeDownReal,
      channelWidthRealAmount: rangeWidthReal,
    },
  };
}
