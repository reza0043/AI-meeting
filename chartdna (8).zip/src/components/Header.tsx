import React, { useState, useRef, useEffect } from "react";
import {
  Globe,
  Check,
  ChevronDown,
  Palette,
  Type,
  Settings as SettingsIcon,
  Dna,
} from "lucide-react";
import appLogo from "../assets/logo.png";
import { SUPPORTED_LANGUAGES, LanguageCode, getTranslation } from "../i18n/languages";
import { THEMES, ThemeId, getTheme } from "../theme/themes";
import { FONTS, FontId } from "../theme/fonts";

interface HeaderProps {
  activeSymbol: string;
  onOpenSettings: () => void;
  activeLanguage: LanguageCode;
  onSelectLanguage: (lang: LanguageCode) => void;
  activeTheme: ThemeId;
  onSelectTheme: (theme: ThemeId) => void;
  activeFont: FontId;
  onSelectFont: (font: FontId) => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenSettings,
  activeLanguage,
  onSelectLanguage,
  activeTheme,
  onSelectTheme,
  activeFont,
  onSelectFont,
}) => {
  const [isLangOpen, setIsLangOpen] = useState(false);
  const [isThemeOpen, setIsThemeOpen] = useState(false);
  const [isFontOpen, setIsFontOpen] = useState(false);
  const [logoError, setLogoError] = useState(false);

  const langRef = useRef<HTMLDivElement>(null);
  const themeRef = useRef<HTMLDivElement>(null);
  const fontRef = useRef<HTMLDivElement>(null);

  const t = (key: string, fallback?: string) => getTranslation(activeLanguage, key, fallback);
  const currentLang = SUPPORTED_LANGUAGES.find((l) => l.code === activeLanguage) || SUPPORTED_LANGUAGES[0];
  const currentTheme = getTheme(activeTheme);
  const isPersian = activeLanguage === "fa" || activeLanguage === "ar";

  // Click outside to close dropdowns
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (langRef.current && !langRef.current.contains(e.target as Node)) {
        setIsLangOpen(false);
      }
      if (themeRef.current && !themeRef.current.contains(e.target as Node)) {
        setIsThemeOpen(false);
      }
      if (fontRef.current && !fontRef.current.contains(e.target as Node)) {
        setIsFontOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <header
      id="app-header"
      className="px-3 sm:px-5 lg:px-8 py-2.5 sticky top-0 z-40 backdrop-blur-xl border-b transition-colors duration-200"
      style={{
        backgroundColor: `${currentTheme.colors.headerBg}f0`,
        borderColor: currentTheme.colors.border,
        color: currentTheme.colors.text,
      }}
    >
      <div className="w-full max-w-[1920px] mx-auto flex items-center justify-between gap-3">
        {/* Brand & Logo */}
        <div className="flex items-center gap-3">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center p-0.5 shadow-lg overflow-hidden shrink-0 border transition-transform hover:scale-105"
            style={{
              backgroundColor: currentTheme.colors.subpanelBg,
              borderColor: currentTheme.colors.border,
            }}
          >
            {!logoError ? (
              <img
                src={appLogo}
                alt="Chart DNA Logo"
                className="w-full h-full object-cover rounded-lg"
                onError={() => setLogoError(true)}
                referrerPolicy="no-referrer"
              />
            ) : (
              <Dna
                className="w-6 h-6 animate-pulse"
                style={{ color: currentTheme.colors.primary }}
              />
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold tracking-tight flex items-center gap-1.5 font-mono" style={{ color: currentTheme.colors.text }}>
                <span className="font-extrabold" style={{ color: currentTheme.colors.primary }}>DNA</span>
                <span>CHART</span>
              </h1>
              <span
                className="px-2 py-0.5 text-[10px] font-semibold rounded-full border"
                style={{
                  backgroundColor: `${currentTheme.colors.secondary}15`,
                  color: currentTheme.colors.secondary,
                  borderColor: `${currentTheme.colors.secondary}30`,
                }}
              >
                v2.3 Pro
              </span>
            </div>
          </div>
        </div>

        {/* Header Right Actions: Font (Icon Only), Theme (Icon Only), Language, and Settings */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* 1. Font Selector (Icon Only - فقط آیکون فونت) */}
          <div className="relative" ref={fontRef}>
            <button
              id="btn-header-font"
              onClick={() => {
                setIsFontOpen(!isFontOpen);
                setIsThemeOpen(false);
                setIsLangOpen(false);
              }}
              className="w-9 h-9 rounded-xl flex items-center justify-center backdrop-blur-md border transition-all duration-150 cursor-pointer shadow-sm active:scale-95 group relative"
              style={{
                backgroundColor: `${currentTheme.colors.subpanelBg}ee`,
                borderColor: currentTheme.colors.border,
                color: currentTheme.colors.text,
              }}
              title={isPersian ? "انتخاب فونت برنامه" : "Select UI Font"}
              aria-label={isPersian ? "انتخاب فونت برنامه" : "Select UI Font"}
            >
              <Type className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition-transform" />
            </button>

            {isFontOpen && (
              <div
                className="absolute right-0 rtl:right-auto rtl:left-0 mt-2 w-56 max-h-80 border rounded-2xl p-2 shadow-2xl z-50 overflow-y-auto backdrop-blur-2xl"
                style={{
                  backgroundColor: currentTheme.colors.cardBg,
                  borderColor: currentTheme.colors.border,
                  color: currentTheme.colors.text,
                }}
              >
                <div
                  className="px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider border-b mb-1"
                  style={{
                    color: currentTheme.colors.textMuted,
                    borderColor: currentTheme.colors.borderSubtle,
                  }}
                >
                  {isPersian ? "انتخاب فونت رابط کاربری" : "Select UI Font"}
                </div>
                {FONTS.map((f) => {
                  const isCur = f.id === activeFont;
                  return (
                    <button
                      key={f.id}
                      onClick={() => {
                        onSelectFont(f.id);
                        setIsFontOpen(false);
                      }}
                      className="w-full text-left rtl:text-right flex items-center justify-between px-2.5 py-2 rounded-xl text-xs transition-colors cursor-pointer"
                      style={{
                        backgroundColor: isCur ? `${currentTheme.colors.primary}20` : "transparent",
                        color: isCur ? currentTheme.colors.primary : currentTheme.colors.text,
                        fontFamily: f.fontFamily,
                      }}
                    >
                      <div className="flex flex-col">
                        <span className="font-semibold text-xs">{f.name[activeLanguage] || f.name.en}</span>
                        <span className="text-[9px] opacity-60">{f.preview}</span>
                      </div>
                      {isCur && <Check className="w-3.5 h-3.5 shrink-0" style={{ color: currentTheme.colors.primary }} />}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* 2. Theme Selector (Icon Only - فقط آیکون تم) */}
          <div className="relative" ref={themeRef}>
            <button
              id="btn-header-theme"
              onClick={() => {
                setIsThemeOpen(!isThemeOpen);
                setIsFontOpen(false);
                setIsLangOpen(false);
              }}
              className="w-9 h-9 rounded-xl flex items-center justify-center backdrop-blur-md border transition-all duration-150 cursor-pointer shadow-sm active:scale-95 group relative"
              style={{
                backgroundColor: `${currentTheme.colors.subpanelBg}ee`,
                borderColor: currentTheme.colors.border,
                color: currentTheme.colors.text,
              }}
              title={isPersian ? "انتخاب تم رنگی" : "Select Color Theme"}
              aria-label={isPersian ? "انتخاب تم رنگی" : "Select Color Theme"}
            >
              <Palette className="w-4 h-4 text-purple-400 group-hover:scale-110 transition-transform" />
            </button>

            {isThemeOpen && (
              <div
                className="absolute right-0 rtl:right-auto rtl:left-0 mt-2 w-56 max-h-80 border rounded-2xl p-2 shadow-2xl z-50 overflow-y-auto backdrop-blur-2xl"
                style={{
                  backgroundColor: currentTheme.colors.cardBg,
                  borderColor: currentTheme.colors.border,
                  color: currentTheme.colors.text,
                }}
              >
                <div
                  className="px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider border-b mb-1"
                  style={{
                    color: currentTheme.colors.textMuted,
                    borderColor: currentTheme.colors.borderSubtle,
                  }}
                >
                  {isPersian ? "۱۰ تم رنگی مختلف" : "10 Color Themes"}
                </div>
                {THEMES.map((th) => {
                  const isCur = th.id === activeTheme;
                  return (
                    <button
                      key={th.id}
                      onClick={() => {
                        onSelectTheme(th.id);
                        setIsThemeOpen(false);
                      }}
                      className="w-full text-left rtl:text-right flex items-center justify-between px-2.5 py-2 rounded-xl text-xs transition-colors cursor-pointer"
                      style={{
                        backgroundColor: isCur ? `${th.colors.primary}20` : "transparent",
                        color: isCur ? th.colors.primary : currentTheme.colors.text,
                      }}
                    >
                      <div className="flex items-center gap-2">
                        <span
                          className="w-3 h-3 rounded-full border border-black/50 shrink-0"
                          style={{ backgroundColor: th.colors.primary }}
                        />
                        <span className="truncate">{th.name[activeLanguage] || th.name.en}</span>
                      </div>
                      {isCur && <Check className="w-3.5 h-3.5 shrink-0" style={{ color: th.colors.primary }} />}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* 3. 10 Languages Dropdown */}
          <div className="relative" ref={langRef}>
            <button
              id="btn-quick-lang"
              onClick={() => {
                setIsLangOpen(!isLangOpen);
                setIsFontOpen(false);
                setIsThemeOpen(false);
              }}
              className="flex items-center gap-1.5 px-2.5 py-1.5 h-9 backdrop-blur-md border text-xs font-medium rounded-xl transition-all duration-150 cursor-pointer shadow-sm active:scale-[0.98]"
              style={{
                backgroundColor: `${currentTheme.colors.subpanelBg}ee`,
                borderColor: currentTheme.colors.border,
                color: currentTheme.colors.text,
              }}
              title={t("language", "انتخاب زبان")}
            >
              <Globe className="w-3.5 h-3.5" style={{ color: currentTheme.colors.primary }} />
              <span className="text-sm leading-none">{currentLang.flag}</span>
              <span className="font-mono text-xs font-bold">{currentLang.code.toUpperCase()}</span>
              <ChevronDown className="w-3 h-3 opacity-70" />
            </button>

            {isLangOpen && (
              <div
                className="absolute right-0 rtl:right-auto rtl:left-0 mt-2 w-52 max-h-80 border rounded-2xl p-2 shadow-2xl z-50 overflow-y-auto backdrop-blur-2xl"
                style={{
                  backgroundColor: currentTheme.colors.cardBg,
                  borderColor: currentTheme.colors.border,
                  color: currentTheme.colors.text,
                }}
              >
                <div
                  className="px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider border-b mb-1"
                  style={{
                    color: currentTheme.colors.textMuted,
                    borderColor: currentTheme.colors.borderSubtle,
                  }}
                >
                  {t("tabLanguages", "۱۰ زبان زنده دنیا")}
                </div>
                {SUPPORTED_LANGUAGES.map((lang) => {
                  const isCur = lang.code === activeLanguage;
                  return (
                    <button
                      key={lang.code}
                      onClick={() => {
                        onSelectLanguage(lang.code);
                        setIsLangOpen(false);
                      }}
                      className="w-full text-left rtl:text-right flex items-center justify-between px-2.5 py-2 rounded-xl text-xs transition-colors cursor-pointer"
                      style={{
                        backgroundColor: isCur ? `${currentTheme.colors.secondary}25` : "transparent",
                        color: isCur ? currentTheme.colors.secondary : currentTheme.colors.text,
                      }}
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="text-lg">{lang.flag}</span>
                        <div className="flex flex-col">
                          <span>{lang.name}</span>
                          <span className="text-[9px]" style={{ color: currentTheme.colors.textMuted }}>{lang.englishName}</span>
                        </div>
                      </div>
                      {isCur && <Check className="w-3.5 h-3.5" style={{ color: currentTheme.colors.secondary }} />}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* 4. Quick Settings Icon Button */}
          <button
            id="btn-header-settings"
            onClick={onOpenSettings}
            className="flex items-center gap-1.5 px-2.5 py-1.5 h-9 backdrop-blur-md border text-xs font-semibold rounded-xl transition-all duration-150 cursor-pointer shadow-sm active:scale-[0.98]"
            style={{
              backgroundColor: `${currentTheme.colors.primary}18`,
              borderColor: `${currentTheme.colors.primary}40`,
              color: currentTheme.colors.primary,
            }}
            title={t("settings", "تنظیمات")}
          >
            <SettingsIcon className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{t("settings", "تنظیمات")}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
