import React, { useState } from "react";
import {
  X,
  Sliders,
  Check,
  RotateCcw,
  Sparkles,
  FolderOpen,
  Palette,
  Globe,
  CheckCircle2,
  ScanLine,
  Percent,
  Layers,
  TrendingUp,
  History,
  ListOrdered,
  Filter,
  Scale,
  Activity,
  GitMerge,
  ArrowUpRight,
  Mountain,
} from "lucide-react";
import { SearchConfig, MarketDataset, MyDNAPattern } from "../engine/types";
import { MarketDataManager } from "./MarketDataManager";
import { ImagePatternExtractorTab } from "./ImagePatternExtractorTab";
import { THEMES, ThemeId } from "../theme/themes";
import { FONTS, FontId } from "../theme/fonts";
import { SUPPORTED_LANGUAGES, LanguageCode, getTranslation } from "../i18n/languages";

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: "themes" | "languages" | "algorithm" | "weights" | "data" | "patternExtractor";
  config: SearchConfig;
  onUpdateConfig: (newConfig: SearchConfig) => void;
  datasets: MarketDataset[];
  onUpdateDatasets: (newDatasets: MarketDataset[]) => void;
  selectedDatasetIds: string[];
  onToggleDatasetId: (id: string) => void;
  onSetSelectedDatasetIds?: (ids: string[]) => void;
  onSelectAllDatasets: (select: boolean) => void;
  savedPatterns: MyDNAPattern[];
  onSavePattern: (pattern: MyDNAPattern) => void;
  onDeletePattern: (id: string) => void;
  onApplyAsActiveReference: (pattern: number[], name: string) => void;
  onRunSearchWithPattern?: (pattern: number[], name: string) => void;
  includeCustomPatternsInSearch?: boolean;
  onToggleIncludeCustomPatterns?: (include: boolean) => void;
  includeTALibPatternsInSearch?: boolean;
  onToggleIncludeTALibPatterns?: (include: boolean) => void;
  activeTheme: ThemeId;
  onSelectTheme: (themeId: ThemeId) => void;
  activeFont?: FontId;
  onSelectFont?: (fontId: FontId) => void;
  activeLanguage: LanguageCode;
  onSelectLanguage: (lang: LanguageCode) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  initialTab = "themes",
  config,
  onUpdateConfig,
  datasets,
  onUpdateDatasets,
  selectedDatasetIds,
  onToggleDatasetId,
  onSetSelectedDatasetIds,
  onSelectAllDatasets,
  savedPatterns,
  onSavePattern,
  onDeletePattern,
  onApplyAsActiveReference,
  onRunSearchWithPattern,
  includeCustomPatternsInSearch = true,
  onToggleIncludeCustomPatterns,
  includeTALibPatternsInSearch = true,
  onToggleIncludeTALibPatterns,
  activeTheme,
  onSelectTheme,
  activeFont = "vazirmatn",
  onSelectFont,
  activeLanguage,
  onSelectLanguage,
}) => {
  const [activeTab, setActiveTab] = useState<"themes" | "languages" | "algorithm" | "weights" | "data" | "patternExtractor">(initialTab);
  const [tempConfig, setTempConfig] = useState<SearchConfig>({ ...config });

  // Sync tab when initialTab changes or modal opens
  React.useEffect(() => {
    if (isOpen && initialTab) {
      if ((initialTab as any) === "datasets") {
        setActiveTab("data");
      } else if ((initialTab as any) === "search" || (initialTab as any) === "parameters") {
        setActiveTab("algorithm");
      } else {
        setActiveTab(initialTab);
      }
    }
  }, [isOpen, initialTab]);

  if (!isOpen) return null;

  const t = (key: string, fallback?: string) => getTranslation(activeLanguage, key, fallback);
  const isRtl = activeLanguage === "fa" || activeLanguage === "ar";

  const handleSave = () => {
    onUpdateConfig(tempConfig);
    onClose();
  };

  const handleResetDefaults = () => {
    setTempConfig({
      threshold: 75,
      patternLength: 60,
      extractorPointCount: 500,
      futureCandles: 70,
      beforeCandles: 40,
      topResults: 50,
      rangeTolerance: 1.0,
      skipOverlap: true,
      weights: {
        pearson: 0.4,
        dtw: 0.3,
        slope: 0.15,
        structural: 0.15,
      },
    });
  };

  return (
    <div
      id="settings-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-3 md:p-5 bg-black/85 backdrop-blur-md"
      dir={isRtl ? "rtl" : "ltr"}
    >
      <div className="bg-[#0b101c]/98 border border-slate-700/80 rounded-2xl w-full max-w-5xl xl:max-w-6xl h-[92vh] max-h-[94vh] flex flex-col shadow-2xl overflow-hidden backdrop-blur-2xl">
        {/* Header */}
        <div className="bg-slate-900/95 border-b border-slate-800/80 px-5 py-3.5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-cyan-500/15 border border-cyan-400/30 text-cyan-300 shadow-sm">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-wide">
                {t("settingsTitle", "تنظیمات")}
              </h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] text-slate-400 hover:text-white transition-all cursor-pointer"
            title={t("clearAll", "بستن")}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector - Clean, scrollable bar with visible pills */}
        <div className="flex items-center border-b border-slate-800/80 bg-slate-950/80 px-4 overflow-x-auto gap-2 shrink-0 py-1.5 scrollbar-thin">
          {/* Tab 1: Themes */}
          <button
            onClick={() => setActiveTab("themes")}
            className={`py-2 px-3.5 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap shrink-0 ${
              activeTab === "themes"
                ? "bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 shadow-sm shadow-cyan-950"
                : "border border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/60"
            }`}
          >
            <Palette className="w-4 h-4 text-cyan-400" />
            <span>{t("tabThemes", "تم‌های رنگی (۱۰ تم)")}</span>
          </button>

          {/* Tab 2: Language */}
          <button
            onClick={() => setActiveTab("languages")}
            className={`py-2 px-3.5 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap shrink-0 ${
              activeTab === "languages"
                ? "bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 shadow-sm shadow-cyan-950"
                : "border border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/60"
            }`}
          >
            <Globe className="w-4 h-4 text-emerald-400" />
            <span>{t("tabLanguages", "انتخاب زبان (۱۰ زبان)")}</span>
          </button>

          {/* Tab 3: Search Parameters */}
          <button
            onClick={() => setActiveTab("algorithm")}
            className={`py-2 px-3.5 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap shrink-0 ${
              activeTab === "algorithm"
                ? "bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 shadow-sm shadow-cyan-950"
                : "border border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/60"
            }`}
          >
            <Sliders className="w-4 h-4 text-amber-400" />
            <span>{t("tabSearch", "پارامترهای جستجو")}</span>
          </button>

          {/* Tab 4: Similarity Weights */}
          <button
            onClick={() => setActiveTab("weights")}
            className={`py-2 px-3.5 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap shrink-0 ${
              activeTab === "weights"
                ? "bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 shadow-sm shadow-cyan-950"
                : "border border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/60"
            }`}
          >
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span>{t("tabWeights", "وزن‌دهی فرمول")}</span>
          </button>

          {/* Tab 5: Market Data Manager */}
          <button
            onClick={() => setActiveTab("data")}
            className={`py-2 px-3.5 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap shrink-0 ${
              activeTab === "data"
                ? "bg-emerald-500/20 text-emerald-300 border border-emerald-400/50 shadow-sm shadow-emerald-950"
                : "border border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/60"
            }`}
          >
            <FolderOpen className="w-4 h-4 text-emerald-400" />
            <span>{t("tabData", "مدیریت داده‌ها")}</span>
          </button>

          {/* Tab 6: Image Pattern Extractor & DNA Library */}
          <button
            onClick={() => setActiveTab("patternExtractor")}
            className={`py-2 px-3.5 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap shrink-0 ${
              activeTab === "patternExtractor"
                ? "bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 shadow-sm shadow-cyan-950"
                : "border border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/60"
            }`}
          >
            <ScanLine className="w-4 h-4 text-cyan-400" />
            <span>{t("tabPatternExtractor", "تشخیص و ثبت الگو از تصویر")}</span>
          </button>
        </div>

        {/* Tab Contents */}
        <div className="p-4 sm:p-5 md:p-6 overflow-y-auto flex-1 flex flex-col gap-5 text-xs text-slate-300">
          {/* TAB 1: 10 Color Themes */}
          {activeTab === "themes" && (
            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Palette className="w-4 h-4 text-cyan-400" />
                    <span>{t("tabThemes", "تم‌های رنگی رابط کاربری")}</span>
                  </h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    {t("selectThemeDesc", "یکی از ۱۰ تم زیر را برای تغییر کل پالت رنگی برنامه انتخاب کنید:")}
                  </p>
                </div>
              </div>

              {/* 10 Theme Cards Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-3">
                {THEMES.map((theme) => {
                  const isSelected = activeTheme === theme.id;
                  const themeName =
                    theme.name[activeLanguage] || theme.name.en || theme.id;
                  const themeDesc =
                    theme.description[activeLanguage] || theme.description.en;

                  return (
                    <div
                      key={theme.id}
                      onClick={() => onSelectTheme(theme.id)}
                      className={`relative p-3.5 rounded-xl border transition-all duration-200 cursor-pointer flex flex-col justify-between gap-3 ${
                        isSelected
                          ? "bg-white/[0.08] border-cyan-400 shadow-lg shadow-cyan-950/40 ring-1 ring-cyan-400/50"
                          : "bg-slate-900/60 hover:bg-slate-900/90 border-slate-800 hover:border-slate-700"
                      }`}
                      style={{
                        backgroundColor: isSelected ? undefined : `${theme.colors.cardBg}cc`,
                        borderColor: isSelected ? theme.colors.primary : undefined,
                      }}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          {/* Color preview palette dots */}
                          <div className="flex items-center -space-x-1.5 rtl:space-x-reverse">
                            <span
                              className="w-4 h-4 rounded-full border border-black/40 shadow-sm"
                              style={{ backgroundColor: theme.colors.primary }}
                            />
                            <span
                              className="w-4 h-4 rounded-full border border-black/40 shadow-sm"
                              style={{ backgroundColor: theme.colors.secondary }}
                            />
                            <span
                              className="w-4 h-4 rounded-full border border-black/40 shadow-sm"
                              style={{ backgroundColor: theme.colors.bg }}
                            />
                          </div>
                          <div>
                            <h4 className="font-bold text-xs text-white">
                              {themeName}
                            </h4>
                            {theme.isLight && (
                              <span className="text-[9px] px-1.5 py-0.2 bg-blue-500/20 text-blue-300 rounded border border-blue-400/30">
                                Light Mode
                              </span>
                            )}
                          </div>
                        </div>

                        {isSelected && (
                          <span
                            className="flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-md border"
                            style={{
                              backgroundColor: `${theme.colors.primary}20`,
                              color: theme.colors.primary,
                              borderColor: `${theme.colors.primary}50`,
                            }}
                          >
                            <CheckCircle2 className="w-3 h-3" />
                            <span>{t("activeCandles", "فعال")}</span>
                          </span>
                        )}
                      </div>

                      <p className="text-[11px] text-slate-400 leading-relaxed">
                        {themeDesc}
                      </p>

                      {/* Visual Line preview */}
                      <div
                        className="w-full h-7 rounded-lg border p-1 flex items-center justify-between px-2.5 overflow-hidden"
                        style={{
                          backgroundColor: theme.colors.bg,
                          borderColor: theme.colors.border,
                        }}
                      >
                        <div className="flex items-center gap-2">
                          <span
                            className="w-5 h-1 rounded-full"
                            style={{ backgroundColor: theme.colors.dnaLine }}
                          />
                          <span
                            className="w-5 h-1 rounded-full"
                            style={{ backgroundColor: theme.colors.matchedLine }}
                          />
                          <span
                            className="w-5 h-1 rounded-full"
                            style={{ backgroundColor: theme.colors.futureLine }}
                          />
                        </div>
                        <span
                          className="text-[9px] font-mono"
                          style={{ color: theme.colors.textMuted }}
                        >
                          preview
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Font Selection Section */}
              {onSelectFont && (
                <div className="mt-3 pt-3 border-t border-slate-800 flex flex-col gap-2.5">
                  <div>
                    <h4 className="text-xs font-bold text-white flex items-center gap-2">
                      <span>{isRtl ? "فونت و تایپوگرافی رابط کاربری" : "UI Typography & Font Family"}</span>
                    </h4>
                    <p className="text-[10px] text-slate-400 mt-0.5">
                      {isRtl
                        ? "فونت مورد علاقه خود را برای متن‌های فارسی و نمایش اعداد انتخاب نمایید:"
                        : "Select your preferred font family for interface typography:"}
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                    {FONTS.map((font) => {
                      const isSelected = activeFont === font.id;
                      return (
                        <div
                          key={font.id}
                          onClick={() => onSelectFont(font.id)}
                          className={`p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-2 ${
                            isSelected
                              ? "bg-cyan-500/15 border-cyan-400 text-cyan-200 ring-1 ring-cyan-400/40"
                              : "bg-slate-900/60 hover:bg-slate-900 border-slate-800 text-slate-300"
                          }`}
                          style={{ fontFamily: font.fontFamily }}
                        >
                          <div className="flex flex-col">
                            <span className="font-bold text-xs">{font.name[activeLanguage] || font.name.en}</span>
                            <span className="text-[10px] opacity-70 mt-0.5">{font.preview}</span>
                          </div>
                          {isSelected && <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: 10 World Languages */}
          {activeTab === "languages" && (
            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Globe className="w-4 h-4 text-emerald-400" />
                    <span>{t("tabLanguages", "انتخاب زبان برنامه")}</span>
                  </h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    {t("selectLangDesc", "زبان مورد نظر خود را از میان ۱۰ زبان زنده دنیا انتخاب کنید:")}
                  </p>
                </div>
              </div>

              {/* 10 Languages Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {SUPPORTED_LANGUAGES.map((lang) => {
                  const isSelected = activeLanguage === lang.code;

                  return (
                    <div
                      key={lang.code}
                      onClick={() => onSelectLanguage(lang.code)}
                      className={`p-3 rounded-xl border flex items-center justify-between transition-all duration-150 cursor-pointer ${
                        isSelected
                          ? "bg-emerald-500/15 border-emerald-400/80 shadow-md shadow-emerald-950/40"
                          : "bg-slate-900/60 hover:bg-slate-900/90 border-slate-800 hover:border-slate-700"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{lang.flag}</span>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-xs text-white">
                              {lang.name}
                            </span>
                            <span className="text-[10px] text-slate-400">
                              ({lang.englishName})
                            </span>
                          </div>
                          <span className="text-[9px] text-slate-500 font-mono">
                            {lang.dir.toUpperCase()} • Code: {lang.code}
                          </span>
                        </div>
                      </div>

                      {isSelected ? (
                        <div className="flex items-center gap-1 text-[11px] font-bold text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded-md border border-emerald-400/30">
                          <Check className="w-3.5 h-3.5" />
                          <span>فعال</span>
                        </div>
                      ) : (
                        <button className="text-[11px] text-slate-400 hover:text-slate-200 px-2.5 py-1 bg-white/[0.04] rounded-lg border border-white/[0.08]">
                          Select
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 3: Search Parameters */}
          {activeTab === "algorithm" && (
            <div className="flex flex-col gap-3.5">
              {/* 1. Similarity Threshold */}
              <div className="p-3.5 rounded-xl border border-cyan-500/30 bg-slate-900/90 flex flex-col gap-2 hover:border-cyan-500/50 transition-colors shadow-sm">
                <div className="flex justify-between items-center font-semibold text-slate-100 gap-3">
                  <div className="flex flex-col">
                    <span className="text-xs sm:text-sm text-cyan-300 font-bold flex items-center gap-1.5">
                      <Percent className="w-4 h-4 text-cyan-400" />
                      <span>{t("similarityThreshold", "آستانه حداقل شباهت (Threshold %):")}</span>
                    </span>
                    <span className="text-[11px] text-slate-400 mt-0.5">
                      {isRtl
                        ? "حداقل درصد تطابق ریاضی و هندسی الگوهای تاریخی با الگوی مبنا جهت انتخاب به عنوان خروجی مشابه (۶۰٪ تا ۹۸٪)"
                        : "Minimum mathematical similarity percentage required to qualify a historical match (60% to 98%)"}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-cyan-500/20 border border-cyan-400/50 shrink-0">
                    <input
                      type="number"
                      min="60"
                      max="98"
                      step="1"
                      value={tempConfig.threshold}
                      onChange={(e) => {
                        const val = parseInt(e.target.value);
                        if (!isNaN(val)) {
                          setTempConfig({
                            ...tempConfig,
                            threshold: Math.max(60, Math.min(98, val)),
                          });
                        }
                      }}
                      className="w-14 bg-transparent text-right rtl:text-left font-mono font-bold text-cyan-300 text-sm focus:outline-none border-b border-cyan-500/40"
                    />
                    <span className="text-[10px] text-cyan-400 font-bold">%</span>
                  </div>
                </div>

                <input
                  type="range"
                  min="60"
                  max="98"
                  value={tempConfig.threshold}
                  onChange={(e) =>
                    setTempConfig({ ...tempConfig, threshold: parseInt(e.target.value) })
                  }
                  className="w-full accent-cyan-400 cursor-pointer mt-1"
                />
              </div>

              {/* 2. Pattern Length */}
              <div className="p-3.5 rounded-xl border border-blue-500/30 bg-slate-900/90 flex flex-col gap-2 hover:border-blue-500/50 transition-colors shadow-sm">
                <div className="flex justify-between items-center font-semibold text-slate-100 gap-3">
                  <div className="flex flex-col">
                    <span className="text-xs sm:text-sm text-blue-300 font-bold flex items-center gap-1.5">
                      <Layers className="w-4 h-4 text-blue-400" />
                      <span>{t("patternLength", "طول بازه الگو (تعداد کندل):")}</span>
                    </span>
                    <span className="text-[11px] text-slate-400 mt-0.5">
                      {isRtl
                        ? "تعداد کندل‌های تشکیل‌دهنده الگوی اصلی برای برش، استخراج و مقایسه در دیتاست‌ها (۱۵ تا ۱۵۰ کندل)"
                        : "Number of candles forming the base pattern for extraction and dataset scanning (15 to 150 candles)"}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-500/20 border border-blue-400/50 shrink-0">
                    <input
                      type="number"
                      min="15"
                      max="150"
                      step="1"
                      value={tempConfig.patternLength}
                      onChange={(e) => {
                        const val = parseInt(e.target.value);
                        if (!isNaN(val)) {
                          setTempConfig({
                            ...tempConfig,
                            patternLength: Math.max(15, Math.min(150, val)),
                          });
                        }
                      }}
                      className="w-14 bg-transparent text-right rtl:text-left font-mono font-bold text-blue-300 text-sm focus:outline-none border-b border-blue-500/40"
                    />
                    <span className="text-[10px] text-blue-400 font-bold">{isRtl ? "کندل" : "cds"}</span>
                  </div>
                </div>

                <input
                  type="range"
                  min="15"
                  max="150"
                  value={tempConfig.patternLength}
                  onChange={(e) =>
                    setTempConfig({ ...tempConfig, patternLength: parseInt(e.target.value) })
                  }
                  className="w-full accent-blue-400 cursor-pointer mt-1"
                />
              </div>

              {/* 3. Future Candles (After Pattern) */}
              <div className="p-3.5 rounded-xl border border-emerald-500/30 bg-slate-900/90 flex flex-col gap-2 hover:border-emerald-500/50 transition-colors shadow-sm">
                <div className="flex justify-between items-center font-semibold text-slate-100 gap-3">
                  <div className="flex flex-col">
                    <span className="text-xs sm:text-sm text-emerald-300 font-bold flex items-center gap-1.5">
                      <TrendingUp className="w-4 h-4 text-emerald-400" />
                      <span>{t("futureCandlesCount", "تعداد کندل‌های بعد از الگو (آینده‌نگری):")}</span>
                    </span>
                    <span className="text-[11px] text-slate-400 mt-0.5">
                      {isRtl
                        ? "تعداد کندل‌های تاریخی پس از پایان هر الگو جهت محاسبه بازدهی، جهت صعودی/نزولی و پیش‌بینی مسیر (۵ تا ۱۵۰ کندل)"
                        : "Number of future candles evaluated after pattern end to measure performance and trajectory (5 to 150 candles)"}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500/20 border border-emerald-400/50 shrink-0">
                    <input
                      type="number"
                      min="5"
                      max="150"
                      step="1"
                      value={tempConfig.futureCandles}
                      onChange={(e) => {
                        const val = parseInt(e.target.value);
                        if (!isNaN(val)) {
                          setTempConfig({
                            ...tempConfig,
                            futureCandles: Math.max(5, Math.min(150, val)),
                          });
                        }
                      }}
                      className="w-14 bg-transparent text-right rtl:text-left font-mono font-bold text-emerald-300 text-sm focus:outline-none border-b border-emerald-500/40"
                    />
                    <span className="text-[10px] text-emerald-400 font-bold">{isRtl ? "کندل" : "cds"}</span>
                  </div>
                </div>

                <input
                  type="range"
                  min="5"
                  max="150"
                  value={tempConfig.futureCandles}
                  onChange={(e) =>
                    setTempConfig({ ...tempConfig, futureCandles: parseInt(e.target.value) })
                  }
                  className="w-full accent-emerald-400 cursor-pointer mt-1"
                />
              </div>

              {/* 4. Before Candles (Before Pattern for Chart View) */}
              <div className="p-3.5 rounded-xl border border-sky-500/30 bg-slate-900/90 flex flex-col gap-2 hover:border-sky-500/50 transition-colors shadow-sm">
                <div className="flex justify-between items-center font-semibold text-slate-100 gap-3">
                  <div className="flex flex-col">
                    <span className="text-xs sm:text-sm text-sky-300 font-bold flex items-center gap-1.5">
                      <History className="w-4 h-4 text-sky-400" />
                      <span>{isRtl ? "تعداد کندل‌های قبل از الگو (نمایش در چارت):" : "Candles Before Pattern (Chart View):"}</span>
                    </span>
                    <span className="text-[11px] text-slate-400 mt-0.5">
                      {isRtl
                        ? "تعداد کندل‌های ماقبل شروع الگو جهت نمایش بستر روند و زمینه قبلی در پنجره چارت (۱۰ تا ۲۰۰ کندل)"
                        : "Number of candles preceding the pattern to provide trend context in candlestick charts (10 to 200 candles)"}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-sky-500/20 border border-sky-400/50 shrink-0">
                    <input
                      type="number"
                      min="10"
                      max="200"
                      step="1"
                      value={tempConfig.beforeCandles ?? 40}
                      onChange={(e) => {
                        const val = parseInt(e.target.value);
                        if (!isNaN(val)) {
                          setTempConfig({
                            ...tempConfig,
                            beforeCandles: Math.max(10, Math.min(200, val)),
                          });
                        }
                      }}
                      className="w-14 bg-transparent text-right rtl:text-left font-mono font-bold text-sky-300 text-sm focus:outline-none border-b border-sky-500/40"
                    />
                    <span className="text-[10px] text-sky-400 font-bold">{isRtl ? "کندل" : "cds"}</span>
                  </div>
                </div>

                <input
                  type="range"
                  min="10"
                  max="200"
                  value={tempConfig.beforeCandles ?? 40}
                  onChange={(e) =>
                    setTempConfig({ ...tempConfig, beforeCandles: parseInt(e.target.value) })
                  }
                  className="w-full accent-sky-400 cursor-pointer mt-1"
                />
              </div>

              {/* 5. Max Top Results Limit */}
              <div className="p-3.5 rounded-xl border border-indigo-500/30 bg-slate-900/90 flex flex-col gap-2 hover:border-indigo-500/50 transition-colors shadow-sm">
                <div className="flex justify-between items-center font-semibold text-slate-100 gap-3">
                  <div className="flex flex-col">
                    <span className="text-xs sm:text-sm text-indigo-300 font-bold flex items-center gap-1.5">
                      <ListOrdered className="w-4 h-4 text-indigo-400" />
                      <span>{t("maxResults", "حداکثر تعداد نتایج (Top Hits):")}</span>
                    </span>
                    <span className="text-[11px] text-slate-400 mt-0.5">
                      {isRtl
                        ? "سقف تعداد الگوهای برتر با بالاترین درصد انطباق که در خروجی و جدول نتایج نمایش داده می‌شوند (۵ تا ۲۰۰ نتیجه)"
                        : "Maximum count of highest-scoring matched patterns returned in results (5 to 200 hits)"}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-500/20 border border-indigo-400/50 shrink-0">
                    <input
                      type="number"
                      min="5"
                      max="200"
                      step="5"
                      value={tempConfig.topResults ?? 50}
                      onChange={(e) => {
                        const val = parseInt(e.target.value);
                        if (!isNaN(val)) {
                          setTempConfig({
                            ...tempConfig,
                            topResults: Math.max(5, Math.min(200, val)),
                          });
                        }
                      }}
                      className="w-14 bg-transparent text-right rtl:text-left font-mono font-bold text-indigo-300 text-sm focus:outline-none border-b border-indigo-500/40"
                    />
                    <span className="text-[10px] text-indigo-400 font-bold">{isRtl ? "مورد" : "hits"}</span>
                  </div>
                </div>

                <input
                  type="range"
                  min="5"
                  max="200"
                  step="5"
                  value={tempConfig.topResults ?? 50}
                  onChange={(e) =>
                    setTempConfig({ ...tempConfig, topResults: parseInt(e.target.value) })
                  }
                  className="w-full accent-indigo-400 cursor-pointer mt-1"
                />
              </div>

              {/* 6. Extractor Similarity Point Count (Resolution of Pattern from Image / Chart) */}
              <div className="p-3.5 rounded-xl border border-violet-500/30 bg-slate-900/90 flex flex-col gap-2 hover:border-violet-500/50 transition-colors shadow-sm">
                <div className="flex justify-between items-center font-semibold text-slate-100 gap-3">
                  <div className="flex flex-col">
                    <span className="text-xs sm:text-sm text-violet-300 font-bold flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-violet-400" />
                      <span>
                        {isRtl
                          ? "تعداد نقاط شباهت و تفکیک الگو (Pattern Resolution Points):"
                          : "Pattern Similarity Points & Resolution:"}
                      </span>
                    </span>
                    <span className="text-[11px] text-slate-400 mt-0.5">
                      {isRtl
                        ? "تعداد نقاطی که موتور از تصویر آپلودشده استخراج کرده و برای رسم و تطبیق روند مبنا قرار می‌دهد (پیش‌فرض: ۵۰۰ نقطه)"
                        : "Number of data points extracted from uploaded image to calculate trend and pattern similarity"}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-violet-500/20 border border-violet-400/50 shrink-0">
                    <input
                      type="number"
                      min="20"
                      max="1000"
                      step="10"
                      value={tempConfig.extractorPointCount ?? 500}
                      onChange={(e) => {
                        const val = parseInt(e.target.value);
                        if (!isNaN(val)) {
                          setTempConfig({
                            ...tempConfig,
                            extractorPointCount: Math.max(20, Math.min(1000, val)),
                          });
                        }
                      }}
                      className="w-14 bg-transparent text-right rtl:text-left font-mono font-bold text-violet-300 text-sm focus:outline-none border-b border-violet-500/40"
                    />
                    <span className="text-[10px] text-violet-400 font-bold">pts</span>
                  </div>
                </div>

                <input
                  type="range"
                  min="20"
                  max="1000"
                  step="10"
                  value={tempConfig.extractorPointCount ?? 500}
                  onChange={(e) =>
                    setTempConfig({ ...tempConfig, extractorPointCount: parseInt(e.target.value) })
                  }
                  className="w-full accent-violet-400 cursor-pointer mt-1"
                />

                {/* Quick Selection Presets */}
                <div className="flex items-center gap-2 flex-wrap pt-1 border-t border-slate-800/80 mt-1">
                  <span className="text-[11px] text-slate-400 font-medium">
                    {isRtl ? "مقادیر آماده:" : "Presets:"}
                  </span>
                  {[50, 80, 150, 300, 500, 750, 1000].map((preset) => {
                    const isSelected = (tempConfig.extractorPointCount ?? 500) === preset;
                    return (
                      <button
                        key={preset}
                        type="button"
                        onClick={() =>
                          setTempConfig({ ...tempConfig, extractorPointCount: preset })
                        }
                        className={`px-2 py-0.5 text-[11px] font-mono rounded-md border transition-all cursor-pointer ${
                          isSelected
                            ? "bg-violet-500 text-slate-950 font-bold border-violet-300 shadow-sm"
                            : "bg-slate-950/80 hover:bg-slate-800 text-slate-300 border-slate-800"
                        }`}
                      >
                        {preset}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 7. Range Tolerance % (0% to 30%) */}
              <div className="p-3.5 rounded-xl border border-amber-500/30 bg-slate-900/90 flex flex-col gap-2 hover:border-amber-500/50 transition-colors shadow-sm">
                <div className="flex justify-between items-center font-semibold text-slate-100 gap-3">
                  <div className="flex flex-col">
                    <span className="text-xs sm:text-sm text-amber-300 font-bold flex items-center gap-1.5">
                      <Sliders className="w-4 h-4 text-amber-400" />
                      <span>{t("rangeTolerance", "میزان تحمل تشخیص رنج (%):")}</span>
                    </span>
                    <span className="text-[11px] text-slate-400 mt-0.5">
                      {isRtl
                        ? "حداکثر درصد تغییر قیمت آینده نسبت به انتهای الگو که بازار همچنان در وضعیت خنثی/رِنج (Range) شناسایی می‌شود (از ۰٪ تا ۳۰٪)"
                        : "Maximum percentage price change in future to classify market as Range-bound (0% to 30%)"}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-500/20 border border-amber-400/50 shrink-0">
                    <input
                      type="number"
                      min="0"
                      max="30"
                      step="0.1"
                      value={tempConfig.rangeTolerance ?? 1.0}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value);
                        if (!isNaN(val)) {
                          setTempConfig({
                            ...tempConfig,
                            rangeTolerance: Math.max(0, Math.min(30, val)),
                          });
                        }
                      }}
                      className="w-14 bg-transparent text-right rtl:text-left font-mono font-bold text-amber-300 text-sm focus:outline-none border-b border-amber-500/40"
                    />
                    <span className="text-[10px] text-amber-400 font-bold">%</span>
                  </div>
                </div>

                <input
                  type="range"
                  min="0"
                  max="30"
                  step="0.1"
                  value={tempConfig.rangeTolerance ?? 1.0}
                  onChange={(e) =>
                    setTempConfig({ ...tempConfig, rangeTolerance: parseFloat(e.target.value) })
                  }
                  className="w-full accent-amber-400 cursor-pointer mt-1"
                />
              </div>

              {/* 8. Skip Overlap Toggle Card */}
              <div
                onClick={() => setTempConfig({ ...tempConfig, skipOverlap: !tempConfig.skipOverlap })}
                className={`p-3.5 rounded-xl border transition-all duration-200 cursor-pointer flex items-center justify-between gap-3 shadow-sm ${
                  tempConfig.skipOverlap
                    ? "bg-slate-900/90 border-teal-500/40 hover:border-teal-400/60"
                    : "bg-slate-900/60 border-slate-800 hover:border-slate-700"
                }`}
              >
                <div className="flex flex-col">
                  <span className={`text-xs sm:text-sm font-bold flex items-center gap-1.5 ${
                    tempConfig.skipOverlap ? "text-teal-300" : "text-slate-300"
                  }`}>
                    <Filter className={`w-4 h-4 ${tempConfig.skipOverlap ? "text-teal-400" : "text-slate-400"}`} />
                    <span>{t("skipOverlap", "فیلتر هم‌پوشانی الگوهای تکراری مجاور (Skip Overlaps)")}</span>
                  </span>
                  <span className="text-[11px] text-slate-400 mt-0.5">
                    {isRtl
                      ? "جلوگیری از انتخاب الگوهای تکراری و همپوشان که در کندل‌های بسیار نزدیک به یکدیگر در یک روند رخ داده‌اند"
                      : "Prevent duplicate overlapping matches found in very close sequential candles along the same trend"}
                  </span>
                </div>

                <div className="flex items-center gap-2.5 shrink-0">
                  <span
                    className={`text-[11px] font-bold px-2 py-0.5 rounded-md border ${
                      tempConfig.skipOverlap
                        ? "bg-teal-500/20 text-teal-300 border-teal-400/40"
                        : "bg-slate-800/60 text-slate-400 border-slate-700/50"
                    }`}
                  >
                    {tempConfig.skipOverlap ? (isRtl ? "فعال" : "Active") : (isRtl ? "غیرفعال" : "Disabled")}
                  </span>
                  <div
                    className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors duration-200 ${
                      tempConfig.skipOverlap ? "bg-teal-500" : "bg-slate-800"
                    }`}
                  >
                    <div
                      className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform duration-200 ${
                        tempConfig.skipOverlap
                          ? isRtl ? "-translate-x-5" : "translate-x-5"
                          : "translate-x-0"
                      }`}
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: Similarity Weights */}
          {activeTab === "weights" && (
            <div className="flex flex-col gap-3.5">
              {/* Informational Header Card with Total Weight Calculation */}
              {(() => {
                const totalWeightPct = Math.round(
                  (tempConfig.weights.pearson +
                    tempConfig.weights.dtw +
                    tempConfig.weights.slope +
                    tempConfig.weights.structural) *
                    100
                );
                return (
                  <div className="p-3 rounded-xl border border-slate-700/60 bg-slate-900/70 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2.5">
                    <div className="flex items-center gap-2">
                      <Scale className="w-4 h-4 text-cyan-400 shrink-0" />
                      <div className="flex flex-col">
                        <span className="text-xs font-bold text-slate-200">
                          {t("weightsNotice", "ترکیب ضرایب محاسباتی موتور برای انطباق آماری و ساختاری")}
                        </span>
                        <span className="text-[11px] text-slate-400">
                          {isRtl
                            ? "مجموع ضرایب برای ایجاد نمره نهایی شباهت الگوها ترکیب و به ۱۰۰٪ نرمال‌سازی می‌شوند"
                            : "Weights are normalized to calculate the composite pattern similarity match score"}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
                      <span className="text-[11px] text-slate-400 font-medium">
                        {isRtl ? "مجموع ضرایب:" : "Sum:"}
                      </span>
                      <span className="px-2.5 py-0.5 rounded-md font-mono font-bold text-xs bg-slate-800 text-cyan-300 border border-slate-700">
                        {totalWeightPct}%
                      </span>
                    </div>
                  </div>
                );
              })()}

              {/* 1. Pearson Weight */}
              <div className="p-3.5 rounded-xl border border-cyan-500/30 bg-slate-900/90 flex flex-col gap-2 hover:border-cyan-500/50 transition-colors shadow-sm">
                <div className="flex justify-between items-center font-semibold text-slate-100 gap-3">
                  <div className="flex flex-col">
                    <span className="text-xs sm:text-sm text-cyan-300 font-bold flex items-center gap-1.5">
                      <Activity className="w-4 h-4 text-cyan-400" />
                      <span>{t("pearsonWeight", "همبستگی پیرسون (Pearson Correlation):")}</span>
                    </span>
                    <span className="text-[11px] text-slate-400 mt-0.5">
                      {isRtl
                        ? "سنجش همبستگی آماری مستقیم، نوسانات خطی و تطابق شکل کلی موج و فراز و فرودها (۰٪ تا ۱۰۰٪)"
                        : "Direct linear correlation evaluating wave shape, trend direction, and wave fluctuations (0% to 100%)"}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-cyan-500/20 border border-cyan-400/50 shrink-0">
                    <input
                      type="number"
                      min="0"
                      max="100"
                      step="5"
                      value={Math.round(tempConfig.weights.pearson * 100)}
                      onChange={(e) => {
                        const val = parseInt(e.target.value);
                        if (!isNaN(val)) {
                          setTempConfig({
                            ...tempConfig,
                            weights: {
                              ...tempConfig.weights,
                              pearson: Math.max(0, Math.min(100, val)) / 100,
                            },
                          });
                        }
                      }}
                      className="w-14 bg-transparent text-right rtl:text-left font-mono font-bold text-cyan-300 text-sm focus:outline-none border-b border-cyan-500/40"
                    />
                    <span className="text-[10px] text-cyan-400 font-bold">%</span>
                  </div>
                </div>

                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.01"
                  value={tempConfig.weights.pearson}
                  onChange={(e) =>
                    setTempConfig({
                      ...tempConfig,
                      weights: { ...tempConfig.weights, pearson: parseFloat(e.target.value) },
                    })
                  }
                  className="w-full accent-cyan-400 cursor-pointer mt-1"
                />
              </div>

              {/* 2. DTW Weight */}
              <div className="p-3.5 rounded-xl border border-purple-500/30 bg-slate-900/90 flex flex-col gap-2 hover:border-purple-500/50 transition-colors shadow-sm">
                <div className="flex justify-between items-center font-semibold text-slate-100 gap-3">
                  <div className="flex flex-col">
                    <span className="text-xs sm:text-sm text-purple-300 font-bold flex items-center gap-1.5">
                      <GitMerge className="w-4 h-4 text-purple-400" />
                      <span>{t("dtwWeight", "انطباق دینامیکی زمانی (Dynamic Time Warping - DTW):")}</span>
                    </span>
                    <span className="text-[11px] text-slate-400 mt-0.5">
                      {isRtl
                        ? "انطباق غیرخطی با تغییرات سرعت زمانی، کشیدگی یا فشردگی موج‌ها در کندل‌های تاریخی (۰٪ تا ۱۰۰٪)"
                        : "Non-linear time-warping alignment handling variable speed, wave stretching, and compression (0% to 100%)"}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-purple-500/20 border border-purple-400/50 shrink-0">
                    <input
                      type="number"
                      min="0"
                      max="100"
                      step="5"
                      value={Math.round(tempConfig.weights.dtw * 100)}
                      onChange={(e) => {
                        const val = parseInt(e.target.value);
                        if (!isNaN(val)) {
                          setTempConfig({
                            ...tempConfig,
                            weights: {
                              ...tempConfig.weights,
                              dtw: Math.max(0, Math.min(100, val)) / 100,
                            },
                          });
                        }
                      }}
                      className="w-14 bg-transparent text-right rtl:text-left font-mono font-bold text-purple-300 text-sm focus:outline-none border-b border-purple-500/40"
                    />
                    <span className="text-[10px] text-purple-400 font-bold">%</span>
                  </div>
                </div>

                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.01"
                  value={tempConfig.weights.dtw}
                  onChange={(e) =>
                    setTempConfig({
                      ...tempConfig,
                      weights: { ...tempConfig.weights, dtw: parseFloat(e.target.value) },
                    })
                  }
                  className="w-full accent-purple-400 cursor-pointer mt-1"
                />
              </div>

              {/* 3. Slope Weight */}
              <div className="p-3.5 rounded-xl border border-emerald-500/30 bg-slate-900/90 flex flex-col gap-2 hover:border-emerald-500/50 transition-colors shadow-sm">
                <div className="flex justify-between items-center font-semibold text-slate-100 gap-3">
                  <div className="flex flex-col">
                    <span className="text-xs sm:text-sm text-emerald-300 font-bold flex items-center gap-1.5">
                      <ArrowUpRight className="w-4 h-4 text-emerald-400" />
                      <span>{t("slopeWeight", "شیب و زاویه کلی بردار (Slope Vector):")}</span>
                    </span>
                    <span className="text-[11px] text-slate-400 mt-0.5">
                      {isRtl
                        ? "تطابق جهت‌گیری کلی روند، زاویه خط رگرسیون و بردار حرکتی ابتدا تا انتهای الگو (۰٪ تا ۱۰۰٪)"
                        : "Trajectory slope alignment and regression vector matching between pattern start and end (0% to 100%)"}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500/20 border border-emerald-400/50 shrink-0">
                    <input
                      type="number"
                      min="0"
                      max="100"
                      step="5"
                      value={Math.round(tempConfig.weights.slope * 100)}
                      onChange={(e) => {
                        const val = parseInt(e.target.value);
                        if (!isNaN(val)) {
                          setTempConfig({
                            ...tempConfig,
                            weights: {
                              ...tempConfig.weights,
                              slope: Math.max(0, Math.min(100, val)) / 100,
                            },
                          });
                        }
                      }}
                      className="w-14 bg-transparent text-right rtl:text-left font-mono font-bold text-emerald-300 text-sm focus:outline-none border-b border-emerald-500/40"
                    />
                    <span className="text-[10px] text-emerald-400 font-bold">%</span>
                  </div>
                </div>

                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.01"
                  value={tempConfig.weights.slope}
                  onChange={(e) =>
                    setTempConfig({
                      ...tempConfig,
                      weights: { ...tempConfig.weights, slope: parseFloat(e.target.value) },
                    })
                  }
                  className="w-full accent-emerald-400 cursor-pointer mt-1"
                />
              </div>

              {/* 4. Structural Weight */}
              <div className="p-3.5 rounded-xl border border-amber-500/30 bg-slate-900/90 flex flex-col gap-2 hover:border-amber-500/50 transition-colors shadow-sm">
                <div className="flex justify-between items-center font-semibold text-slate-100 gap-3">
                  <div className="flex flex-col">
                    <span className="text-xs sm:text-sm text-amber-300 font-bold flex items-center gap-1.5">
                      <Mountain className="w-4 h-4 text-amber-400" />
                      <span>{t("structuralWeight", "ساختار قله‌ها و کف‌ها (Structural Extrema):")}</span>
                    </span>
                    <span className="text-[11px] text-slate-400 mt-0.5">
                      {isRtl
                        ? "انطباق هندسی موقعیت سقف‌ها و کف‌های ماژور و مینور و سطوح اکسترمم الگو (۰٪ تا ۱۰۰٪)"
                        : "Geometric alignment of pivot peaks, valleys, major swings, and extrema price levels (0% to 100%)"}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-500/20 border border-amber-400/50 shrink-0">
                    <input
                      type="number"
                      min="0"
                      max="100"
                      step="5"
                      value={Math.round(tempConfig.weights.structural * 100)}
                      onChange={(e) => {
                        const val = parseInt(e.target.value);
                        if (!isNaN(val)) {
                          setTempConfig({
                            ...tempConfig,
                            weights: {
                              ...tempConfig.weights,
                              structural: Math.max(0, Math.min(100, val)) / 100,
                            },
                          });
                        }
                      }}
                      className="w-14 bg-transparent text-right rtl:text-left font-mono font-bold text-amber-300 text-sm focus:outline-none border-b border-amber-500/40"
                    />
                    <span className="text-[10px] text-amber-400 font-bold">%</span>
                  </div>
                </div>

                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.01"
                  value={tempConfig.weights.structural}
                  onChange={(e) =>
                    setTempConfig({
                      ...tempConfig,
                      weights: { ...tempConfig.weights, structural: parseFloat(e.target.value) },
                    })
                  }
                  className="w-full accent-amber-400 cursor-pointer mt-1"
                />
              </div>

              {/* Quick Weight Profile Presets */}
              <div className="p-3 rounded-xl border border-slate-800 bg-slate-900/60 flex items-center gap-2 flex-wrap">
                <span className="text-[11px] text-slate-400 font-medium">
                  {isRtl ? "پروفایل‌های وزنی آماده:" : "Presets:"}
                </span>
                {[
                  {
                    name: isRtl ? "متعادل (Balanced)" : "Balanced",
                    w: { pearson: 0.35, dtw: 0.25, slope: 0.2, structural: 0.2 },
                  },
                  {
                    name: isRtl ? "مبتنی بر شکل (Shape-Focus)" : "Shape-Focus",
                    w: { pearson: 0.5, dtw: 0.3, slope: 0.1, structural: 0.1 },
                  },
                  {
                    name: isRtl ? "مبتنی بر پیوت‌ها (Extrema-Focus)" : "Extrema-Focus",
                    w: { pearson: 0.2, dtw: 0.2, slope: 0.2, structural: 0.4 },
                  },
                  {
                    name: isRtl ? "مبتنی بر روند (Trend-Focus)" : "Trend-Focus",
                    w: { pearson: 0.2, dtw: 0.2, slope: 0.45, structural: 0.15 },
                  },
                ].map((preset, pIdx) => {
                  const isCur =
                    Math.abs(tempConfig.weights.pearson - preset.w.pearson) < 0.02 &&
                    Math.abs(tempConfig.weights.dtw - preset.w.dtw) < 0.02 &&
                    Math.abs(tempConfig.weights.slope - preset.w.slope) < 0.02 &&
                    Math.abs(tempConfig.weights.structural - preset.w.structural) < 0.02;

                  return (
                    <button
                      key={pIdx}
                      type="button"
                      onClick={() =>
                        setTempConfig({
                          ...tempConfig,
                          weights: { ...preset.w },
                        })
                      }
                      className={`px-2.5 py-1 text-[11px] rounded-lg border transition-all cursor-pointer ${
                        isCur
                          ? "bg-cyan-500 text-slate-950 font-bold border-cyan-300 shadow-sm"
                          : "bg-slate-950/80 hover:bg-slate-800 text-slate-300 border-slate-800"
                      }`}
                    >
                      {preset.name}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 5: Market Data Manager */}
          {activeTab === "data" && (
            <MarketDataManager
              datasets={datasets}
              onUpdateDatasets={onUpdateDatasets}
              selectedDatasetIds={selectedDatasetIds}
              onToggleDatasetId={onToggleDatasetId}
              onSetSelectedDatasetIds={onSetSelectedDatasetIds}
              onSelectAllDatasets={onSelectAllDatasets}
              savedPatterns={savedPatterns}
              includeCustomPatternsInSearch={includeCustomPatternsInSearch}
              onToggleIncludeCustomPatterns={onToggleIncludeCustomPatterns}
              includeTALibPatternsInSearch={includeTALibPatternsInSearch}
              onToggleIncludeTALibPatterns={onToggleIncludeTALibPatterns}
              onNavigateToPatternExtractor={() => setActiveTab("patternExtractor")}
              isPersian={activeLanguage === "fa"}
            />
          )}

          {/* TAB 6: Image Pattern Extractor & DNA Library */}
          {activeTab === "patternExtractor" && (
            <ImagePatternExtractorTab
              savedPatterns={savedPatterns}
              onSavePattern={onSavePattern}
              onDeletePattern={onDeletePattern}
              onApplyAsActiveReference={(points, name) => {
                onApplyAsActiveReference(points, name);
                onClose();
              }}
              onRunSearchWithPattern={(points, name) => {
                if (onRunSearchWithPattern) {
                  onRunSearchWithPattern(points, name);
                } else {
                  onApplyAsActiveReference(points, name);
                }
                onClose();
              }}
              extractorPointCount={tempConfig.extractorPointCount ?? 500}
              activeLanguage={activeLanguage}
              activeTheme={activeTheme}
            />
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-900/90 border-t border-slate-800/80 px-4 sm:px-6 py-3 flex items-center justify-between">
          <button
            onClick={handleResetDefaults}
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200 px-3 py-1.5 bg-white/[0.04] hover:bg-white/[0.08] rounded-xl border border-white/[0.08] transition-all cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{t("resetDefaults", "بازنشانی پیش‌فرض")}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3.5 py-1.5 text-xs font-semibold text-slate-400 hover:text-slate-200 transition-all cursor-pointer"
            >
              {t("clearAll", "بستن")}
            </button>
            <button
              onClick={handleSave}
              className="flex items-center gap-1.5 px-4 py-1.5 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-200 hover:text-white border border-emerald-400/40 font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer active:scale-[0.98]"
            >
              <Check className="w-4 h-4" />
              <span>{t("saveAndApply", "ذخیره و بستن")}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
