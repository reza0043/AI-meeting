import React, { useState, useRef, useEffect } from "react";
import {
  TrendingUp,
  TrendingDown,
  Activity,
  ArrowUpRight,
  ArrowDownRight,
  Target,
  Layers,
  DollarSign,
  Percent,
  Sliders,
  Sparkles,
  BarChart2,
  CheckCircle2,
  Info,
  ChevronRight,
  Eye,
  EyeOff,
  Maximize2,
  ZoomIn,
  RefreshCw,
  LayoutGrid,
  Image as ImageIcon,
  Minus,
} from "lucide-react";
import {
  PatternExtremaAnalysis,
  ForwardScenarioAnalysis,
} from "../engine/patternExtrema";
import { formatRealPrice } from "../engine/priceScaleDetector";
import { CropRect } from "./ImageCropperCanvas";
import { LanguageCode, getTranslation } from "../i18n/languages";
import { ThemeId, getTheme } from "../theme/themes";

interface PatternExtremaTargetsPanelProps {
  imageSrc: string | null;
  cropBox: CropRect | null;
  extrema: PatternExtremaAnalysis | null;
  scenarios: ForwardScenarioAnalysis | null;
  futureCandlesCount?: number;
  referencePrice?: number | null;
  onUpdateReferencePrice?: (price: number | null) => void;
  activeLanguage: LanguageCode;
  activeTheme?: ThemeId;
}

export const PatternExtremaTargetsPanel: React.FC<PatternExtremaTargetsPanelProps> = ({
  imageSrc,
  cropBox,
  extrema,
  scenarios,
  futureCandlesCount = 70,
  referencePrice,
  onUpdateReferencePrice,
  activeLanguage,
  activeTheme = "cyber-obsidian",
}) => {
  const [showResistanceLines, setShowResistanceLines] = useState(true);
  const [showSupportLines, setShowSupportLines] = useState(true);
  const [showPriceLabels, setShowPriceLabels] = useState(true);
  const [showPatternTrace, setShowPatternTrace] = useState(true);
  const [isFullscreenVisual, setIsFullscreenVisual] = useState(false);
  const [imageObj, setImageObj] = useState<HTMLImageElement | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fullscreenCanvasRef = useRef<HTMLCanvasElement>(null);

  const t = (key: string, fallback?: string) => getTranslation(activeLanguage, key, fallback);
  const theme = getTheme(activeTheme);
  const isPersian = activeLanguage === "fa" || activeLanguage === "ar";

  const isRealPrice = !!(
    (referencePrice != null && referencePrice > 0) ||
    (extrema && extrema.isRealPriceAvailable && extrema.realCurrentPrice != null)
  );
  const activeRealPrice = referencePrice ?? extrema?.realCurrentPrice ?? null;
  const decimals = extrema?.decimals ?? 2;

  // Load image object whenever imageSrc changes
  useEffect(() => {
    if (!imageSrc) {
      setImageObj(null);
      return;
    }
    let isCancelled = false;
    const img = new Image();
    if (imageSrc.startsWith("http")) {
      img.crossOrigin = "anonymous";
    }
    img.onload = () => {
      if (!isCancelled) {
        setImageObj(img);
      }
    };
    img.onerror = (err) => {
      console.warn("Overlay image load error:", err);
      if (!isCancelled) {
        setImageObj(null);
      }
    };
    img.src = imageSrc;

    if (img.complete && img.naturalWidth > 0) {
      setImageObj(img);
    }

    return () => {
      isCancelled = true;
    };
  }, [imageSrc]);

  // Re-render canvas whenever image or overlay options change
  useEffect(() => {
    const frame = requestAnimationFrame(() => {
      renderChartOverlay(canvasRef.current, false);
      if (isFullscreenVisual) {
        renderChartOverlay(fullscreenCanvasRef.current, true);
      }
    });
    return () => cancelAnimationFrame(frame);
  }, [
    imageObj,
    imageSrc,
    cropBox,
    extrema,
    scenarios,
    showResistanceLines,
    showSupportLines,
    showPriceLabels,
    showPatternTrace,
    isFullscreenVisual,
    activeTheme,
    activeLanguage,
  ]);

  // ResizeObserver on canvas container
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handleResize = () => {
      renderChartOverlay(canvasRef.current, false);
      if (isFullscreenVisual) {
        renderChartOverlay(fullscreenCanvasRef.current, true);
      }
    };

    const ro = new ResizeObserver(handleResize);
    ro.observe(container);
    return () => ro.disconnect();
  }, [isFullscreenVisual, imageObj, extrema]);

  /**
   * Main Visual Drawing Function:
   * - Mode 1: Draws base uploaded chart image with horizontal resistance & support lines
   * - Mode 2: If no uploaded image, draws a high-precision synthetic dark chart grid with the pattern wave and horizontal levels
   * - Mode 3: If no pattern yet, draws an empty financial grid with instructions
   */
  const renderChartOverlay = (canvas: HTMLCanvasElement | null, isFullscreen = false) => {
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Determine dimensions
    if (imageObj && (imageObj.naturalWidth || imageObj.width)) {
      const imgW = imageObj.naturalWidth || imageObj.width;
      const imgH = imageObj.naturalHeight || imageObj.height;
      canvas.width = imgW;
      canvas.height = imgH;

      // 1. Draw base uploaded chart image
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(imageObj, 0, 0, imgW, imgH);

      // If no extrema data or crop box, we stop after drawing the image
      if (!extrema || extrema.peaks.length === 0 || !cropBox) {
        return;
      }

      const n = extrema.pattern.length;
      if (n < 2) return;

      const { x: cx, y: cy, width: cw, height: ch } = cropBox;
      const minVal = extrema.minPrice;
      const maxVal = extrema.maxPrice;
      const span = maxVal - minVal || 1;

      // Helper: Map pattern index and value to Canvas Pixel coordinates
      const getPointPixel = (index: number, val: number) => {
        const relCoord = extrema.relativeCoords?.[index];
        if (relCoord) {
          return {
            x: cx + relCoord.relX * cw,
            y: cy + relCoord.relY * ch,
          };
        }
        const px = cx + (index / (n - 1)) * cw;
        const normY = (val - minVal) / span;
        const py = cy + (1 - normY) * ch;
        return { x: px, y: py };
      };

      // 2. Draw Crop Bounding Box Highlight
      ctx.save();
      ctx.strokeStyle = "rgba(56, 189, 248, 0.45)"; // cyan subtle
      ctx.lineWidth = 1.5;
      ctx.setLineDash([5, 5]);
      ctx.strokeRect(cx, cy, cw, ch);
      ctx.restore();

      // 3. Optional Pattern Trace Line inside the cropped box
      if (showPatternTrace) {
        ctx.save();
        ctx.beginPath();
        for (let i = 0; i < n; i++) {
          const pt = getPointPixel(i, extrema.pattern[i]);
          if (i === 0) ctx.moveTo(pt.x, pt.y);
          else ctx.lineTo(pt.x, pt.y);
        }
        ctx.strokeStyle = "rgba(56, 189, 248, 0.85)";
        ctx.lineWidth = 2.5;
        ctx.shadowColor = "rgba(6, 182, 212, 0.7)";
        ctx.shadowBlur = 6;
        ctx.stroke();
        ctx.restore();
      }

      // 4. Draw Horizontal Resistance Lines & Badges for each Peak (سقف‌ها به عنوان خطوط مقاومت افقی)
      if (showResistanceLines) {
        extrema.peaks.forEach((p, idx) => {
          const pt = getPointPixel(p.index, p.value);

          ctx.save();
          // Horizontal Resistance Line spanning across the chart
          ctx.beginPath();
          ctx.moveTo(Math.max(0, cx - 20), pt.y);
          ctx.lineTo(canvas.width, pt.y);
          ctx.strokeStyle = p.isMajor ? "rgba(16, 185, 129, 0.9)" : "rgba(52, 211, 153, 0.75)"; // emerald
          ctx.lineWidth = p.isMajor ? 2 : 1.2;
          ctx.setLineDash([6, 4]);
          ctx.shadowColor = "rgba(16, 185, 129, 0.6)";
          ctx.shadowBlur = 4;
          ctx.stroke();
          ctx.restore();

          // Glowing dot at the peak location on the pattern
          ctx.save();
          ctx.beginPath();
          ctx.arc(pt.x, pt.y, p.isMajor ? 6 : 4.5, 0, Math.PI * 2);
          ctx.fillStyle = "#10b981";
          ctx.shadowColor = "#34d399";
          ctx.shadowBlur = 10;
          ctx.fill();

          ctx.beginPath();
          ctx.arc(pt.x, pt.y, 2, 0, Math.PI * 2);
          ctx.fillStyle = "#ffffff";
          ctx.fill();
          ctx.restore();

          // Price Level Label Badge on the horizontal line
          if (showPriceLabels) {
            ctx.save();
            const pctStr = p.percentFromCurrent >= 0 ? `+${p.percentFromCurrent.toFixed(1)}%` : `${p.percentFromCurrent.toFixed(1)}%`;
            const labelText =
              isRealPrice && p.realPrice != null
                ? `R${idx + 1} [سقف]: ${formatRealPrice(p.realPrice, decimals)} (${pctStr})`
                : `R${idx + 1} [Peak #${p.index + 1}]: ${pctStr}`;

            ctx.font = "bold 11px sans-serif";
            const textMetrics = ctx.measureText(labelText);
            const badgeWidth = textMetrics.width + 12;
            const badgeHeight = 18;

            const badgeX = Math.min(canvas.width - badgeWidth - 8, Math.max(cx + 10, pt.x + 12));
            const badgeY = Math.max(6, pt.y - badgeHeight / 2);

            ctx.fillStyle = "rgba(6, 78, 59, 0.95)";
            ctx.strokeStyle = "#34d399";
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.roundRect(badgeX, badgeY, badgeWidth, badgeHeight, 4);
            ctx.fill();
            ctx.stroke();

            ctx.fillStyle = "#ecfdf5";
            ctx.textAlign = "center";
            ctx.textBaseline = "middle";
            ctx.fillText(labelText, badgeX + badgeWidth / 2, badgeY + badgeHeight / 2);
            ctx.restore();
          }
        });
      }

      // 5. Draw Horizontal Support Lines & Badges for each Valley (کف‌ها به عنوان خطوط حمایت افقی)
      if (showSupportLines) {
        extrema.valleys.forEach((v, idx) => {
          const pt = getPointPixel(v.index, v.value);

          ctx.save();
          // Horizontal Support Line spanning across the chart
          ctx.beginPath();
          ctx.moveTo(Math.max(0, cx - 20), pt.y);
          ctx.lineTo(canvas.width, pt.y);
          ctx.strokeStyle = v.isMajor ? "rgba(244, 63, 94, 0.9)" : "rgba(251, 113, 133, 0.75)"; // rose/red
          ctx.lineWidth = v.isMajor ? 2 : 1.2;
          ctx.setLineDash([6, 4]);
          ctx.shadowColor = "rgba(244, 63, 94, 0.6)";
          ctx.shadowBlur = 4;
          ctx.stroke();
          ctx.restore();

          // Glowing dot at the valley location on the pattern
          ctx.save();
          ctx.beginPath();
          ctx.arc(pt.x, pt.y, v.isMajor ? 6 : 4.5, 0, Math.PI * 2);
          ctx.fillStyle = "#f43f5e";
          ctx.shadowColor = "#fb7185";
          ctx.shadowBlur = 10;
          ctx.fill();

          ctx.beginPath();
          ctx.arc(pt.x, pt.y, 2, 0, Math.PI * 2);
          ctx.fillStyle = "#ffffff";
          ctx.fill();
          ctx.restore();

          // Price Level Label Badge on the horizontal line
          if (showPriceLabels) {
            ctx.save();
            const pctStr = v.percentFromCurrent >= 0 ? `+${v.percentFromCurrent.toFixed(1)}%` : `${v.percentFromCurrent.toFixed(1)}%`;
            const labelText =
              isRealPrice && v.realPrice != null
                ? `S${idx + 1} [کف]: ${formatRealPrice(v.realPrice, decimals)} (${pctStr})`
                : `S${idx + 1} [Valley #${v.index + 1}]: ${pctStr}`;

            ctx.font = "bold 11px sans-serif";
            const textMetrics = ctx.measureText(labelText);
            const badgeWidth = textMetrics.width + 12;
            const badgeHeight = 18;

            const badgeX = Math.min(canvas.width - badgeWidth - 8, Math.max(cx + 10, pt.x + 12));
            const badgeY = Math.max(6, pt.y - badgeHeight / 2);

            ctx.fillStyle = "rgba(136, 19, 55, 0.95)";
            ctx.strokeStyle = "#fb7185";
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.roundRect(badgeX, badgeY, badgeWidth, badgeHeight, 4);
            ctx.fill();
            ctx.stroke();

            ctx.fillStyle = "#fff1f2";
            ctx.textAlign = "center";
            ctx.textBaseline = "middle";
            ctx.fillText(labelText, badgeX + badgeWidth / 2, badgeY + badgeHeight / 2);
            ctx.restore();
          }
        });
      }

      // 6. Current Price Level Marker at Pattern End
      const lastPoint = getPointPixel(n - 1, extrema.pattern[n - 1]);
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(lastPoint.x, lastPoint.y);
      ctx.lineTo(canvas.width, lastPoint.y);
      ctx.strokeStyle = "rgba(6, 182, 212, 0.85)"; // cyan
      ctx.lineWidth = 1.5;
      ctx.setLineDash([3, 3]);
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(lastPoint.x, lastPoint.y, 5.5, 0, Math.PI * 2);
      ctx.fillStyle = "#06b6d4";
      ctx.shadowColor = "#38bdf8";
      ctx.shadowBlur = 10;
      ctx.fill();

      ctx.beginPath();
      ctx.arc(lastPoint.x, lastPoint.y, 2, 0, Math.PI * 2);
      ctx.fillStyle = "#ffffff";
      ctx.fill();

      if (showPriceLabels) {
        const curLabel =
          isRealPrice && extrema.realCurrentPrice != null
            ? `قیمت جاری: ${formatRealPrice(extrema.realCurrentPrice, decimals)}`
            : `قیمت انتهای الگو: ${extrema.currentPrice.toFixed(2)}`;

        ctx.font = "bold 10px sans-serif";
        const textMetrics = ctx.measureText(curLabel);
        const badgeWidth = textMetrics.width + 10;
        const badgeHeight = 18;
        const badgeX = Math.min(canvas.width - badgeWidth - 8, lastPoint.x + 8);
        const badgeY = Math.max(6, lastPoint.y - 20);

        ctx.fillStyle = "rgba(8, 51, 68, 0.95)";
        ctx.strokeStyle = "#06b6d4";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.roundRect(badgeX, badgeY, badgeWidth, badgeHeight, 4);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = "#cffafe";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(curLabel, badgeX + badgeWidth / 2, badgeY + badgeHeight / 2);
      }
      ctx.restore();
      return;
    }

    // =========================================================================
    // Mode 2: Synthetic Financial Chart Grid (When no uploaded image is loaded)
    // =========================================================================
    const container = isFullscreen ? fullscreenCanvasRef.current?.parentElement : containerRef.current;
    const cw = container ? container.clientWidth || 600 : 600;
    const ch = container ? container.clientHeight || 340 : 340;
    const dpr = window.devicePixelRatio || 1;

    canvas.width = Math.max(400, Math.round(cw * dpr));
    canvas.height = Math.max(260, Math.round(ch * dpr));

    const w = canvas.width;
    const h = canvas.height;

    // 1. Dark Gradient Background
    const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
    bgGrad.addColorStop(0, "#080d1a");
    bgGrad.addColorStop(1, "#03060c");
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, w, h);

    // 2. Subtle Financial Grid Lines
    ctx.save();
    ctx.strokeStyle = "rgba(148, 163, 184, 0.08)";
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 4]);

    const gridRows = 6;
    for (let r = 1; r < gridRows; r++) {
      const gy = (h / gridRows) * r;
      ctx.beginPath();
      ctx.moveTo(0, gy);
      ctx.lineTo(w, gy);
      ctx.stroke();
    }

    const gridCols = 8;
    for (let c = 1; c < gridCols; c++) {
      const gx = (w / gridCols) * c;
      ctx.beginPath();
      ctx.moveTo(gx, 0);
      ctx.lineTo(gx, h);
      ctx.stroke();
    }
    ctx.restore();

    // If no pattern / extrema available, draw guidance placeholder
    if (!extrema || extrema.peaks.length === 0 || extrema.pattern.length < 2) {
      ctx.save();
      ctx.fillStyle = "rgba(148, 163, 184, 0.6)";
      ctx.font = "bold 13px sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(
        isPersian
          ? "در انتظار انتخاب یا برش الگو برای رسم سطوح حمایت و مقاومت"
          : "Waiting for pattern crop or selection to render support & resistance levels",
        w / 2,
        h / 2
      );
      ctx.restore();
      return;
    }

    // Draw synthetic pattern curve + support/resistance levels
    const padX = 40;
    const padY = 35;
    const chartW = w - padX * 2;
    const chartH = h - padY * 2;

    const n = extrema.pattern.length;
    const minVal = extrema.minPrice;
    const maxVal = extrema.maxPrice;
    const span = maxVal - minVal || 1;

    const getSynthPoint = (idx: number, val: number) => {
      const px = padX + (idx / (n - 1)) * chartW;
      const normY = (val - minVal) / span;
      const py = padY + (1 - normY) * chartH;
      return { x: px, y: py };
    };

    // Fill under pattern curve
    if (showPatternTrace) {
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(padX, padY + chartH);
      for (let i = 0; i < n; i++) {
        const pt = getSynthPoint(i, extrema.pattern[i]);
        ctx.lineTo(pt.x, pt.y);
      }
      ctx.lineTo(padX + chartW, padY + chartH);
      ctx.closePath();

      const fillGrad = ctx.createLinearGradient(0, padY, 0, padY + chartH);
      fillGrad.addColorStop(0, "rgba(6, 182, 212, 0.25)");
      fillGrad.addColorStop(1, "rgba(6, 182, 212, 0.0)");
      ctx.fillStyle = fillGrad;
      ctx.fill();

      // Main trace line
      ctx.beginPath();
      for (let i = 0; i < n; i++) {
        const pt = getSynthPoint(i, extrema.pattern[i]);
        if (i === 0) ctx.moveTo(pt.x, pt.y);
        else ctx.lineTo(pt.x, pt.y);
      }
      ctx.strokeStyle = "#38bdf8";
      ctx.lineWidth = 2.5;
      ctx.shadowColor = "rgba(56, 189, 248, 0.7)";
      ctx.shadowBlur = 8;
      ctx.stroke();
      ctx.restore();
    }

    // Draw Resistance Lines (سقف‌ها)
    if (showResistanceLines) {
      extrema.peaks.forEach((p, idx) => {
        const pt = getSynthPoint(p.index, p.value);

        ctx.save();
        ctx.beginPath();
        ctx.moveTo(0, pt.y);
        ctx.lineTo(w, pt.y);
        ctx.strokeStyle = p.isMajor ? "rgba(16, 185, 129, 0.9)" : "rgba(52, 211, 153, 0.75)";
        ctx.lineWidth = p.isMajor ? 2 : 1.2;
        ctx.setLineDash([6, 4]);
        ctx.shadowColor = "rgba(16, 185, 129, 0.6)";
        ctx.shadowBlur = 4;
        ctx.stroke();
        ctx.restore();

        // Dot
        ctx.save();
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, p.isMajor ? 5.5 : 4, 0, Math.PI * 2);
        ctx.fillStyle = "#10b981";
        ctx.shadowColor = "#34d399";
        ctx.shadowBlur = 8;
        ctx.fill();
        ctx.restore();

        // Badge
        if (showPriceLabels) {
          ctx.save();
          const pctStr = p.percentFromCurrent >= 0 ? `+${p.percentFromCurrent.toFixed(1)}%` : `${p.percentFromCurrent.toFixed(1)}%`;
          const labelText =
            isRealPrice && p.realPrice != null
              ? `R${idx + 1}: ${formatRealPrice(p.realPrice, decimals)} (${pctStr})`
              : `R${idx + 1}: ${pctStr}`;

          ctx.font = "bold 11px sans-serif";
          const textMetrics = ctx.measureText(labelText);
          const bw = textMetrics.width + 12;
          const bh = 18;
          const bx = Math.min(w - bw - 8, Math.max(10, pt.x + 12));
          const by = Math.max(6, pt.y - bh / 2);

          ctx.fillStyle = "rgba(6, 78, 59, 0.95)";
          ctx.strokeStyle = "#34d399";
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.roundRect(bx, by, bw, bh, 4);
          ctx.fill();
          ctx.stroke();

          ctx.fillStyle = "#ecfdf5";
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.fillText(labelText, bx + bw / 2, by + bh / 2);
          ctx.restore();
        }
      });
    }

    // Draw Support Lines (کف‌ها)
    if (showSupportLines) {
      extrema.valleys.forEach((v, idx) => {
        const pt = getSynthPoint(v.index, v.value);

        ctx.save();
        ctx.beginPath();
        ctx.moveTo(0, pt.y);
        ctx.lineTo(w, pt.y);
        ctx.strokeStyle = v.isMajor ? "rgba(244, 63, 94, 0.9)" : "rgba(251, 113, 133, 0.75)";
        ctx.lineWidth = v.isMajor ? 2 : 1.2;
        ctx.setLineDash([6, 4]);
        ctx.shadowColor = "rgba(244, 63, 94, 0.6)";
        ctx.shadowBlur = 4;
        ctx.stroke();
        ctx.restore();

        // Dot
        ctx.save();
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, v.isMajor ? 5.5 : 4, 0, Math.PI * 2);
        ctx.fillStyle = "#f43f5e";
        ctx.shadowColor = "#fb7185";
        ctx.shadowBlur = 8;
        ctx.fill();
        ctx.restore();

        // Badge
        if (showPriceLabels) {
          ctx.save();
          const pctStr = v.percentFromCurrent >= 0 ? `+${v.percentFromCurrent.toFixed(1)}%` : `${v.percentFromCurrent.toFixed(1)}%`;
          const labelText =
            isRealPrice && v.realPrice != null
              ? `S${idx + 1}: ${formatRealPrice(v.realPrice, decimals)} (${pctStr})`
              : `S${idx + 1}: ${pctStr}`;

          ctx.font = "bold 11px sans-serif";
          const textMetrics = ctx.measureText(labelText);
          const bw = textMetrics.width + 12;
          const bh = 18;
          const bx = Math.min(w - bw - 8, Math.max(10, pt.x + 12));
          const by = Math.max(6, pt.y - bh / 2);

          ctx.fillStyle = "rgba(136, 19, 55, 0.95)";
          ctx.strokeStyle = "#fb7185";
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.roundRect(bx, by, bw, bh, 4);
          ctx.fill();
          ctx.stroke();

          ctx.fillStyle = "#fff1f2";
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.fillText(labelText, bx + bw / 2, by + bh / 2);
          ctx.restore();
        }
      });
    }

    // Current Price End Line & Badge
    const lastPoint = getSynthPoint(n - 1, extrema.pattern[n - 1]);
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(0, lastPoint.y);
    ctx.lineTo(w, lastPoint.y);
    ctx.strokeStyle = "rgba(6, 182, 212, 0.85)";
    ctx.lineWidth = 1.5;
    ctx.setLineDash([3, 3]);
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(lastPoint.x, lastPoint.y, 5, 0, Math.PI * 2);
    ctx.fillStyle = "#06b6d4";
    ctx.shadowColor = "#38bdf8";
    ctx.shadowBlur = 8;
    ctx.fill();

    if (showPriceLabels) {
      const curLabel =
        isRealPrice && extrema.realCurrentPrice != null
          ? `قیمت جاری: ${formatRealPrice(extrema.realCurrentPrice, decimals)}`
          : `قیمت پایانی: ${extrema.currentPrice.toFixed(2)}`;

      ctx.font = "bold 10px sans-serif";
      const textMetrics = ctx.measureText(curLabel);
      const bw = textMetrics.width + 10;
      const bh = 18;
      const bx = Math.min(w - bw - 8, lastPoint.x + 8);
      const by = Math.max(6, lastPoint.y - 20);

      ctx.fillStyle = "rgba(8, 51, 68, 0.95)";
      ctx.strokeStyle = "#06b6d4";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.roundRect(bx, by, bw, bh, 4);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = "#cffafe";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(curLabel, bx + bw / 2, by + bh / 2);
    }
    ctx.restore();
  };

  return (
    <div className="w-full flex flex-col gap-2.5">
      {/* ========================================================================= */}
      {/* 1. First Window: Chart Overlay Visualizer (پنجره رسم چارت با سایز محیط الگو) */}
      {/* ========================================================================= */}
      <div
        id="pattern-overlay-canvas-card"
        className="border rounded-2xl p-2 flex flex-col gap-1.5 shadow-lg w-full backdrop-blur-xl h-[340px] md:h-[390px] transition-colors duration-200 overflow-hidden"
        style={{
          backgroundColor: `${theme.colors.cardBg}f0`,
          borderColor: theme.colors.border,
          color: theme.colors.text,
        }}
      >
        {/* Header Toolbar */}
        <div
          className="flex items-center justify-between gap-1.5 border-b pb-1.5"
          style={{ borderColor: theme.colors.borderSubtle }}
        >
          <div className="flex items-center gap-1.5 font-bold text-xs" style={{ color: theme.colors.text }}>
            <Activity className="w-4 h-4 text-cyan-400 shrink-0" />
            <span className="text-xs font-bold tracking-tight truncate">
              {isPersian ? "رسم چارت و سطوح تحلیل الگو" : "Pattern Chart Overlay"}
            </span>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {/* Active Reference Price Indicator */}
            {activeRealPrice != null && (
              <div className="flex items-center gap-1 px-1.5 py-0.5 rounded-lg border bg-slate-900/80 border-slate-800 text-[10px] shadow-inner">
                <DollarSign className="w-3 h-3 text-emerald-400 shrink-0" />
                <span className="font-mono font-bold text-emerald-400 text-[10px]">
                  {formatRealPrice(activeRealPrice, decimals)}
                </span>
              </div>
            )}

            {/* Fullscreen Modal Toggle */}
            <button
              onClick={() => setIsFullscreenVisual(true)}
              title={isPersian ? "بزرگنمایی تمام‌صفحه چارت" : "Fullscreen Overlay"}
              className="p-1 rounded-lg border border-slate-800 hover:border-slate-700 bg-slate-900/60 hover:bg-slate-800 text-slate-300 transition-colors cursor-pointer"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Quick Drawing Layer Toggles */}
        {extrema && extrema.peaks.length > 0 && (
          <div className="flex items-center gap-1 overflow-x-auto pb-0.5 text-[9px] text-slate-300 font-medium shrink-0">
            <button
              onClick={() => setShowResistanceLines(!showResistanceLines)}
              className={`flex items-center gap-1 px-1.5 py-0.5 rounded-md border transition-all cursor-pointer shrink-0 ${
                showResistanceLines
                  ? "bg-emerald-950/50 border-emerald-500/50 text-emerald-300 font-semibold"
                  : "bg-slate-900/80 border-slate-800 text-slate-500"
              }`}
              title={isPersian ? "خطوط افقی مقاومت" : "Resistance Lines"}
            >
              <Minus className="w-2.5 h-2.5 text-emerald-400" />
              <span>{isPersian ? "مقاومت (سقف)" : "Resistance"}</span>
            </button>

            <button
              onClick={() => setShowSupportLines(!showSupportLines)}
              className={`flex items-center gap-1 px-1.5 py-0.5 rounded-md border transition-all cursor-pointer shrink-0 ${
                showSupportLines
                  ? "bg-rose-950/50 border-rose-500/50 text-rose-300 font-semibold"
                  : "bg-slate-900/80 border-slate-800 text-slate-500"
              }`}
              title={isPersian ? "خطوط افقی حمایت" : "Support Lines"}
            >
              <Minus className="w-2.5 h-2.5 text-rose-400" />
              <span>{isPersian ? "حمایت (کف)" : "Support"}</span>
            </button>

            <button
              onClick={() => setShowPriceLabels(!showPriceLabels)}
              className={`flex items-center gap-1 px-1.5 py-0.5 rounded-md border transition-all cursor-pointer shrink-0 ${
                showPriceLabels
                  ? "bg-purple-950/50 border-purple-500/50 text-purple-300 font-semibold"
                  : "bg-slate-900/80 border-slate-800 text-slate-500"
              }`}
              title={isPersian ? "برچسب مبالغ و سطوح" : "Price Labels"}
            >
              <span>🏷️</span>
              <span>{isPersian ? "قیمت‌ها" : "Prices"}</span>
            </button>

            <button
              onClick={() => setShowPatternTrace(!showPatternTrace)}
              className={`flex items-center gap-1 px-1.5 py-0.5 rounded-md border transition-all cursor-pointer shrink-0 ${
                showPatternTrace
                  ? "bg-cyan-950/50 border-cyan-500/50 text-cyan-300 font-semibold"
                  : "bg-slate-900/80 border-slate-800 text-slate-500"
              }`}
              title={isPersian ? "مسیر الگو" : "Pattern Wave"}
            >
              <span>〰️</span>
              <span>{isPersian ? "موج الگو" : "Wave"}</span>
            </button>
          </div>
        )}

        {/* Canvas Visualizer Area */}
        <div
          ref={containerRef}
          className="relative flex-1 border rounded-xl overflow-hidden flex items-center justify-center min-h-[220px] w-full"
          style={{
            backgroundColor: theme.colors.bg,
            borderColor: theme.colors.borderSubtle,
          }}
        >
          <div className="w-full h-full flex items-center justify-center p-1 overflow-hidden">
            <canvas
              ref={canvasRef}
              className="max-w-full max-h-full object-contain rounded-lg shadow-md block"
            />
          </div>

          {/* Floating badge */}
          {extrema && extrema.peaks.length > 0 && (
            <div className="absolute top-1.5 left-1.5 px-2 py-0.5 rounded-md bg-slate-950/85 border border-slate-800 text-[9px] text-cyan-300 font-mono flex items-center gap-1 backdrop-blur-md shadow-sm pointer-events-none">
              <Activity className="w-2.5 h-2.5 text-cyan-400" />
              <span>{isPersian ? (imageSrc ? "سطوح افقی چارت" : "چارت تحلیلی الگو") : "Levels Overlay"}</span>
            </div>
          )}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. Second Window: Extrema & Scenario Statistical Cards (کارت‌های آماری)   */}
      {/* ========================================================================= */}
      <div
        id="pattern-stats-cards-card"
        className="border rounded-2xl p-2.5 flex flex-col gap-2 shadow-lg w-full backdrop-blur-xl transition-colors duration-200 overflow-hidden"
        style={{
          backgroundColor: `${theme.colors.cardBg}f0`,
          borderColor: theme.colors.border,
          color: theme.colors.text,
        }}
      >
        {/* Header Toolbar */}
        <div
          className="flex items-center justify-between gap-1.5 border-b pb-1.5"
          style={{ borderColor: theme.colors.borderSubtle }}
        >
          <div className="flex items-center gap-1.5 font-bold text-xs" style={{ color: theme.colors.text }}>
            <BarChart2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="text-xs font-bold tracking-tight truncate">
              {isPersian ? "کارت‌های آماری تحلیل الگو" : "Pattern Stats & Targets"}
            </span>
          </div>

          {/* Quick stats high/low */}
          {extrema && (
            <div className="flex items-center gap-1.5 font-mono text-[9px] text-slate-400 shrink-0">
              <span className="text-emerald-400 font-bold">
                H: {(extrema.highestPeak?.percentFromCurrent ?? 0) >= 0 ? `+${extrema.highestPeak?.percentFromCurrent.toFixed(1)}%` : `${extrema.highestPeak?.percentFromCurrent.toFixed(1)}%`}
              </span>
              <span>|</span>
              <span className="text-rose-400 font-bold">
                L: {(extrema.lowestValley?.percentFromCurrent ?? 0) >= 0 ? `+${extrema.lowestValley?.percentFromCurrent.toFixed(1)}%` : `${extrema.lowestValley?.percentFromCurrent.toFixed(1)}%`}
              </span>
            </div>
          )}
        </div>

        {/* Statistical Cards Content */}
        {!extrema || extrema.peaks.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-1 text-center p-4 text-slate-400">
            <BarChart2 className="w-5 h-5 text-slate-600" />
            <p className="text-xs font-medium text-slate-400">
              {isPersian ? "آماری برای نمایش وجود ندارد" : "No stats available yet"}
            </p>
            <p className="text-[10px] text-slate-500">
              {isPersian ? "الگو را در پنجره بالا برش دهید تا سطوح و تارگت‌ها محاسبه شوند." : "Crop a pattern to calculate levels and targets."}
            </p>
          </div>
        ) : (
          <div className="flex flex-col gap-2">
            {/* 1. Resistance Levels (Peaks) List */}
            <div className="p-2 rounded-xl border bg-emerald-950/20 border-emerald-500/30 flex flex-col gap-1 shadow-sm">
              <div className="flex items-center justify-between text-xs font-bold text-emerald-300">
                <div className="flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-[11px]">{isPersian ? "سطوح افقی مقاومت (سقف‌ها)" : "Resistance Levels"}</span>
                </div>
                <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300">
                  {extrema.peaks.length} {isPersian ? "سطح" : "Levels"}
                </span>
              </div>

              <div className="flex flex-col gap-1 max-h-28 overflow-y-auto pr-1 text-xs">
                {extrema.peaks.map((p, idx) => (
                  <div
                    key={`peak-lvl-${p.index}`}
                    className="flex items-center justify-between p-1 rounded-lg bg-emerald-900/25 border border-emerald-500/20"
                  >
                    <div className="flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                      <span className="text-[10px] font-semibold text-emerald-200">
                        {isPersian ? `سطح R${idx + 1} (نقطه ${p.index + 1})` : `R${idx + 1} (#${p.index + 1})`}
                        {p.isMajor && (
                          <span className="ml-1 text-[8px] px-1 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-normal">
                            {isPersian ? "ماژور" : "Major"}
                          </span>
                        )}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 font-mono">
                      <span className="font-bold text-emerald-100 text-[11px]">
                        {isRealPrice && p.realPrice != null
                          ? formatRealPrice(p.realPrice, decimals)
                          : p.value.toFixed(2)}
                      </span>
                      <span className="text-[9px] text-emerald-400 font-semibold">
                        {p.percentFromCurrent >= 0 ? `+${p.percentFromCurrent.toFixed(1)}%` : `${p.percentFromCurrent.toFixed(1)}%`}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 2. Support Levels (Valleys) List */}
            <div className="p-2 rounded-xl border bg-rose-950/20 border-rose-500/30 flex flex-col gap-1 shadow-sm">
              <div className="flex items-center justify-between text-xs font-bold text-rose-300">
                <div className="flex items-center gap-1">
                  <TrendingDown className="w-3.5 h-3.5 text-rose-400" />
                  <span className="text-[11px]">{isPersian ? "سطوح افقی حمایت (کف‌ها)" : "Support Levels"}</span>
                </div>
                <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300">
                  {extrema.valleys.length} {isPersian ? "سطح" : "Levels"}
                </span>
              </div>

              <div className="flex flex-col gap-1 max-h-28 overflow-y-auto pr-1 text-xs">
                {extrema.valleys.map((v, idx) => (
                  <div
                    key={`valley-lvl-${v.index}`}
                    className="flex items-center justify-between p-1 rounded-lg bg-rose-900/25 border border-rose-500/20"
                  >
                    <div className="flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />
                      <span className="text-[10px] font-semibold text-rose-200">
                        {isPersian ? `سطح S${idx + 1} (نقطه ${v.index + 1})` : `S${idx + 1} (#${v.index + 1})`}
                        {v.isMajor && (
                          <span className="ml-1 text-[8px] px-1 py-0.2 rounded bg-rose-500/20 text-rose-300 font-normal">
                            {isPersian ? "ماژور" : "Major"}
                          </span>
                        )}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 font-mono">
                      <span className="font-bold text-rose-100 text-[11px]">
                        {isRealPrice && v.realPrice != null
                          ? formatRealPrice(v.realPrice, decimals)
                          : v.value.toFixed(2)}
                      </span>
                      <span className="text-[9px] text-rose-400 font-semibold">
                        {v.percentFromCurrent >= 0 ? `+${v.percentFromCurrent.toFixed(1)}%` : `${v.percentFromCurrent.toFixed(1)}%`}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 3. Forward Projections Summary (Bullish / Bearish Targets from Data) */}
            {scenarios && (
              <div className="p-2 rounded-xl border bg-slate-900/60 border-slate-800 flex flex-col gap-1.5 shadow-sm text-xs">
                <div className="flex items-center justify-between font-bold text-slate-200">
                  <div className="flex items-center gap-1">
                    <Target className="w-3.5 h-3.5 text-purple-400" />
                    <span className="text-[11px]">{isPersian ? `تارگت‌های پیش‌بینی (${futureCandlesCount} کندل)` : `Projections`}</span>
                  </div>
                  <span className="text-[9px] font-mono text-purple-300">
                    {isRealPrice && scenarios.range.channelWidthRealAmount != null
                      ? `${formatRealPrice(scenarios.range.channelWidthRealAmount, decimals)}`
                      : `±${scenarios.range.channelWidthPercent.toFixed(1)}%`}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-1.5 text-[10px]">
                  {/* Bullish Target */}
                  <div className="p-1.5 rounded-lg bg-emerald-950/30 border border-emerald-500/20 flex flex-col">
                    <span className="text-[9px] text-emerald-400">{isPersian ? "تارگت صعودی (R1):" : "Target 1:"}</span>
                    <span className="font-mono font-bold text-emerald-200 text-[10px]">
                      {isRealPrice && scenarios.bullish.target1.realPrice != null
                        ? `${formatRealPrice(scenarios.bullish.target1.realPrice, decimals)} (+${scenarios.bullish.target1.percentChange.toFixed(1)}%)`
                        : `+${scenarios.bullish.target1.percentChange.toFixed(1)}%`}
                    </span>
                  </div>

                  {/* Bearish Support */}
                  <div className="p-1.5 rounded-lg bg-rose-950/30 border border-rose-500/20 flex flex-col">
                    <span className="text-[9px] text-rose-400">{isPersian ? "حمایت نزولی (S1):" : "Support 1:"}</span>
                    <span className="font-mono font-bold text-rose-200 text-[10px]">
                      {isRealPrice && scenarios.bearish.support1.realPrice != null
                        ? `${formatRealPrice(scenarios.bearish.support1.realPrice, decimals)} (-${scenarios.bearish.support1.percentChange.toFixed(1)}%)`
                        : `-${scenarios.bearish.support1.percentChange.toFixed(1)}%`}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Fullscreen Visual Modal */}
      {isFullscreenVisual && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-xl flex flex-col p-4 animate-in fade-in duration-200">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-cyan-400" />
              <span className="font-bold text-sm text-slate-100">
                {isPersian ? "نمای تمام‌صفحه خطوط افقی سطوح حمایت و مقاومت روی چارت اصلی" : "Fullscreen Support & Resistance Overlay"}
              </span>
            </div>
            <button
              onClick={() => setIsFullscreenVisual(false)}
              className="px-3 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs cursor-pointer"
            >
              {isPersian ? "بستن" : "Close"}
            </button>
          </div>

          <div className="flex-1 flex items-center justify-center p-4 overflow-hidden">
            <canvas
              ref={fullscreenCanvasRef}
              className="max-w-full max-h-full object-contain rounded-xl shadow-2xl border border-slate-800"
            />
          </div>
        </div>
      )}
    </div>
  );
};
