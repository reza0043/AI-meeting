import React, { useRef, useState, useEffect } from "react";
import { Upload, Crosshair, Check, DollarSign, Sliders, RefreshCw, X } from "lucide-react";
import { extractPatternFromImageData, extractPathFromImageData } from "../engine/imageExtractor";
import {
  PriceScaleCalibration,
  detectPriceScaleFromImage,
  createManualCalibration,
  createEmptyCalibration,
  formatRealPrice,
} from "../engine/priceScaleDetector";
import { LanguageCode, getTranslation } from "../i18n/languages";
import { ThemeId, getTheme } from "../theme/themes";

interface ImageCropperCanvasProps {
  imageSrc: string | null;
  onImageLoaded: (img: HTMLImageElement) => void;
  onPatternExtracted: (pattern: number[], relativeCoords?: { relX: number; relY: number }[]) => void;
  onCropChange?: (crop: CropRect | null) => void;
  onPriceScaleDetected?: (calibration: PriceScaleCalibration | null) => void;
  extractorPointCount?: number;
  triggerExtractPattern?: number;
  triggerPriceScaleModal?: number;
  referencePrice?: number | null;
  onUpdateReferencePrice?: (price: number | null) => void;
  activeLanguage: LanguageCode;
  activeTheme?: ThemeId;
}

export interface CropRect {
  x: number;
  y: number;
  width: number;
  height: number;
}

export const ImageCropperCanvas: React.FC<ImageCropperCanvasProps> = ({
  imageSrc,
  onImageLoaded,
  onPatternExtracted,
  onCropChange,
  onPriceScaleDetected,
  extractorPointCount = 500,
  triggerExtractPattern,
  triggerPriceScaleModal,
  referencePrice,
  onUpdateReferencePrice,
  activeLanguage,
  activeTheme = "cyber-obsidian",
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [imageObj, setImageObj] = useState<HTMLImageElement | null>(null);
  const [crop, setCrop] = useState<CropRect | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number } | null>(null);
  const [extractStatus, setExtractStatus] = useState<string | null>(null);
  const [isDetectingPriceScale, setIsDetectingPriceScale] = useState(false);
  const [calibration, setCalibration] = useState<PriceScaleCalibration | null>(null);
  const [showManualScaleModal, setShowManualScaleModal] = useState(false);
  const [manualMaxPrice, setManualMaxPrice] = useState("");
  const [manualMinPrice, setManualMinPrice] = useState("");

  const [isEditingRefPrice, setIsEditingRefPrice] = useState(false);
  const [refPriceInput, setRefPriceInput] = useState(referencePrice ? String(referencePrice) : "");

  useEffect(() => {
    setRefPriceInput(referencePrice ? String(referencePrice) : "");
  }, [referencePrice]);

  const t = (key: string, fallback?: string) => getTranslation(activeLanguage, key, fallback);
  const theme = getTheme(activeTheme);
  const isPersian = activeLanguage === "fa" || activeLanguage === "ar";

  // Load image when imageSrc changes
  useEffect(() => {
    if (!imageSrc) {
      setImageObj(null);
      setCrop(null);
      setCalibration(null);
      onCropChange?.(null);
      onPriceScaleDetected?.(null);
      return;
    }

    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = async () => {
      setImageObj(img);
      onImageLoaded(img);
      // Auto-set default crop box around the central 70% of the chart
      const initialCrop: CropRect = {
        x: Math.round(img.width * 0.15),
        y: Math.round(img.height * 0.15),
        width: Math.round(img.width * 0.7),
        height: Math.round(img.height * 0.7),
      };
      setCrop(initialCrop);
      onCropChange?.(initialCrop);

      // Perform OCR Price Scale Scan on the uncropped full image
      setIsDetectingPriceScale(true);
      try {
        const detectedScale = await detectPriceScaleFromImage(img);
        setCalibration(detectedScale);
        onPriceScaleDetected?.(detectedScale);
      } catch (e) {
        console.warn("OCR scale check error:", e);
        const empty = createEmptyCalibration(img.height);
        setCalibration(empty);
        onPriceScaleDetected?.(empty);
      } finally {
        setIsDetectingPriceScale(false);
      }

      // Auto-extract initial pattern
      setTimeout(() => performExtraction(img, initialCrop, extractorPointCount), 100);
    };
    img.src = imageSrc;
  }, [imageSrc]);

  // Re-extract immediately whenever extractorPointCount changes
  useEffect(() => {
    if (imageObj && crop && crop.width > 20 && crop.height > 20) {
      performExtraction(imageObj, crop, extractorPointCount);
    }
  }, [extractorPointCount]);

  // Re-extract whenever external trigger is fired (e.g. sidebar button)
  useEffect(() => {
    if (triggerExtractPattern && imageObj && crop && crop.width > 20 && crop.height > 20) {
      performExtraction(imageObj, crop, extractorPointCount);
    }
  }, [triggerExtractPattern]);

  // Open price scale modal whenever external trigger is fired
  useEffect(() => {
    if (triggerPriceScaleModal && imageObj) {
      setShowManualScaleModal(true);
    }
  }, [triggerPriceScaleModal]);

  // Redraw canvas whenever image or crop changes
  useEffect(() => {
    drawCanvas();
  }, [imageObj, crop]);

  const drawCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas || !imageObj) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Set canvas dimensions
    canvas.width = imageObj.width;
    canvas.height = imageObj.height;

    // Draw main image
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(imageObj, 0, 0);

    // If crop box exists, draw semi-transparent overlay + crop borders
    if (crop && crop.width > 0 && crop.height > 0) {
      // Dark overlay outside crop box
      ctx.fillStyle = "rgba(0, 0, 0, 0.55)";
      // Top
      ctx.fillRect(0, 0, canvas.width, crop.y);
      // Bottom
      ctx.fillRect(0, crop.y + crop.height, canvas.width, canvas.height - (crop.y + crop.height));
      // Left
      ctx.fillRect(0, crop.y, crop.x, crop.height);
      // Right
      ctx.fillRect(crop.x + crop.width, crop.y, canvas.width - (crop.x + crop.width), crop.height);

      // Crop border (bright yellow/gold neon)
      ctx.strokeStyle = "#eab308";
      ctx.lineWidth = 2.5;
      ctx.setLineDash([6, 3]);
      ctx.strokeRect(crop.x, crop.y, crop.width, crop.height);

      // Corner handles
      ctx.setLineDash([]);
      ctx.fillStyle = "#facc15";
      const handleSize = 8;
      // Top-left
      ctx.fillRect(crop.x - handleSize / 2, crop.y - handleSize / 2, handleSize, handleSize);
      // Top-right
      ctx.fillRect(crop.x + crop.width - handleSize / 2, crop.y - handleSize / 2, handleSize, handleSize);
      // Bottom-left
      ctx.fillRect(crop.x - handleSize / 2, crop.y + crop.height - handleSize / 2, handleSize, handleSize);
      // Bottom-right
      ctx.fillRect(crop.x + crop.width - handleSize / 2, crop.y + crop.height - handleSize / 2, handleSize, handleSize);

      // Center crosshair
      ctx.strokeStyle = "rgba(250, 204, 21, 0.4)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(crop.x + crop.width / 2, crop.y);
      ctx.lineTo(crop.x + crop.width / 2, crop.y + crop.height);
      ctx.moveTo(crop.x, crop.y + crop.height / 2);
      ctx.lineTo(crop.x + crop.width, crop.y + crop.height / 2);
      ctx.stroke();
    }
  };

  const getCanvasCoords = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY,
    };
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!imageObj) return;
    const { x, y } = getCanvasCoords(e);
    setIsDragging(true);
    setDragStart({ x, y });
    const initialRect = { x, y, width: 0, height: 0 };
    setCrop(initialRect);
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDragging || !dragStart || !imageObj) return;
    const { x, y } = getCanvasCoords(e);

    const x1 = Math.max(0, Math.min(dragStart.x, x));
    const y1 = Math.max(0, Math.min(dragStart.y, y));
    const x2 = Math.min(imageObj.width, Math.max(dragStart.x, x));
    const y2 = Math.min(imageObj.height, Math.max(dragStart.y, y));

    const updatedCrop = {
      x: Math.round(x1),
      y: Math.round(y1),
      width: Math.round(x2 - x1),
      height: Math.round(y2 - y1),
    };
    setCrop(updatedCrop);
  };

  const handleMouseUp = () => {
    if (!isDragging || !crop || !imageObj) return;
    setIsDragging(false);

    if (crop.width > 20 && crop.height > 20) {
      onCropChange?.(crop);
      performExtraction(imageObj, crop);
    }
  };

  const performExtraction = (
    img: HTMLImageElement,
    cropRect: CropRect,
    targetPoints?: number
  ) => {
    try {
      setExtractStatus(t("extractFromCrop", "Extracting DNA Curve..."));

      const resolvedPoints = targetPoints || extractorPointCount || 500;

      // Create offscreen canvas for cropped slice
      const offCanvas = document.createElement("canvas");
      offCanvas.width = cropRect.width;
      offCanvas.height = cropRect.height;
      const offCtx = offCanvas.getContext("2d");
      if (!offCtx) return;

      offCtx.drawImage(
        img,
        cropRect.x,
        cropRect.y,
        cropRect.width,
        cropRect.height,
        0,
        0,
        cropRect.width,
        cropRect.height
      );

      const croppedImgData = offCtx.getImageData(0, 0, cropRect.width, cropRect.height);

      // Extract high-accuracy curve & relative coordinates from cropped image
      const extractedResult = extractPatternFromImageData(croppedImgData, resolvedPoints);

      if (extractedResult && extractedResult.normalizedShape.length > 0) {
        onPatternExtracted(extractedResult.normalizedShape, extractedResult.relativeCoords);
        setExtractStatus(
          activeLanguage === "fa"
            ? `الگوی DNA استخراج شد (${extractedResult.normalizedShape.length} نقطه)`
            : `DNA Pattern Extracted (${extractedResult.normalizedShape.length} Points)`
        );
      } else {
        setExtractStatus(
          activeLanguage === "fa"
            ? "الگوی معتبری در کادر انتخاب شده یافت نشد"
            : "No distinct curve detected in crop selection"
        );
      }
      setTimeout(() => setExtractStatus(null), 3000);
    } catch (err) {
      console.error(err);
      setExtractStatus(t("noDataLoaded", "Extraction Error"));
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (ev) => {
      const result = ev.target?.result as string;
      const img = new Image();
      img.onload = async () => {
        setImageObj(img);
        onImageLoaded(img);
        const initialCrop: CropRect = {
          x: Math.round(img.width * 0.15),
          y: Math.round(img.height * 0.15),
          width: Math.round(img.width * 0.7),
          height: Math.round(img.height * 0.7),
        };
        setCrop(initialCrop);
        onCropChange?.(initialCrop);

        // OCR Price scale scan
        setIsDetectingPriceScale(true);
        try {
          const detectedScale = await detectPriceScaleFromImage(img);
          setCalibration(detectedScale);
          onPriceScaleDetected?.(detectedScale);
        } catch (err) {
          const empty = createEmptyCalibration(img.height);
          setCalibration(empty);
          onPriceScaleDetected?.(empty);
        } finally {
          setIsDetectingPriceScale(false);
        }

        performExtraction(img, initialCrop);
      };
      img.src = result;
    };
    reader.readAsDataURL(file);
  };

  const handleSaveManualScale = () => {
    if (!imageObj) return;
    const maxP = parseFloat(manualMaxPrice);
    const minP = parseFloat(manualMinPrice);
    if (!isNaN(maxP) && !isNaN(minP) && maxP > minP) {
      const manualCalib = createManualCalibration(minP, maxP, imageObj.height);
      setCalibration(manualCalib);
      onPriceScaleDetected?.(manualCalib);
      setShowManualScaleModal(false);
    }
  };

  const handleClearScale = () => {
    if (!imageObj) return;
    const empty = createEmptyCalibration(imageObj.height);
    setCalibration(empty);
    onPriceScaleDetected?.(empty);
    setShowManualScaleModal(false);
  };

  return (
    <div
      id="image-cropper-card"
      className="border rounded-2xl p-3 flex flex-col gap-2.5 shadow-md w-full min-h-[300px] h-[330px] md:h-[360px] overflow-hidden backdrop-blur-xl transition-colors duration-200"
      style={{
        backgroundColor: `${theme.colors.cardBg}f0`,
        borderColor: theme.colors.border,
        color: theme.colors.text,
      }}
    >
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-1.5">
        <div className="flex items-center gap-1.5">
          <Crosshair className="w-4 h-4" style={{ color: theme.colors.primary }} />
          <h2 className="text-xs font-bold" style={{ color: theme.colors.text }}>
            {t("imageWorkspace", "Chart Image & Crop Selection")}
          </h2>
          <span className="px-1.5 py-0.5 rounded bg-cyan-950/60 border border-cyan-800/50 text-[9px] font-mono text-cyan-300 font-bold">
            {extractorPointCount} pts
          </span>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-1.5">
          {/* Reference Price Controller */}
          <div
            className="flex items-center gap-1 px-2 py-0.5 rounded-lg border text-xs shadow-inner backdrop-blur-md"
            style={{
              backgroundColor: `${theme.colors.subpanelBg}ee`,
              borderColor: theme.colors.borderSubtle,
            }}
          >
            <DollarSign className="w-3 h-3 text-emerald-400 shrink-0" />
            <span className="text-[10px] text-slate-400 font-sans">
              {isPersian ? "قیمت مرجع:" : "Ref:"}
            </span>
            {isEditingRefPrice ? (
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  step="any"
                  value={refPriceInput}
                  onChange={(e) => setRefPriceInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      const p = parseFloat(refPriceInput);
                      if (!isNaN(p) && p > 0) {
                        onUpdateReferencePrice?.(p);
                      } else {
                        onUpdateReferencePrice?.(null);
                      }
                      setIsEditingRefPrice(false);
                    } else if (e.key === "Escape") {
                      setIsEditingRefPrice(false);
                    }
                  }}
                  autoFocus
                  placeholder="e.g. 104250"
                  className="w-16 px-1 py-0.2 bg-slate-950 border border-emerald-500/50 rounded font-mono text-[10px] text-emerald-300 focus:outline-none"
                />
                <button
                  onClick={() => {
                    const p = parseFloat(refPriceInput);
                    if (!isNaN(p) && p > 0) {
                      onUpdateReferencePrice?.(p);
                    } else {
                      onUpdateReferencePrice?.(null);
                    }
                    setIsEditingRefPrice(false);
                  }}
                  className="px-1.5 py-0.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-[9px] font-bold cursor-pointer"
                >
                  ✓
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-1">
                <span className="font-mono font-bold text-emerald-400 text-[10px]">
                  {referencePrice != null
                    ? formatRealPrice(referencePrice)
                    : isPersian
                    ? "تعیین نشده"
                    : "Not set"}
                </span>
                <button
                  onClick={() => {
                    setRefPriceInput(referencePrice ? String(referencePrice) : "");
                    setIsEditingRefPrice(true);
                  }}
                  className="text-[9px] text-cyan-400 hover:text-cyan-300 underline cursor-pointer"
                  title={isPersian ? "تنظیم دستی قیمت مرجع برای تمام تحلیل‌ها" : "Set Reference Price"}
                >
                  {isPersian ? "تنظیم" : "Edit"}
                </button>
              </div>
            )}
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleFileInput}
          />
        </div>
      </div>



      {/* Canvas Area */}
      <div
        ref={containerRef}
        className="relative flex-1 border rounded-xl overflow-hidden flex items-center justify-center min-h-0"
        style={{
          backgroundColor: theme.colors.bg,
          borderColor: theme.colors.borderSubtle,
        }}
      >
        {imageObj ? (
          <div className="w-full h-full flex items-center justify-center p-2 overflow-auto">
            <canvas
              ref={canvasRef}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              className="max-w-full max-h-[350px] object-contain rounded-lg shadow-inner cursor-crosshair select-none"
            />
          </div>
        ) : (
          <div
            onClick={() => fileInputRef.current?.click()}
            className="flex flex-col items-center justify-center gap-2 text-center p-4 cursor-pointer transition-colors w-full h-full"
            style={{ color: theme.colors.textMuted }}
          >
            <div
              className="w-11 h-11 rounded-2xl border flex items-center justify-center"
              style={{
                backgroundColor: theme.colors.subpanelBg,
                borderColor: theme.colors.borderSubtle,
              }}
            >
              <Upload className="w-5 h-5" style={{ color: theme.colors.primary }} />
            </div>
            <div>
              <p className="text-xs font-semibold" style={{ color: theme.colors.text }}>
                {t("dropImageHere", "Drop financial chart screenshot here or click to browse")}
              </p>
              <p className="text-[11px] mt-0.5" style={{ color: theme.colors.textMuted }}>
                {t("cropInstruction", "Supports PNG, JPG, WebP — drag to crop the target pattern curve")}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Status bar */}
      {extractStatus && (
        <div
          className="text-xs font-mono px-3 py-1.5 border rounded-lg flex items-center gap-2"
          style={{
            backgroundColor: `${theme.colors.subpanelBg}ee`,
            borderColor: theme.colors.borderSubtle,
            color: theme.colors.primary,
          }}
        >
          <span
            className="w-2 h-2 rounded-full animate-pulse"
            style={{ backgroundColor: theme.colors.primary }}
          />
          <span>{extractStatus}</span>
        </div>
      )}

      {/* Manual Price Scale Modal */}
      {showManualScaleModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div
            className="w-full max-w-sm border rounded-2xl p-4 shadow-2xl flex flex-col gap-3"
            style={{
              backgroundColor: theme.colors.cardBg,
              borderColor: theme.colors.border,
              color: theme.colors.text,
            }}
          >
            <div className="flex items-center justify-between border-b pb-2" style={{ borderColor: theme.colors.borderSubtle }}>
              <div className="flex items-center gap-1.5 font-bold text-xs">
                <DollarSign className="w-4 h-4 text-emerald-400" />
                <span>{isPersian ? "تراز مقیاس قیمت تصویر" : "Chart Image Price Scale"}</span>
              </div>
              <button
                onClick={() => setShowManualScaleModal(false)}
                className="p-1 rounded hover:bg-slate-800 text-slate-400 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-[11px] text-slate-400">
              {isPersian
                ? "اگر اعداد محور قیمت تصویر به صورت خودکار خوانده نشد، می‌توانید بالاترین و پایین‌ترین مبلغ محور عمودی را به صورت دستی وارد کنید تا مبالغ سقف، کف و سناریوها دقیقاً محاسبه و نمایش داده شوند."
                : "If prices on the image axis were not auto-detected, enter the highest and lowest price of the chart screenshot to calculate exact peak/valley currency targets."}
            </p>

            <div className="flex flex-col gap-2 text-xs">
              <label className="flex flex-col gap-1">
                <span className="text-slate-300 font-medium">
                  {isPersian ? "بالاترین قیمت در بالای تصویر (Max Price):" : "Top Price on Screenshot (Max):"}
                </span>
                <input
                  type="number"
                  step="any"
                  value={manualMaxPrice}
                  onChange={(e) => setManualMaxPrice(e.target.value)}
                  placeholder={calibration?.maxScalePrice ? calibration.maxScalePrice.toString() : "e.g. 68500"}
                  className="px-2.5 py-1.5 rounded-lg border bg-slate-900/80 border-slate-700 text-slate-100 font-mono focus:outline-none focus:border-cyan-400"
                />
              </label>

              <label className="flex flex-col gap-1">
                <span className="text-slate-300 font-medium">
                  {isPersian ? "پایین‌ترین قیمت در پایین تصویر (Min Price):" : "Bottom Price on Screenshot (Min):"}
                </span>
                <input
                  type="number"
                  step="any"
                  value={manualMinPrice}
                  onChange={(e) => setManualMinPrice(e.target.value)}
                  placeholder={calibration?.minScalePrice ? calibration.minScalePrice.toString() : "e.g. 62000"}
                  className="px-2.5 py-1.5 rounded-lg border bg-slate-900/80 border-slate-700 text-slate-100 font-mono focus:outline-none focus:border-cyan-400"
                />
              </label>
            </div>

            <div className="flex items-center justify-between gap-2 pt-2 border-t" style={{ borderColor: theme.colors.borderSubtle }}>
              {calibration?.detected && (
                <button
                  onClick={handleClearScale}
                  className="px-3 py-1.5 text-xs rounded-lg border border-rose-500/40 bg-rose-950/20 text-rose-300 cursor-pointer hover:bg-rose-900/30"
                >
                  {isPersian ? "حذف تراز (فقط درصد)" : "Remove Scale"}
                </button>
              )}
              <div className="flex items-center gap-2 ml-auto">
                <button
                  onClick={() => setShowManualScaleModal(false)}
                  className="px-3 py-1.5 text-xs rounded-lg border border-slate-700 bg-slate-800 text-slate-300 cursor-pointer"
                >
                  {isPersian ? "انصراف" : "Cancel"}
                </button>
                <button
                  onClick={handleSaveManualScale}
                  className="px-4 py-1.5 text-xs font-bold rounded-lg border border-emerald-500/50 bg-emerald-600 text-white cursor-pointer hover:bg-emerald-500 shadow-md"
                >
                  {isPersian ? "ثبت تراز" : "Save Scale"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
