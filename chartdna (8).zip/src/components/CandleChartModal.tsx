import React, { useRef, useEffect, useState, useMemo } from "react";
import {
  X,
  Maximize2,
  Minimize2,
  Sliders,
  Sparkles,
  TrendingUp,
  TrendingDown,
  Minus,
  Info,
  Calendar,
  Layers,
  ZoomIn,
  ZoomOut,
  AlertCircle,
  Eye,
  CheckCircle2,
  ArrowUpRight,
  ArrowDownRight,
  Target,
} from "lucide-react";
import { MatchResult, Candle, MarketDataset, SearchConfig, FutureExtremum } from "../engine/types";
import { normalizeShape, resampleSeries } from "../engine/normalizer";
import { LanguageCode, getTranslation } from "../i18n/languages";
import { ThemeId, getTheme } from "../theme/themes";

interface CandleChartModalProps {
  isOpen: boolean;
  onClose: () => void;
  result: MatchResult | null;
  datasets: MarketDataset[];
  config?: SearchConfig;
  referencePattern?: number[] | null;
  referencePrice?: number | null;
  onUpdateReferencePrice?: (price: number | null) => void;
  activeLanguage: LanguageCode;
  activeTheme?: ThemeId;
}

export const CandleChartModal: React.FC<CandleChartModalProps> = ({
  isOpen,
  onClose,
  result,
  datasets,
  config,
  referencePattern,
  referencePrice,
  onUpdateReferencePrice,
  activeLanguage,
  activeTheme = "cyber-obsidian",
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isEditingRefPrice, setIsEditingRefPrice] = useState(false);
  const [refPriceInput, setRefPriceInput] = useState(referencePrice ? String(referencePrice) : "");

  const t = (key: string, fallback?: string) => getTranslation(activeLanguage, key, fallback);
  const theme = getTheme(activeTheme);
  const isPersian = activeLanguage === "fa";

  // Configured default counts from user settings
  const userConfigBefore = config?.beforeCandles ?? config?.patternLength ?? 40;
  const userConfigAfter = config?.futureCandles ?? 40;

  // State
  const [beforeCount, setBeforeCount] = useState(userConfigBefore);
  const [afterCount, setAfterCount] = useState(userConfigAfter);
  const [isFullscreen, setIsFullscreen] = useState(true);
  const [showSettings, setShowSettings] = useState(false);

  // Overlay toggles
  const [showReferenceDNA, setShowReferenceDNA] = useState(true);
  const [showHorizontalLines, setShowHorizontalLines] = useState(true);

  // Sync with user settings whenever result opens or config changes
  useEffect(() => {
    if (isOpen && result) {
      setIsFullscreen(true);
      setBeforeCount(config?.beforeCandles ?? config?.patternLength ?? 40);
      setAfterCount(config?.futureCandles ?? 40);
    }
  }, [isOpen, result, config?.beforeCandles, config?.futureCandles, config?.patternLength]);

  // Colors
  const [bgColor, setBgColor] = useState(theme.colors.bg || "#0b0f17");
  const [gridColor, setGridColor] = useState("rgba(255, 255, 255, 0.07)");
  const [bullColor, setBullColor] = useState("#10b981");
  const [bearColor, setBearColor] = useState("#ef4444");
  const [patternHighlight, setPatternHighlight] = useState("rgba(56, 189, 248, 0.14)");

  // Hover candle state
  const [hoverCandle, setHoverCandle] = useState<{
    candle: Candle;
    index: number;
    x: number;
    y: number;
  } | null>(null);

  // Container dimensions
  const [dimensions, setDimensions] = useState({ width: 800, height: 500 });

  // Format price helper
  const formatPrice = (p?: number | null) => {
    if (p == null || isNaN(p)) return "—";
    if (p >= 1000) return p.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    if (p >= 10) return p.toFixed(3);
    return p.toFixed(5);
  };

  // Trend detection and relevant extrema (Peaks if Bullish, Valleys if Bearish)
  const isBullish = result?.trend === "up";
  const isBearish = result?.trend === "down";

  const relevantExtrema = useMemo<FutureExtremum[]>(() => {
    if (!result) return [];
    if (isBullish) {
      if (result.futurePeaks && result.futurePeaks.length > 0) {
        return result.futurePeaks.slice(0, 4);
      }
      const peaks = result.futureExtrema?.filter((e) => e.type === "peak");
      if (peaks && peaks.length > 0) return peaks.slice(0, 4);
    } else if (isBearish) {
      if (result.futureValleys && result.futureValleys.length > 0) {
        return result.futureValleys.slice(0, 4);
      }
      const valleys = result.futureExtrema?.filter((e) => e.type === "valley");
      if (valleys && valleys.length > 0) return valleys.slice(0, 4);
    }
    return (result.futureExtrema || []).slice(0, 4);
  }, [result, isBullish, isBearish]);

  // Resolve matching dataset
  const dataset = useMemo(() => {
    if (!result) return datasets[0] || null;
    return (
      (result.datasetId && datasets.find((d) => d.id === result.datasetId)) ||
      datasets.find(
        (d) =>
          d.symbol.toUpperCase() === result.symbol.toUpperCase() &&
          d.timeframe.toUpperCase() === result.timeframe.toUpperCase()
      ) ||
      datasets.find((d) => d.name.toLowerCase() === result.fileName.toLowerCase()) ||
      datasets.find((d) => d.symbol.toUpperCase() === result.symbol.toUpperCase()) ||
      null
    );
  }, [result, datasets]);

  // Extract visible candles around match
  const totalCandles = useMemo(() => {
    if (dataset?.candles && dataset.candles.length > 0) {
      return dataset.candles;
    }
    // Fallback: If this is a custom DNA pattern match, synthesize realistic candles
    if (result && result.pattern && result.pattern.length > 0) {
      const fullSeries = [...result.pattern, ...(result.future || [])];
      return fullSeries.map((price, idx) => {
        const spread = Math.max(0.0005 * price, 0.05);
        const open = idx === 0 ? price : fullSeries[idx - 1];
        const close = price;
        const high = Math.max(open, close) + spread * (1 + (idx % 3) * 0.4);
        const low = Math.min(open, close) - spread * (1 + ((idx + 1) % 3) * 0.4);
        return {
          timestamp: `Point #${idx + 1}`,
          open,
          high,
          low,
          close,
          volume: 1000 + Math.abs(Math.sin(idx) * 800),
        };
      });
    }
    return [];
  }, [dataset, result]);

  const startIdx = result ? Math.max(0, result.startIndex - beforeCount) : 0;
  const endIdx = result ? Math.min(totalCandles.length, result.endIndex + afterCount + 1) : 0;
  const visibleCandles = useMemo(() => {
    if (!result || totalCandles.length === 0) return [];
    return totalCandles.slice(startIdx, endIdx);
  }, [totalCandles, startIdx, endIdx, result]);

  const patternLocalStart = result ? Math.max(0, result.startIndex - startIdx) : 0;
  const patternLocalEnd = result ? Math.min(visibleCandles.length - 1, result.endIndex - startIdx) : 0;

  // Track container size with ResizeObserver
  useEffect(() => {
    if (!isOpen) return;
    const container = containerRef.current;
    if (!container) return;

    const updateSize = () => {
      const w = container.clientWidth || 800;
      const h = container.clientHeight || 500;
      if (w > 0 && h > 0) {
        setDimensions({ width: w, height: h });
      }
    };

    updateSize();
    const ro = new ResizeObserver(() => {
      updateSize();
    });
    ro.observe(container);

    return () => ro.disconnect();
  }, [isOpen, isFullscreen, showSettings]);

  // Draw Candlestick Chart with Overlays
  useEffect(() => {
    if (!isOpen || !result) return;
    const canvas = canvasRef.current;
    if (!canvas || visibleCandles.length === 0) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const { width, height } = dimensions;

    canvas.width = width * dpr;
    canvas.height = height * dpr;

    ctx.resetTransform?.();
    ctx.scale(dpr, dpr);

    // 1. Background
    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, width, height);

    // Padding
    const padLeft = 20;
    const padRight = 85;
    const padTop = 45;
    const padBottom = 40;
    const plotWidth = Math.max(10, width - padLeft - padRight);
    const plotHeight = Math.max(10, height - padTop - padBottom);

    // 2. Price Bounds Calculation (including extrema prices)
    let minPrice = Infinity;
    let maxPrice = -Infinity;

    for (const c of visibleCandles) {
      if (c.low < minPrice) minPrice = c.low;
      if (c.high > maxPrice) maxPrice = c.high;
    }

    if (showHorizontalLines && relevantExtrema.length > 0) {
      for (const ext of relevantExtrema) {
        if (ext.historicalPrice < minPrice) minPrice = ext.historicalPrice;
        if (ext.historicalPrice > maxPrice) maxPrice = ext.historicalPrice;
      }
    }

    if (minPrice === maxPrice || !isFinite(minPrice) || !isFinite(maxPrice)) {
      minPrice = 1;
      maxPrice = 2;
    }

    const pricePadding = (maxPrice - minPrice) * 0.12 || 0.01;
    minPrice -= pricePadding;
    maxPrice += pricePadding;
    const totalRange = maxPrice - minPrice || 1;

    const mapY = (price: number) =>
      padTop + plotHeight - ((price - minPrice) / totalRange) * plotHeight;
    const candleWidth = Math.max(3, (plotWidth / visibleCandles.length) * 0.72);
    const mapX = (idx: number) =>
      padLeft + (idx + 0.5) * (plotWidth / visibleCandles.length);

    // 3. Grid Lines & Right Price Axis
    ctx.strokeStyle = gridColor;
    ctx.lineWidth = 1;
    ctx.fillStyle = "#94a3b8";
    ctx.font = "10px monospace";
    ctx.textAlign = "left";

    const priceSteps = 6;
    for (let i = 0; i <= priceSteps; i++) {
      const p = minPrice + (totalRange / priceSteps) * i;
      const y = mapY(p);

      ctx.beginPath();
      ctx.moveTo(padLeft, y);
      ctx.lineTo(width - padRight, y);
      ctx.stroke();

      // Right axis price label
      ctx.fillText(formatPrice(p), width - padRight + 8, y + 3.5);
    }

    // 4. Highlight Pattern Area Span
    if (patternLocalStart >= 0 && patternLocalEnd < visibleCandles.length) {
      const leftX = mapX(patternLocalStart) - candleWidth * 1.2;
      const rightX = mapX(patternLocalEnd) + candleWidth * 1.2;
      const spanWidth = Math.max(10, rightX - leftX);

      // Fill span
      ctx.fillStyle = patternHighlight;
      ctx.fillRect(leftX, padTop, spanWidth, plotHeight);

      // Border outline for pattern span
      ctx.strokeStyle = "rgba(56, 189, 248, 0.4)";
      ctx.lineWidth = 1.5;
      ctx.strokeRect(leftX, padTop, spanWidth, plotHeight);

      // Top label for Pattern Window
      ctx.fillStyle = "#38bdf8";
      ctx.font = "bold 11px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(
        isPersian
          ? `🎯 محدوده الگوی کشف شده (شباهت: ${result.similarity.toFixed(1)}%)`
          : `🎯 Matched Pattern Span (${result.similarity.toFixed(1)}% Match)`,
        leftX + spanWidth / 2,
        padTop - 12
      );
    }

    // 5. Draw Candlesticks (Wicks and Bodies)
    for (let i = 0; i < visibleCandles.length; i++) {
      const c = visibleCandles[i];
      const x = mapX(i);
      const isBull = c.close >= c.open;
      const color = isBull ? bullColor : bearColor;

      const yOpen = mapY(c.open);
      const yClose = mapY(c.close);
      const yHigh = mapY(c.high);
      const yLow = mapY(c.low);

      // High-Low Wick
      ctx.strokeStyle = color;
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(x, yHigh);
      ctx.lineTo(x, yLow);
      ctx.stroke();

      // Body
      const bodyTop = Math.min(yOpen, yClose);
      const bodyHeight = Math.max(1.5, Math.abs(yClose - yOpen));

      ctx.fillStyle = color;
      ctx.fillRect(x - candleWidth / 2, bodyTop, candleWidth, bodyHeight);
    }

    // 6. Draw Extracted Reference Pattern (DNA Curve from uploaded image) Overlay
    if (
      showReferenceDNA &&
      referencePattern &&
      referencePattern.length >= 2 &&
      patternLocalStart < patternLocalEnd
    ) {
      const patternSpanCandles = visibleCandles.slice(patternLocalStart, patternLocalEnd + 1);
      const N = patternSpanCandles.length;

      if (N >= 2) {
        // Resample reference DNA to match the exact candle count of the matched window (1-to-1 horizontal mapping)
        const resampledRef = resampleSeries(referencePattern, N);
        const candleCloses = patternSpanCandles.map((c) => c.close);

        // Optimal Linear Fit (OLS) to map DNA amplitude and level directly into candle price coordinates
        let meanRef = 0;
        let meanCandle = 0;
        for (let i = 0; i < N; i++) {
          meanRef += resampledRef[i];
          meanCandle += candleCloses[i];
        }
        meanRef /= N;
        meanCandle /= N;

        let covXY = 0;
        let varX = 0;
        for (let i = 0; i < N; i++) {
          const dx = resampledRef[i] - meanRef;
          const dy = candleCloses[i] - meanCandle;
          covXY += dx * dy;
          varX += dx * dx;
        }

        const slope = varX > 1e-9 ? covXY / varX : 0;
        const intercept = meanCandle - slope * meanRef;

        let pricePoints: number[];
        if (slope > 0) {
          pricePoints = resampledRef.map((r) => slope * r + intercept);
        } else {
          // Fallback to min-max scaling mapped to candle close span
          const minRef = Math.min(...resampledRef);
          const maxRef = Math.max(...resampledRef);
          const spanRef = maxRef - minRef || 1;

          const minClose = Math.min(...candleCloses);
          const maxClose = Math.max(...candleCloses);
          const spanClose = maxClose - minClose || 1;

          pricePoints = resampledRef.map((r) => {
            const norm01 = (r - minRef) / spanRef;
            return minClose + norm01 * spanClose;
          });
        }

        const leftX = mapX(patternLocalStart);
        const rightX = mapX(patternLocalEnd);

        ctx.save();
        // Glowing Gold/Amber curve representing uploaded reference DNA
        ctx.strokeStyle = "#f59e0b";
        ctx.lineWidth = 2.8;
        ctx.shadowColor = "rgba(245, 158, 11, 0.75)";
        ctx.shadowBlur = 8;

        ctx.beginPath();
        for (let i = 0; i < N; i++) {
          const px = mapX(patternLocalStart + i);
          const py = mapY(pricePoints[i]);

          if (i === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        ctx.stroke();

        // Start & End markers on the reference DNA curve (drawn separately to avoid connecting lines)
        ctx.shadowBlur = 0;
        ctx.fillStyle = "#f59e0b";
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 1.5;

        // Start marker
        const startY = mapY(pricePoints[0]);
        ctx.beginPath();
        ctx.arc(leftX, startY, 4.5, 0, 2 * Math.PI);
        ctx.fill();
        ctx.stroke();

        // End marker
        const endY = mapY(pricePoints[N - 1]);
        ctx.beginPath();
        ctx.arc(rightX, endY, 4.5, 0, 2 * Math.PI);
        ctx.fill();
        ctx.stroke();

        // Label on top of the DNA curve
        ctx.font = "bold 10px sans-serif";
        ctx.fillStyle = "#fbbf24";
        ctx.textAlign = "center";
        ctx.fillText(
          isPersian ? "🧬 روند استخراج شده از عکس (DNA معیار شباهت)" : "🧬 Extracted Reference Pattern (DNA)",
          leftX + (rightX - leftX) / 2,
          padTop + 14
        );

        ctx.restore();
      }
    }

    // 7. Draw Trend-Filtered Extrema Horizontal Price Lines & Badges
    if (showHorizontalLines && relevantExtrema.length > 0) {
      relevantExtrema.forEach((ext, idx) => {
        const isPeak = ext.type === "peak";
        const color = isPeak ? "#10b981" : "#f43f5e";
        const bgBadge = isPeak ? "rgba(6, 78, 59, 0.94)" : "rgba(136, 19, 55, 0.94)";
        const textBorder = isPeak ? "rgba(16, 185, 129, 0.65)" : "rgba(244, 63, 94, 0.65)";

        const y = mapY(ext.historicalPrice);
        const candleTargetIdx = result.endIndex + ext.candleIndex;
        const localIdx = candleTargetIdx - startIdx;
        const candleObj =
          localIdx >= 0 && localIdx < visibleCandles.length ? visibleCandles[localIdx] : null;
        const candX = candleObj
          ? mapX(localIdx)
          : mapX(Math.min(visibleCandles.length - 1, patternLocalEnd + ext.candleIndex));
        const timestampStr = ext.timestamp || candleObj?.timestamp || `+${ext.candleIndex}`;

        // Projected price based on current reference price
        const projPrice =
          referencePrice && referencePrice > 0
            ? referencePrice * (1 + ext.percentChange / 100)
            : null;

        ctx.save();

        // 7a. Dashed Horizontal Price Line across chart
        ctx.strokeStyle = color;
        ctx.lineWidth = 1.6;
        ctx.setLineDash([5, 4]);
        ctx.beginPath();
        ctx.moveTo(padLeft, y);
        ctx.lineTo(width - padRight, y);
        ctx.stroke();

        // 7b. Right-Axis Price Badge
        ctx.setLineDash([]);
        ctx.fillStyle = color;
        const axisBadgeW = 76;
        const axisBadgeH = 16;
        const axisBadgeX = width - padRight + 2;
        const axisBadgeY = y - axisBadgeH / 2;
        ctx.beginPath();
        if (ctx.roundRect) {
          ctx.roundRect(axisBadgeX, axisBadgeY, axisBadgeW, axisBadgeH, 4);
        } else {
          ctx.rect(axisBadgeX, axisBadgeY, axisBadgeW, axisBadgeH);
        }
        ctx.fill();

        ctx.fillStyle = "#ffffff";
        ctx.font = "bold 9.5px monospace";
        ctx.textAlign = "center";
        ctx.fillText(formatPrice(ext.historicalPrice), axisBadgeX + axisBadgeW / 2, y + 3.5);

        // 7c. Peak / Valley Point Marker on Candle Wick/Apex
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.arc(candX, y, 4.5, 0, 2 * Math.PI);
        ctx.fill();
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 1.2;
        ctx.stroke();

        // 7d. Informative Label Badge at horizontal line
        const titleText = isPeak
          ? (isPersian
              ? `▲ سقف ${idx + 1} (+${ext.candleIndex} کندل)`
              : `▲ Peak ${idx + 1} (+${ext.candleIndex} candles)`)
          : (isPersian
              ? `▼ کف ${idx + 1} (+${ext.candleIndex} کندل)`
              : `▼ Valley ${idx + 1} (+${ext.candleIndex} candles)`);

        const dateText = isPersian ? `تاریخ: ${timestampStr}` : `Date: ${timestampStr}`;
        const histText = isPersian
          ? `قیمت در تاریخ: ${formatPrice(ext.historicalPrice)}`
          : `Hist Price: ${formatPrice(ext.historicalPrice)}`;

        const pctSign = ext.percentChange >= 0 ? "+" : "";
        const pctStr = `${pctSign}${ext.percentChange.toFixed(2)}%`;
        const projText =
          projPrice != null
            ? isPersian
              ? `با قیمت کنونی: ${formatPrice(projPrice)} (${pctStr})`
              : `Ref Projected: ${formatPrice(projPrice)} (${pctStr})`
            : isPersian
            ? `تغییر نسبت به پایان الگو: ${pctStr}`
            : `Change: ${pctStr}`;

        ctx.font = "bold 10px sans-serif";
        const m1 = ctx.measureText(titleText).width;
        ctx.font = "9px monospace";
        const m2 = ctx.measureText(dateText).width;
        const m3 = ctx.measureText(histText).width;
        const m4 = ctx.measureText(projText).width;
        const boxW = Math.max(m1, m2, m3, m4) + 20;
        const boxH = 58;

        // Position box horizontally near candX with bounds protection
        let boxX = candX - boxW / 2;
        if (boxX < padLeft + 6) boxX = padLeft + 6;
        if (boxX + boxW > width - padRight - 6) boxX = width - padRight - 6 - boxW;

        // Vertical positioning (above line for peaks, below for valleys, staggered)
        let boxY = isPeak ? y - boxH - 10 : y + 10;
        if (boxY < padTop + 2) boxY = y + 10;
        if (boxY + boxH > height - padBottom - 2) boxY = y - boxH - 10;

        // Box background
        ctx.fillStyle = bgBadge;
        ctx.strokeStyle = textBorder;
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        if (ctx.roundRect) {
          ctx.roundRect(boxX, boxY, boxW, boxH, 6);
        } else {
          ctx.rect(boxX, boxY, boxW, boxH);
        }
        ctx.fill();
        ctx.stroke();

        // Box text rendering
        const alignX = isPersian ? boxX + boxW - 8 : boxX + 8;
        ctx.textAlign = isPersian ? "right" : "left";

        // Line 1: Title
        ctx.fillStyle = isPeak ? "#6ee7b7" : "#fda4af";
        ctx.font = "bold 10px sans-serif";
        ctx.fillText(titleText, alignX, boxY + 13);

        // Line 2: Date
        ctx.fillStyle = "#cbd5e1";
        ctx.font = "9px monospace";
        ctx.fillText(dateText, alignX, boxY + 27);

        // Line 3: Historical price
        ctx.fillStyle = "#f8fafc";
        ctx.font = "bold 9.5px monospace";
        ctx.fillText(histText, alignX, boxY + 41);

        // Line 4: Current reference projected price + pct
        ctx.fillStyle = isPeak ? "#34d399" : "#fb7185";
        ctx.font = "bold 9.5px monospace";
        ctx.fillText(projText, alignX, boxY + 53);

        ctx.restore();
      });
    }

    // 8. Crosshair & Hover Tooltip
    if (hoverCandle) {
      ctx.save();
      ctx.setLineDash([4, 4]);
      ctx.strokeStyle = "rgba(255, 255, 255, 0.35)";
      ctx.lineWidth = 1;

      // Vertical line
      ctx.beginPath();
      ctx.moveTo(hoverCandle.x, padTop);
      ctx.lineTo(hoverCandle.x, height - padBottom);
      ctx.stroke();

      // Horizontal line
      ctx.beginPath();
      ctx.moveTo(padLeft, hoverCandle.y);
      ctx.lineTo(width - padRight, hoverCandle.y);
      ctx.stroke();

      ctx.restore();
    }

    // 9. Time Axis labels at bottom
    ctx.fillStyle = "#64748b";
    ctx.font = "10px monospace";
    ctx.textAlign = "center";

    const labelStep = Math.max(1, Math.floor(visibleCandles.length / 8));
    for (let i = 0; i < visibleCandles.length; i += labelStep) {
      const x = mapX(i);
      const rawTs = visibleCandles[i].timestamp;
      const ts = rawTs.includes(" ") ? rawTs.split(" ")[1] || rawTs : rawTs;
      ctx.fillText(ts, x, height - 12);
    }
  }, [
    isOpen,
    result,
    visibleCandles,
    dimensions,
    bgColor,
    gridColor,
    bullColor,
    bearColor,
    patternHighlight,
    patternLocalStart,
    patternLocalEnd,
    hoverCandle,
    isPersian,
    showReferenceDNA,
    showHorizontalLines,
    referencePattern,
    referencePrice,
    relevantExtrema,
  ]);

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas || visibleCandles.length === 0) return;
    const rect = canvas.getBoundingClientRect();
    const padLeft = 20;
    const padRight = 85;
    const plotWidth = rect.width - padLeft - padRight;

    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    if (mouseX >= padLeft && mouseX <= rect.width - padRight) {
      const idx = Math.floor(((mouseX - padLeft) / plotWidth) * visibleCandles.length);
      if (idx >= 0 && idx < visibleCandles.length) {
        setHoverCandle({
          candle: visibleCandles[idx],
          index: idx,
          x: mouseX,
          y: mouseY,
        });
      }
    } else {
      setHoverCandle(null);
    }
  };

  if (!isOpen || !result) return null;

  return (
    <div
      id="candle-chart-modal"
      className={`fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md ${
        isFullscreen ? "p-0" : "p-2 sm:p-4 md:p-6"
      }`}
    >
      <div
        className={`border flex flex-col shadow-2xl overflow-hidden transition-all duration-200 ${
          isFullscreen ? "w-full h-full rounded-none border-0" : "w-full max-w-7xl h-[94vh] rounded-2xl"
        }`}
        style={{
          backgroundColor: theme.colors.cardBg,
          borderColor: theme.colors.border,
          color: theme.colors.text,
        }}
      >
        {/* Top Header Bar */}
        <div
          className="border-b px-3 sm:px-4 py-2 sm:py-2.5 flex flex-wrap items-center justify-between gap-2.5 shrink-0"
          style={{
            backgroundColor: theme.colors.headerBg,
            borderColor: theme.colors.borderSubtle,
          }}
        >
          <div className="flex items-center gap-2.5">
            <div
              className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl flex items-center justify-center font-bold text-xs shadow-inner shrink-0"
              style={{
                backgroundColor: `${theme.colors.primary}20`,
                color: theme.colors.primary,
              }}
            >
              OHLC
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-xs sm:text-sm font-bold" style={{ color: theme.colors.text }}>
                  {result.symbol} — {result.timeframe}
                </h2>
                <span
                  className="px-2 py-0.5 rounded font-mono text-xs font-bold border"
                  style={{
                    backgroundColor: `${theme.colors.secondary}20`,
                    color: theme.colors.secondary,
                    borderColor: `${theme.colors.secondary}40`,
                  }}
                >
                  {result.similarity.toFixed(2)}% {isPersian ? "شباهت" : "Match"}
                </span>
                <span
                  className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                    isBullish
                      ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                      : isBearish
                      ? "bg-rose-500/20 text-rose-400 border border-rose-500/30"
                      : "bg-slate-800 text-slate-300 border border-slate-700"
                  }`}
                >
                  {isBullish
                    ? isPersian ? "صعودی ▲" : "▲ Bullish"
                    : isBearish
                    ? isPersian ? "نزولی ▼" : "▼ Bearish"
                    : isPersian ? "رنج ▬" : "▬ Range"}
                </span>
              </div>
              <p className="text-[11px] font-mono mt-0.5" style={{ color: theme.colors.textMuted }}>
                {isPersian ? "بازه الگو:" : "Pattern Span:"} {result.startTime} → {result.endTime} ({visibleCandles.length} candles in view)
              </p>
            </div>
          </div>

          {/* Quick Candle OHLC HUD on hover */}
          {hoverCandle ? (
            <div
              className="hidden lg:flex items-center gap-3 px-3 py-1 rounded-xl text-xs font-mono border"
              style={{
                backgroundColor: theme.colors.subpanelBg,
                borderColor: theme.colors.borderSubtle,
              }}
            >
              <span style={{ color: theme.colors.textMuted }}>{hoverCandle.candle.timestamp}</span>
              <span style={{ color: theme.colors.textMuted }}>
                O: <strong style={{ color: theme.colors.text }}>{formatPrice(hoverCandle.candle.open)}</strong>
              </span>
              <span className="text-emerald-400">
                H: <strong className="text-emerald-300">{formatPrice(hoverCandle.candle.high)}</strong>
              </span>
              <span className="text-rose-400">
                L: <strong className="text-rose-300">{formatPrice(hoverCandle.candle.low)}</strong>
              </span>
              <span style={{ color: theme.colors.textMuted }}>
                C:{" "}
                <strong
                  className={
                    hoverCandle.candle.close >= hoverCandle.candle.open
                      ? "text-emerald-400"
                      : "text-rose-400"
                  }
                >
                  {formatPrice(hoverCandle.candle.close)}
                </strong>
              </span>
            </div>
          ) : (
            <div className="hidden xl:flex items-center gap-2 text-xs font-sans" style={{ color: theme.colors.textMuted }}>
              <Info className="w-3.5 h-3.5" />
              <span>
                {isPersian
                  ? "ماوس را روی کندل‌ها حرکت دهید تا اطلاعات قیمتی نمایش داده شود"
                  : "Hover over candles for precise OHLC details"}
              </span>
            </div>
          )}

          {/* Header Controls */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Reference Price Controller */}
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl border bg-slate-900/95 border-emerald-500/30 text-xs shadow-inner shrink-0">
              <span className="text-[11px] text-emerald-300/80 font-sans font-medium">
                {isPersian ? "قیمت کنونی (مرجع):" : "Ref Price:"}
              </span>
              {isEditingRefPrice ? (
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    step="any"
                    value={refPriceInput}
                    onChange={(e) => setRefPriceInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        const p = parseFloat(refPriceInput);
                        if (!isNaN(p) && p > 0) {
                          onUpdateReferencePrice?.(p);
                        } else {
                          onUpdateReferencePrice?.(null);
                        }
                        setIsEditingRefPrice(false);
                      } else if (e.key === "Escape") {
                        setIsEditingRefPrice(false);
                      }
                    }}
                    autoFocus
                    placeholder="e.g. 104250"
                    className="w-24 px-1.5 py-0.5 bg-slate-950 border border-emerald-500/60 rounded font-mono text-[11px] text-emerald-300 focus:outline-none"
                  />
                  <button
                    onClick={() => {
                      const p = parseFloat(refPriceInput);
                      if (!isNaN(p) && p > 0) {
                        onUpdateReferencePrice?.(p);
                      } else {
                        onUpdateReferencePrice?.(null);
                      }
                      setIsEditingRefPrice(false);
                    }}
                    className="px-1.5 py-0.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-bold cursor-pointer"
                  >
                    ✓
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-1.5">
                  <span className="font-mono font-bold text-emerald-400 text-xs">
                    {referencePrice != null && referencePrice > 0
                      ? formatPrice(referencePrice)
                      : isPersian
                      ? "تعیین نشده"
                      : "Not set"}
                  </span>
                  {onUpdateReferencePrice && (
                    <button
                      onClick={() => {
                        setRefPriceInput(referencePrice ? String(referencePrice) : "");
                        setIsEditingRefPrice(true);
                      }}
                      className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 font-medium cursor-pointer transition-colors"
                      title={isPersian ? "تنظیم دستی قیمت مرجع" : "Edit Reference Price"}
                    >
                      {isPersian ? "تنظیم" : "Edit"}
                    </button>
                  )}
                </div>
              )}
            </div>

            <button
              onClick={() => setShowSettings(!showSettings)}
              className="p-2 rounded-xl border transition-colors cursor-pointer"
              style={{
                backgroundColor: showSettings ? theme.colors.primary : theme.colors.subpanelBg,
                borderColor: showSettings ? theme.colors.primary : theme.colors.borderSubtle,
                color: showSettings ? theme.colors.primaryText : theme.colors.text,
              }}
              title={isPersian ? "تنظیمات بازه و لایه‌ها" : "Display settings"}
            >
              <Sliders className="w-4 h-4" />
            </button>

            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-2 rounded-xl border transition-colors cursor-pointer"
              style={{
                backgroundColor: theme.colors.subpanelBg,
                borderColor: theme.colors.borderSubtle,
                color: theme.colors.text,
              }}
              title={isFullscreen ? (isPersian ? "خروج از تمام صفحه" : "Exit Fullscreen") : (isPersian ? "تمام صفحه" : "Fullscreen")}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/40 border border-rose-500/30 text-rose-300 transition-colors cursor-pointer"
              title={isPersian ? "بستن پنجره" : "Close window"}
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Quick Targets Strip under Header (Trend-Filtered: Peaks for Bullish, Valleys for Bearish) */}
        {relevantExtrema.length > 0 && (
          <div
            className="px-4 py-2 border-b flex flex-wrap items-center justify-between gap-3 text-xs"
            style={{
              backgroundColor: isBullish
                ? "rgba(6, 78, 59, 0.25)"
                : isBearish
                ? "rgba(136, 19, 55, 0.25)"
                : `${theme.colors.subpanelBg}ee`,
              borderColor: isBullish
                ? "rgba(16, 185, 129, 0.3)"
                : isBearish
                ? "rgba(244, 63, 94, 0.3)"
                : theme.colors.borderSubtle,
            }}
          >
            <div className="flex items-center gap-2">
              <Target className={`w-4 h-4 ${isBullish ? "text-emerald-400" : isBearish ? "text-rose-400" : "text-cyan-400"}`} />
              <span className="font-bold text-slate-200">
                {isPersian
                  ? isBullish
                    ? "اهداف سقف‌های آینده (روند صعودی):"
                    : isBearish
                    ? "اهداف کف‌های آینده (روند نزولی):"
                    : "سطوح مهم آینده:"
                  : isBullish
                  ? "Bullish Future Peak Targets:"
                  : isBearish
                  ? "Bearish Future Valley Targets:"
                  : "Future Targets:"}
              </span>
              <span className="text-[11px] text-slate-400">
                {isPersian
                  ? "اگر قیمت بر طبق این الگو ادامه دهد در آینده به این سطوح خواهد رسید:"
                  : "Projected price levels if trajectory continues:"}
              </span>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              {relevantExtrema.map((ext, idx) => {
                const isPeak = ext.type === "peak";
                const projPrice =
                  referencePrice && referencePrice > 0
                    ? referencePrice * (1 + ext.percentChange / 100)
                    : null;
                const displayPrice = projPrice ?? ext.historicalPrice;
                const pctSign = ext.percentChange >= 0 ? "+" : "";

                return (
                  <div
                    key={idx}
                    className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border font-mono text-[11px] font-semibold ${
                      isPeak
                        ? "bg-emerald-950/50 text-emerald-200 border-emerald-500/40"
                        : "bg-rose-950/50 text-rose-200 border-rose-500/40"
                    }`}
                    title={`تاریخ: ${ext.timestamp || `+${ext.candleIndex}`} | قیمت تاریخی: ${formatPrice(ext.historicalPrice)}${projPrice ? ` | با نرخ فعلی: ${formatPrice(projPrice)}` : ""}`}
                  >
                    <span>{isPeak ? "▲" : "▼"}</span>
                    <span className="text-[10px] text-slate-400 font-sans">
                      {isPersian ? (isPeak ? `سقف ${idx + 1}` : `کف ${idx + 1}`) : isPeak ? `P${idx + 1}` : `V${idx + 1}`}
                    </span>
                    <strong className="tracking-tight">{formatPrice(displayPrice)}</strong>
                    <span className={`text-[10px] font-bold ${ext.percentChange >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
                      ({pctSign}{ext.percentChange.toFixed(2)}%)
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Main Body */}
        <div className="flex-1 flex flex-col lg:flex-row overflow-hidden relative min-h-0">
          {/* Settings Drawer (Collapsible) */}
          {showSettings && (
            <div
              className="w-full lg:w-80 border-b lg:border-b-0 lg:border-r p-4 flex flex-col gap-4 text-xs overflow-y-auto z-10"
              style={{
                backgroundColor: theme.colors.subpanelBg,
                borderColor: theme.colors.borderSubtle,
              }}
            >
              <h3 className="font-bold text-slate-200 text-sm flex items-center gap-2">
                <Sliders className="w-4 h-4 text-cyan-400" />
                <span>{isPersian ? "تنظیمات نمایش چارت و لایه‌ها" : "Chart Layers & Settings"}</span>
              </h3>

              {/* Layer Toggles */}
              <div className="flex flex-col gap-2 p-2.5 rounded-xl bg-slate-900/60 border border-slate-800">
                <label className="flex items-center justify-between cursor-pointer">
                  <span className="text-slate-300 font-medium flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-400 shadow-[0_0_6px_#f59e0b]" />
                    {isPersian ? "روند DNA عکس آپلود شده" : "Extracted Reference DNA"}
                  </span>
                  <input
                    type="checkbox"
                    checked={showReferenceDNA}
                    onChange={(e) => setShowReferenceDNA(e.target.checked)}
                    className="accent-amber-400 rounded cursor-pointer"
                  />
                </label>

                <label className="flex items-center justify-between cursor-pointer pt-1 border-t border-slate-800">
                  <span className="text-slate-300 font-medium flex items-center gap-1.5">
                    <span className={`w-2.5 h-2.5 rounded-full ${isBullish ? "bg-emerald-400" : "bg-rose-400"}`} />
                    {isPersian ? "خطوط افقی سطوح سقف و کف" : "Horizontal Extrema Lines"}
                  </span>
                  <input
                    type="checkbox"
                    checked={showHorizontalLines}
                    onChange={(e) => setShowHorizontalLines(e.target.checked)}
                    className="accent-cyan-400 rounded cursor-pointer"
                  />
                </label>
              </div>

              {/* Before Count */}
              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="text-slate-300 font-medium">
                    {isPersian ? "کندل‌های قبل از الگو:" : "Candles Before Pattern:"}
                  </label>
                  <span className="text-[10px] text-slate-500 font-mono">
                    ({isPersian ? "تنظیمات:" : "Default:"} {userConfigBefore})
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="range"
                    min="5"
                    max="250"
                    step="5"
                    value={beforeCount}
                    onChange={(e) => setBeforeCount(parseInt(e.target.value))}
                    className="flex-1 accent-cyan-400"
                  />
                  <span className="font-mono text-cyan-300 w-9 text-right font-bold">{beforeCount}</span>
                </div>
              </div>

              {/* After Count */}
              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="text-slate-300 font-medium">
                    {isPersian ? "کندل‌های بعد از الگو (آینده):" : "Candles After Pattern (Future):"}
                  </label>
                  <span className="text-[10px] text-slate-500 font-mono">
                    ({isPersian ? "تنظیمات:" : "Default:"} {userConfigAfter})
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="range"
                    min="5"
                    max="250"
                    step="5"
                    value={afterCount}
                    onChange={(e) => setAfterCount(parseInt(e.target.value))}
                    className="flex-1 accent-emerald-400"
                  />
                  <span className="font-mono text-emerald-300 w-9 text-right font-bold">{afterCount}</span>
                </div>
              </div>

              {/* Quick presets for range */}
              <div className="flex flex-wrap gap-1.5">
                <button
                  onClick={() => {
                    setBeforeCount(userConfigBefore);
                    setAfterCount(userConfigAfter);
                  }}
                  className="px-2.5 py-1 bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/40 text-cyan-300 rounded text-[11px] font-bold"
                >
                  {isPersian ? "↺ تنظیمات کاربر" : "↺ User Config"}
                </button>
                <button
                  onClick={() => {
                    setBeforeCount(30);
                    setAfterCount(30);
                  }}
                  className="px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded text-[11px] text-slate-300"
                >
                  ±30
                </button>
                <button
                  onClick={() => {
                    setBeforeCount(60);
                    setAfterCount(60);
                  }}
                  className="px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded text-[11px] text-slate-300"
                >
                  ±60
                </button>
                <button
                  onClick={() => {
                    setBeforeCount(120);
                    setAfterCount(120);
                  }}
                  className="px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded text-[11px] text-slate-300"
                >
                  ±120
                </button>
              </div>

              {/* Color Customizer */}
              <div className="border-t border-slate-800 pt-3 flex flex-col gap-2.5">
                <h4 className="font-semibold text-slate-300">
                  {isPersian ? "رنگ‌بندی کندل‌ها" : "Candle Colors"}
                </h4>

                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Bullish Candle:</span>
                  <input
                    type="color"
                    value={bullColor}
                    onChange={(e) => setBullColor(e.target.value)}
                    className="w-6 h-6 rounded cursor-pointer bg-transparent border-0"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Bearish Candle:</span>
                  <input
                    type="color"
                    value={bearColor}
                    onChange={(e) => setBearColor(e.target.value)}
                    className="w-6 h-6 rounded cursor-pointer bg-transparent border-0"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Interactive Candlestick Canvas Container */}
          <div
            ref={containerRef}
            className="flex-1 h-full bg-[#0b0f17] relative flex items-center justify-center p-2 min-h-0 w-full overflow-hidden"
          >
            {visibleCandles.length > 0 ? (
              <canvas
                ref={canvasRef}
                onMouseMove={handleCanvasMouseMove}
                onMouseLeave={() => setHoverCandle(null)}
                className="w-full h-full block cursor-crosshair"
              />
            ) : (
              <div className="p-8 text-center flex flex-col items-center gap-3 text-slate-400">
                <AlertCircle className="w-10 h-10 text-amber-400" />
                <h4 className="text-sm font-bold text-slate-200">
                  {isPersian
                    ? "کندل‌های این الگو در دیتابیس فعال بارگذاری نشدند."
                    : "No candle records found for this result."}
                </h4>
                <p className="text-xs text-slate-500 font-mono max-w-md">
                  {isPersian
                    ? `نماد: ${result.symbol} | تایم‌فریم: ${result.timeframe} | فایل: ${result.fileName}`
                    : `Symbol: ${result.symbol} | Timeframe: ${result.timeframe} | File: ${result.fileName}`}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
