import React, { useRef, useEffect, useMemo } from "react";
import { LineChart, Activity, Info, Eye, TrendingUp, TrendingDown, Layers } from "lucide-react";
import { MatchResult, FutureExtremum } from "../engine/types";
import { PatternMatcher } from "../engine/matcher";
import { normalizeShape, resampleSeries } from "../engine/normalizer";
import { LanguageCode, getTranslation } from "../i18n/languages";
import { ThemeId, getTheme } from "../theme/themes";

interface ComparativeChartProps {
  referencePattern: number[] | null;
  selectedMatch: MatchResult | null;
  referencePrice?: number | null;
  extractorPointCount?: number;
  onOpenCandleChart?: (match: MatchResult) => void;
  activeLanguage: LanguageCode;
  activeTheme: ThemeId;
}

export const ComparativeChart: React.FC<ComparativeChartProps> = ({
  referencePattern,
  selectedMatch,
  referencePrice,
  extractorPointCount = 500,
  onOpenCandleChart,
  activeLanguage,
  activeTheme,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const t = (key: string, fallback?: string) => getTranslation(activeLanguage, key, fallback);
  const theme = getTheme(activeTheme);
  const isPersian = activeLanguage === "fa" || activeLanguage === "ar";

  const activeResolutionPoints = useMemo(() => {
    return Math.max(10, extractorPointCount || referencePattern?.length || 500);
  }, [extractorPointCount, referencePattern]);

  const formatPrice = (val: number) => {
    if (val >= 1000) {
      return val.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    } else if (val >= 1) {
      return val.toFixed(4);
    } else {
      return val.toFixed(6);
    }
  };

  // Swings details (Peaks and Valleys)
  const { futurePeaks, futureValleys } = useMemo(() => {
    if (!selectedMatch) return { futurePeaks: [], futureValleys: [] };
    if (
      selectedMatch.futurePeaks &&
      selectedMatch.futurePeaks.length > 0 &&
      selectedMatch.futureValleys &&
      selectedMatch.futureValleys.length > 0
    ) {
      return {
        futurePeaks: selectedMatch.futurePeaks.slice(0, 4),
        futureValleys: selectedMatch.futureValleys.slice(0, 4),
      };
    }
    // Fallback extraction via Zigzag algorithm
    if (selectedMatch.future && selectedMatch.future.length > 0) {
      const base =
        selectedMatch.historicalEndPrice ?? selectedMatch.pattern[selectedMatch.pattern.length - 1] ?? 1;
      const fakeCandles = selectedMatch.future.map((f, idx) => ({
        timestamp: `+${idx + 1}`,
        open: f,
        high: f,
        low: f,
        close: f,
      }));
      const details = PatternMatcher.extractZigzagSwings(fakeCandles, base);
      return {
        futurePeaks: details.futurePeaks.slice(0, 4),
        futureValleys: details.futureValleys.slice(0, 4),
      };
    }
    return { futurePeaks: [], futureValleys: [] };
  }, [selectedMatch]);

  const drawChart = () => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Handle high DPI and container sizing stably
    const dpr = window.devicePixelRatio || 1;
    const width = container.clientWidth || 300;
    const height = container.clientHeight || 220;

    canvas.width = width * dpr;
    canvas.height = height * dpr;

    ctx.resetTransform?.();
    ctx.scale(dpr, dpr);

    // Clear background using theme color
    ctx.fillStyle = theme.colors.bg;
    ctx.fillRect(0, 0, width, height);

    // Padding for axes
    const padLeft = 45;
    const padRight = 35;
    const padTop = 30;
    const padBottom = 25;
    const plotWidth = width - padLeft - padRight;
    const plotHeight = height - padTop - padBottom;

    if (!referencePattern || referencePattern.length === 0) {
      // Empty placeholder state
      ctx.fillStyle = theme.colors.textMuted || "#64748b";
      ctx.font = "13px sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(
        t("noPatternSelected", "No reference pattern extracted or selected yet"),
        width / 2,
        height / 2
      );
      return;
    }

    // Grid lines
    ctx.strokeStyle = theme.isLight ? "rgba(0, 0, 0, 0.06)" : "rgba(255, 255, 255, 0.05)";
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const y = padTop + (plotHeight / 4) * i;
      ctx.beginPath();
      ctx.moveTo(padLeft, y);
      ctx.lineTo(width - padRight, y);
      ctx.stroke();
    }
    for (let i = 0; i <= 6; i++) {
      const x = padLeft + (plotWidth / 6) * i;
      ctx.beginPath();
      ctx.moveTo(x, padTop);
      ctx.lineTo(x, height - padBottom);
      ctx.stroke();
    }

    // Normalize reference dynamically according to extractorPointCount or referencePattern
    const normLen = Math.max(10, extractorPointCount || referencePattern?.length || 500);
    const normRef = normalizeShape(resampleSeries(referencePattern || [], normLen));

    // Determine bounds
    let normMatch: number[] = [];
    let normFuture: number[] = [];

    if (selectedMatch) {
      normMatch = normalizeShape(resampleSeries(selectedMatch.pattern, normLen));

      if (selectedMatch.future && selectedMatch.future.length > 0) {
        const pFirst = selectedMatch.pattern[0];
        const pRange = Math.max(...selectedMatch.pattern) - Math.min(...selectedMatch.pattern) || 1;
        const normRefRange = Math.max(...normMatch) - Math.min(...normMatch) || 1;

        normFuture = selectedMatch.future.map((f) => {
          const delta = (f - pFirst) / pRange;
          return normMatch[0] + delta * normRefRange;
        });
      }
    }

    // Total points along X axis
    const totalXPoints = normLen + (normFuture.length > 0 ? normFuture.length : 0);

    // Coordinate mapping functions
    const mapX = (idx: number) => padLeft + (idx / Math.max(1, totalXPoints - 1)) * plotWidth;

    // Gather all Y values for min/max scaling
    const allY = [...normRef, ...normMatch, ...normFuture];
    const minY = Math.min(...allY, -1.1);
    const maxY = Math.max(...allY, 1.1);
    const ySpan = maxY - minY || 1;

    const mapY = (val: number) => padTop + plotHeight - ((val - minY) / ySpan) * plotHeight;

    // Vertical transition line between pattern and future
    if (normFuture.length > 0) {
      const splitX = mapX(normLen - 1);
      ctx.strokeStyle = theme.colors.textMuted || "rgba(148, 163, 184, 0.4)";
      ctx.lineWidth = 1.5;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(splitX, padTop);
      ctx.lineTo(splitX, height - padBottom);
      ctx.stroke();
      ctx.setLineDash([]);

      // Label on top
      ctx.fillStyle = theme.colors.textMuted || "#94a3b8";
      ctx.font = "10px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(t("matchedInterval", "Pattern End | Future"), splitX, padTop - 8);
    }

    // 1. Draw Reference Pattern (theme DNA line)
    ctx.strokeStyle = theme.colors.dnaLine;
    ctx.lineWidth = 2.8;
    ctx.beginPath();
    for (let i = 0; i < normRef.length; i++) {
      const x = mapX(i);
      const y = mapY(normRef[i]);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // 2. Draw Found Pattern in Market Data (theme matched line)
    if (normMatch.length > 0) {
      ctx.strokeStyle = theme.colors.matchedLine;
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      for (let i = 0; i < normMatch.length; i++) {
        const x = mapX(i);
        const y = mapY(normMatch[i]);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }

    // 3. Draw Future Movement (theme future line with dots)
    if (normFuture.length > 0) {
      ctx.strokeStyle = theme.colors.futureLine;
      ctx.lineWidth = 2.5;
      ctx.setLineDash([3, 3]);
      ctx.beginPath();
      const startX = mapX(normLen - 1);
      const startY = normMatch.length > 0 ? mapY(normMatch[normMatch.length - 1]) : mapY(normRef[normRef.length - 1]);
      ctx.moveTo(startX, startY);

      for (let i = 0; i < normFuture.length; i++) {
        const x = mapX(normLen + i);
        const y = mapY(normFuture[i]);
        ctx.lineTo(x, y);
      }
      ctx.stroke();
      ctx.setLineDash([]);

      // Draw dot markers on future candles
      ctx.fillStyle = theme.colors.futureLine;
      for (let i = 0; i < normFuture.length; i++) {
        const x = mapX(normLen + i);
        const y = mapY(normFuture[i]);
        ctx.beginPath();
        ctx.arc(x, y, 3, 0, 2 * Math.PI);
        ctx.fill();
      }

      // Draw Peak & Valley markers and price labels directly on chart based on trend
      const isBullish = selectedMatch?.trend === "up";
      const isBearish = selectedMatch?.trend === "down";
      const activeExtrema = isBullish
        ? futurePeaks
        : isBearish
        ? futureValleys
        : [...futurePeaks, ...futureValleys];

      activeExtrema.forEach((ext) => {
        const futureIdx = ext.candleIndex - 1;
        if (futureIdx >= 0 && futureIdx < normFuture.length) {
          const px = mapX(normLen + futureIdx);
          const py = mapY(normFuture[futureIdx]);
          const isPeak = ext.type === "peak";

          const displayPrice =
            referencePrice && referencePrice > 0
              ? referencePrice * (1 + ext.percentChange / 100)
              : ext.historicalPrice;

          // Draw icon marker
          ctx.fillStyle = isPeak ? "#10b981" : "#f43f5e";
          ctx.beginPath();
          if (isPeak) {
            ctx.moveTo(px, py - 8);
            ctx.lineTo(px - 5, py);
            ctx.lineTo(px + 5, py);
          } else {
            ctx.moveTo(px, py + 8);
            ctx.lineTo(px - 5, py);
            ctx.lineTo(px + 5, py);
          }
          ctx.closePath();
          ctx.fill();

          // Price label tag
          ctx.font = "bold 9px monospace";
          ctx.textAlign = "center";
          const labelText = formatPrice(displayPrice);
          const tagY = isPeak ? py - 12 : py + 18;

          // Background box for label readability
          const textMetrics = ctx.measureText(labelText);
          ctx.fillStyle = isPeak ? "rgba(6, 78, 59, 0.85)" : "rgba(136, 19, 55, 0.85)";
          ctx.fillRect(px - textMetrics.width / 2 - 3, tagY - 8, textMetrics.width + 6, 11);

          ctx.fillStyle = isPeak ? "#6ee7b7" : "#fda4af";
          ctx.fillText(labelText, px, tagY);
        }
      });
    }

    // Bottom Time Axis labels
    ctx.fillStyle = theme.colors.textMuted || "#64748b";
    ctx.font = "10px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("0", mapX(0), height - 8);
    ctx.fillText(String(Math.floor(normLen / 2)), mapX(Math.floor(normLen / 2)), height - 8);
    ctx.fillText(`${normLen} (${t("pattern", "Pattern")})`, mapX(normLen - 1), height - 8);
    if (normFuture.length > 0) {
      ctx.fillText(`+${normFuture.length} ${t("candlesCount", "candles")}`, mapX(totalXPoints - 1), height - 8);
    }
  };

  useEffect(() => {
    drawChart();

    const container = containerRef.current;
    if (!container) return;

    let resizeObserver: ResizeObserver | null = null;
    if (typeof ResizeObserver !== "undefined") {
      resizeObserver = new ResizeObserver(() => {
        drawChart();
      });
      resizeObserver.observe(container);
    }

    const handleWindowResize = () => drawChart();
    window.addEventListener("resize", handleWindowResize);

    return () => {
      if (resizeObserver && container) {
        resizeObserver.unobserve(container);
      }
      window.removeEventListener("resize", handleWindowResize);
    };
  }, [referencePattern, selectedMatch, referencePrice, extractorPointCount, futurePeaks, futureValleys, activeLanguage, activeTheme]);

  return (
    <div
      id="comparative-chart-card"
      className="border rounded-2xl p-3.5 flex flex-col gap-2.5 shadow-lg w-full min-h-[660px] lg:h-[685px] xl:h-[700px] overflow-hidden backdrop-blur-xl transition-colors duration-200"
      style={{
        backgroundColor: `${theme.colors.cardBg}f0`,
        borderColor: theme.colors.border,
        color: theme.colors.text,
      }}
    >
      {/* Header with Title and Legend */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <LineChart className="w-4 h-4 text-emerald-400" />
          <h2 className="text-sm font-bold text-slate-100" style={{ color: theme.colors.text }}>
            {t("comparativeOverlay", isPersian ? "اطلاعات الگوی کشف شده" : "Discovered Pattern Information")}
          </h2>
          <span className="px-1.5 py-0.5 rounded bg-cyan-950/60 border border-cyan-800/50 text-[10px] font-mono text-cyan-300 font-bold">
            {activeResolutionPoints} pts
          </span>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap items-center gap-3 text-xs">
          {referencePattern && referencePattern.length > 0 && (
            <div className="flex items-center gap-1.5">
              <span
                className="w-3 h-1 rounded-full"
                style={{ backgroundColor: theme.colors.dnaLine }}
              />
              <span className="text-slate-300" style={{ color: theme.colors.textMuted }}>
                {t("referenceDna", "Reference DNA")}
              </span>
            </div>
          )}

          {selectedMatch && (
            <>
              <div className="flex items-center gap-1.5">
                <span
                  className="w-3 h-1 rounded-full"
                  style={{ backgroundColor: theme.colors.matchedLine }}
                />
                <span className="text-slate-300" style={{ color: theme.colors.textMuted }}>
                  {t("matchedHistory", "Matched History")}
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <span
                  className="w-3 h-1 rounded-full"
                  style={{ backgroundColor: theme.colors.futureLine }}
                />
                <span className="text-slate-300" style={{ color: theme.colors.textMuted }}>
                  {t("futureProjection", "Future Projection")} (+{selectedMatch.future.length})
                </span>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Selected Match Info Bar */}
      {selectedMatch && (
        <div
          className="flex flex-wrap items-center justify-between gap-2 px-3 py-1.5 rounded-xl text-xs border backdrop-blur-md"
          style={{
            backgroundColor: `${theme.colors.bg}cc`,
            borderColor: theme.colors.border,
          }}
        >
          <div className="flex items-center gap-2">
            <span className="font-bold text-emerald-400 font-mono">
              #{selectedMatch.rank} • {selectedMatch.similarity.toFixed(2)}%
            </span>
            <span className="text-slate-500">|</span>
            <span className="text-slate-200 font-medium">
              {selectedMatch.symbol} ({selectedMatch.timeframe})
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-3 text-slate-400 text-[11px]">
            <span>
              {t("startDate", "Start:")}{" "}
              <span className="text-slate-200 font-mono">{selectedMatch.startTime}</span>
            </span>
            <span className="text-slate-600">•</span>
            <span>
              {t("endDate", "End:")}{" "}
              <span className="text-slate-200 font-mono">{selectedMatch.endTime}</span>
            </span>
            <span className="text-slate-600">•</span>
            <span
              className={`px-2 py-0.5 rounded-md font-bold text-[10px] ${
                selectedMatch.trend === "up"
                  ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                  : selectedMatch.trend === "down"
                  ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                  : "bg-slate-700/50 text-slate-300 border border-slate-600"
              }`}
            >
              {selectedMatch.trend === "up"
                ? `${t("bullish", "BULLISH")} ▲`
                : selectedMatch.trend === "down"
                ? `${t("bearish", "BEARISH")} ▼`
                : `${t("range", "RANGE")} ▬`}
            </span>
            {onOpenCandleChart && (
              <button
                onClick={() => onOpenCandleChart(selectedMatch)}
                className="flex items-center gap-1 px-2.5 py-1 bg-emerald-600/40 hover:bg-emerald-600 active:bg-emerald-700 text-white rounded-lg font-bold text-[11px] transition-all shadow-sm cursor-pointer ml-1 border border-emerald-400/40 active:scale-[0.98]"
                title={t("interactiveCandlestick", "Open Candlestick Chart")}
              >
                <Eye className="w-3 h-3" />
                <span>{t("viewChart", "View Candles")}</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Trend-Specific Future Extrema Prices Section (Peaks if Bullish, Valleys if Bearish) */}
      {selectedMatch && (
        (() => {
          const isBullish = selectedMatch.trend === "up";
          const isBearish = selectedMatch.trend === "down";
          const showPeaks = (isBullish || selectedMatch.trend === "range") && futurePeaks.length > 0;
          const showValleys = (isBearish || selectedMatch.trend === "range") && futureValleys.length > 0;

          if (!showPeaks && !showValleys) return null;

          const gridColsClass = showPeaks && showValleys ? "grid-cols-1 md:grid-cols-2" : "grid-cols-1";

          return (
            <div className={`grid ${gridColsClass} gap-2 text-xs`}>
              {/* 4 Future Peaks Prices (Shown when Bullish or Range) */}
              {showPeaks && (
                <div
                  className="p-2 rounded-xl border flex flex-col gap-1.5"
                  style={{
                    backgroundColor: "rgba(6, 78, 59, 0.15)",
                    borderColor: "rgba(16, 185, 129, 0.3)",
                  }}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-emerald-300 font-bold text-[11px]">
                      <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                      <span>
                        {isPersian
                          ? isBullish
                            ? "قیمت ۴ سقف مهم آینده (روند صعودی)"
                            : "قیمت ۴ سقف مهم آینده"
                          : "4 Future Peak Prices"}
                      </span>
                    </div>
                    <span className="text-[10px] text-emerald-400/80 font-mono">
                      {referencePrice && referencePrice > 0
                        ? (isPersian ? "بر مبنای مرجع" : "Ref Based")
                        : (isPersian ? "قیمت تاریخی" : "Hist Price")}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                    {futurePeaks.map((peak, pIdx) => {
                      const displayPrice =
                        referencePrice && referencePrice > 0
                          ? referencePrice * (1 + peak.percentChange / 100)
                          : peak.historicalPrice;

                      return (
                        <div
                          key={pIdx}
                          className="flex flex-col px-2 py-1 rounded-lg border font-mono text-[11px] bg-emerald-950/40 border-emerald-500/30"
                          title={`${isPersian ? "سقف" : "Peak"} ${pIdx + 1} (کندل +${peak.candleIndex}) | قیمت تاریخی: ${formatPrice(peak.historicalPrice)}${referencePrice && referencePrice > 0 ? ` | قیمت مرجع: ${formatPrice(displayPrice)}` : ""}`}
                        >
                          <div className="flex items-center justify-between text-[10px] text-emerald-300 font-sans">
                            <span className="font-bold">▲ {isPersian ? `سقف ${pIdx + 1}` : `P${pIdx + 1}`}</span>
                            <span className="text-slate-400 text-[9px]">+{peak.candleIndex}</span>
                          </div>
                          <div className="font-bold text-emerald-200 mt-0.5 tracking-tight">
                            {formatPrice(displayPrice)}
                          </div>
                          {referencePrice && referencePrice > 0 && (
                            <div className="text-[9px] text-slate-400 truncate">
                              {isPersian ? "ت:" : "H:"} {formatPrice(peak.historicalPrice)}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* 4 Future Valleys Prices (Shown when Bearish or Range) */}
              {showValleys && (
                <div
                  className="p-2 rounded-xl border flex flex-col gap-1.5"
                  style={{
                    backgroundColor: "rgba(136, 19, 55, 0.15)",
                    borderColor: "rgba(244, 63, 94, 0.3)",
                  }}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-rose-300 font-bold text-[11px]">
                      <TrendingDown className="w-3.5 h-3.5 text-rose-400" />
                      <span>
                        {isPersian
                          ? isBearish
                            ? "قیمت ۴ کف مهم آینده (روند نزولی)"
                            : "قیمت ۴ کف مهم آینده"
                          : "4 Future Valley Prices"}
                      </span>
                    </div>
                    <span className="text-[10px] text-rose-400/80 font-mono">
                      {referencePrice && referencePrice > 0
                        ? (isPersian ? "بر مبنای مرجع" : "Ref Based")
                        : (isPersian ? "قیمت تاریخی" : "Hist Price")}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                    {futureValleys.map((valley, vIdx) => {
                      const displayPrice =
                        referencePrice && referencePrice > 0
                          ? referencePrice * (1 + valley.percentChange / 100)
                          : valley.historicalPrice;

                      return (
                        <div
                          key={vIdx}
                          className="flex flex-col px-2 py-1 rounded-lg border font-mono text-[11px] bg-rose-950/40 border-rose-500/30"
                          title={`${isPersian ? "کف" : "Valley"} ${vIdx + 1} (کندل +${valley.candleIndex}) | قیمت تاریخی: ${formatPrice(valley.historicalPrice)}${referencePrice && referencePrice > 0 ? ` | قیمت مرجع: ${formatPrice(displayPrice)}` : ""}`}
                        >
                          <div className="flex items-center justify-between text-[10px] text-rose-300 font-sans">
                            <span className="font-bold">▼ {isPersian ? `کف ${vIdx + 1}` : `V${vIdx + 1}`}</span>
                            <span className="text-slate-400 text-[9px]">+{valley.candleIndex}</span>
                          </div>
                          <div className="font-bold text-rose-200 mt-0.5 tracking-tight">
                            {formatPrice(displayPrice)}
                          </div>
                          {referencePrice && referencePrice > 0 && (
                            <div className="text-[9px] text-slate-400 truncate">
                              {isPersian ? "ت:" : "H:"} {formatPrice(valley.historicalPrice)}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          );
        })()
      )}

      {/* Canvas */}
      <div
        ref={containerRef}
        className="flex-1 border rounded-xl overflow-hidden min-h-[220px] relative"
        style={{
          backgroundColor: theme.colors.bg,
          borderColor: theme.colors.border,
        }}
      >
        <canvas ref={canvasRef} className="w-full h-full block" />
      </div>
    </div>
  );
};
