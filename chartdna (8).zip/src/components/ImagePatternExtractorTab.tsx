import React, { useState, useRef, useEffect } from "react";
import {
  Upload,
  Sparkles,
  TrendingUp,
  TrendingDown,
  Minus,
  Save,
  Check,
  Trash2,
  Play,
  Layers,
  Search,
  Tag,
  FileText,
  RotateCcw,
  Sliders,
  Image as ImageIcon,
  CheckCircle2,
  AlertCircle,
  Eye,
  Download,
} from "lucide-react";
import { MyDNAPattern, SearchConfig } from "../engine/types";
import { extractPatternFromImageData, extractPathFromImageData } from "../engine/imageExtractor";
import { normalizeShape, resampleSeries } from "../engine/normalizer";
import { LanguageCode, getTranslation } from "../i18n/languages";
import { ThemeId, getTheme } from "../theme/themes";

interface ImagePatternExtractorTabProps {
  savedPatterns: MyDNAPattern[];
  onSavePattern: (newPattern: MyDNAPattern) => void;
  onDeletePattern: (id: string) => void;
  onApplyAsActiveReference: (patternPoints: number[], name: string) => void;
  onRunSearchWithPattern?: (patternPoints: number[], name: string) => void;
  extractorPointCount?: number;
  activeLanguage: LanguageCode;
  activeTheme?: ThemeId;
}

interface CropRect {
  x: number;
  y: number;
  width: number;
  height: number;
}

const CATEGORIES = [
  "پرایس اکشن (Price Action)",
  "کلاسیک (Classic Patterns)",
  "هارمونیک (Harmonics)",
  "اسمارت مانی (Smart Money / SMC)",
  "شکست و پولبک (Breakout & Pullback)",
  "کندل‌استیک (Candlesticks)",
  "سفارشی شخصی (Custom)",
];

export const ImagePatternExtractorTab: React.FC<ImagePatternExtractorTabProps> = ({
  savedPatterns,
  onSavePattern,
  onDeletePattern,
  onApplyAsActiveReference,
  onRunSearchWithPattern,
  extractorPointCount = 500,
  activeLanguage,
  activeTheme = "cyber-obsidian",
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [imageObj, setImageObj] = useState<HTMLImageElement | null>(null);
  const [crop, setCrop] = useState<CropRect | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number } | null>(null);
  const [pointCount, setPointCount] = useState<number>(extractorPointCount);

  // Synchronize when prop changes
  useEffect(() => {
    if (extractorPointCount) {
      setPointCount(extractorPointCount);
    }
  }, [extractorPointCount]);

  // Extracted Pattern Data
  const [extractedPoints, setExtractedPoints] = useState<number[] | null>(null);
  const [detectedTrend, setDetectedTrend] = useState<"up" | "down" | "range">("up");
  const [trendStats, setTrendStats] = useState<{
    slope: number;
    changePct: number;
    volatility: number;
  } | null>(null);

  // Form Fields
  const [patternName, setPatternName] = useState("");
  const [patternCategory, setPatternCategory] = useState(CATEGORIES[0]);
  const [patternNotes, setPatternNotes] = useState("");
  const [smoothingLevel, setSmoothingLevel] = useState(1); // 0: raw, 1: medium, 2: smooth

  // UI state
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [isSuccessSave, setIsSuccessSave] = useState(false);
  const [activePreviewId, setActivePreviewId] = useState<string | null>(null);
  const [searchLibraryQuery, setSearchLibraryQuery] = useState("");

  const t = (key: string, fallback?: string) => getTranslation(activeLanguage, key, fallback);
  const theme = getTheme(activeTheme);
  const isPersian = activeLanguage === "fa";

  // Handle image load
  useEffect(() => {
    if (!imageSrc) {
      setImageObj(null);
      setCrop(null);
      setExtractedPoints(null);
      return;
    }

    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      setImageObj(img);
      // Default crop: central 80% of width and 75% of height
      const initialCrop: CropRect = {
        x: Math.round(img.width * 0.1),
        y: Math.round(img.height * 0.12),
        width: Math.round(img.width * 0.8),
        height: Math.round(img.height * 0.76),
      };
      setCrop(initialCrop);
      // Auto-extract pattern
      setTimeout(() => performExtraction(img, initialCrop, smoothingLevel), 80);
    };
    img.src = imageSrc;
  }, [imageSrc]);

  // Redraw canvas when crop or image changes
  useEffect(() => {
    drawCanvas();
  }, [imageObj, crop]);

  const drawCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas || !imageObj) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = imageObj.width;
    canvas.height = imageObj.height;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(imageObj, 0, 0);

    if (crop && crop.width > 0 && crop.height > 0) {
      // Dark overlay outside crop box
      ctx.fillStyle = "rgba(0, 0, 0, 0.65)";
      ctx.fillRect(0, 0, canvas.width, crop.y);
      ctx.fillRect(0, crop.y + crop.height, canvas.width, canvas.height - (crop.y + crop.height));
      ctx.fillRect(0, crop.y, crop.x, crop.height);
      ctx.fillRect(crop.x + crop.width, crop.y, canvas.width - (crop.x + crop.width), crop.height);

      // Crop border
      ctx.strokeStyle = "#38bdf8";
      ctx.lineWidth = Math.max(2, Math.round(imageObj.width / 400));
      ctx.setLineDash([6, 4]);
      ctx.strokeRect(crop.x, crop.y, crop.width, crop.height);
      ctx.setLineDash([]);

      // Corner handles
      const handleSize = Math.max(8, Math.round(imageObj.width / 80));
      ctx.fillStyle = "#38bdf8";
      ctx.fillRect(crop.x - handleSize / 2, crop.y - handleSize / 2, handleSize, handleSize);
      ctx.fillRect(crop.x + crop.width - handleSize / 2, crop.y - handleSize / 2, handleSize, handleSize);
      ctx.fillRect(crop.x - handleSize / 2, crop.y + crop.height - handleSize / 2, handleSize, handleSize);
      ctx.fillRect(crop.x + crop.width - handleSize / 2, crop.y + crop.height - handleSize / 2, handleSize, handleSize);
    }
  };

  // Perform curve extraction from image
  const performExtraction = (
    img: HTMLImageElement,
    cropRect: CropRect,
    smoothing: number,
    targetPoints?: number
  ) => {
    if (cropRect.width < 10 || cropRect.height < 10) return;

    const resolvedPointCount = targetPoints || pointCount || extractorPointCount || 500;

    try {
      const offCanvas = document.createElement("canvas");
      offCanvas.width = cropRect.width;
      offCanvas.height = cropRect.height;
      const offCtx = offCanvas.getContext("2d");
      if (!offCtx) return;

      offCtx.drawImage(
        img,
        cropRect.x,
        cropRect.y,
        cropRect.width,
        cropRect.height,
        0,
        0,
        cropRect.width,
        cropRect.height
      );

      const imgData = offCtx.getImageData(0, 0, cropRect.width, cropRect.height);
      const extractedResult = extractPatternFromImageData(imgData, resolvedPointCount);

      if (!extractedResult || extractedResult.normalizedShape.length < 10) {
        setStatusMessage(
          isPersian
            ? "⚠️ تشخیص الگو از کادر با کنتراست پایین مواجه شد. کادر را روی کندل‌ها یا خط روند تنظیم کنید."
            : "⚠️ Low contrast detected. Please adjust crop over the chart trend line."
        );
        return;
      }

      const normalized = extractedResult.normalizedShape;
      setExtractedPoints(normalized);

      // Analyze trend direction and statistics
      const first = normalized[0];
      const last = normalized[normalized.length - 1];
      const middleIdx = Math.floor(normalized.length / 2);
      const middle = normalized[middleIdx];

      const slope = last - first;
      const changePct = ((last - first) / (Math.abs(first) || 1)) * 100;

      // Volatility / variance
      const mean = normalized.reduce((a, b) => a + b, 0) / normalized.length;
      const variance =
        normalized.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / normalized.length;

      let trend: "up" | "down" | "range" = "range";
      if (slope > 0.25) {
        trend = "up";
      } else if (slope < -0.25) {
        trend = "down";
      } else {
        trend = "range";
      }

      setDetectedTrend(trend);
      setTrendStats({
        slope: parseFloat(slope.toFixed(2)),
        changePct: parseFloat(changePct.toFixed(1)),
        volatility: parseFloat(Math.sqrt(variance).toFixed(2)),
      });

      // Suggest intelligent default name if empty
      if (!patternName) {
        const trendLabel = trend === "up" ? "Bullish (صعودی)" : trend === "down" ? "Bearish (نزولی)" : "Range (خنثی)";
        setPatternName(`الگوی ${trendLabel} تصویر ${new Date().toLocaleTimeString("fa-IR")}`);
      }

      setStatusMessage(
        isPersian
          ? `✅ روند نمودار با موفقیت استخراج شد (${trend === "up" ? "روند صعودی" : trend === "down" ? "روند نزولی" : "روند خنثی/رنج"}).`
          : `✅ Chart curve extracted successfully (${trend.toUpperCase()} trend).`
      );
    } catch (err: any) {
      console.error(err);
      setStatusMessage(isPersian ? "خطا در پردازش تصویر چارت" : "Error processing chart image");
    }
  };

  // Mouse interaction for crop box selection
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas || !imageObj) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    const clientX = e.clientX - rect.left;
    const clientY = e.clientY - rect.top;

    const canvasX = Math.round(clientX * scaleX);
    const canvasY = Math.round(clientY * scaleY);

    setIsDragging(true);
    setDragStart({ x: canvasX, y: canvasY });
    setCrop({
      x: canvasX,
      y: canvasY,
      width: 0,
      height: 0,
    });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDragging || !dragStart || !canvasRef.current || !imageObj) return;

    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    const currentX = Math.round((e.clientX - rect.left) * scaleX);
    const currentY = Math.round((e.clientY - rect.top) * scaleY);

    const x = Math.max(0, Math.min(dragStart.x, currentX));
    const y = Math.max(0, Math.min(dragStart.y, currentY));
    const width = Math.min(imageObj.width - x, Math.abs(currentX - dragStart.x));
    const height = Math.min(imageObj.height - y, Math.abs(currentY - dragStart.y));

    setCrop({ x, y, width, height });
  };

  const handleMouseUp = () => {
    if (isDragging && imageObj && crop && crop.width > 20 && crop.height > 20) {
      performExtraction(imageObj, crop, smoothingLevel);
    }
    setIsDragging(false);
    setDragStart(null);
  };

  // File Upload Handlers
  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (ev) => {
      setImageSrc(ev.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Paste image from clipboard
  const handlePaste = (e: React.ClipboardEvent) => {
    const items = e.clipboardData.items;
    for (let i = 0; i < items.length; i++) {
      if (items[i].type.indexOf("image") !== -1) {
        const blob = items[i].getAsFile();
        if (blob) {
          const reader = new FileReader();
          reader.onload = (ev) => {
            setImageSrc(ev.target?.result as string);
          };
          reader.readAsDataURL(blob);
        }
      }
    }
  };

  // Save new custom pattern
  const handleSavePattern = () => {
    if (!extractedPoints || extractedPoints.length < 10) {
      setStatusMessage(
        isPersian
          ? "⚠️ ابتدا باید یک تصویر بارگذاری و الگوی آن استخراج شود."
          : "⚠️ Extract a valid curve first."
      );
      return;
    }

    const name = patternName.trim() || `الگوی سفارشی ${savedPatterns.length + 1}`;
    const newPattern: MyDNAPattern = {
      id: `custom_dna_${Date.now()}`,
      name: name,
      category: patternCategory,
      createdAt: new Date().toISOString().slice(0, 10),
      points: extractedPoints,
      normalizedPoints: extractedPoints,
      notes: patternNotes.trim() || `روند تشخیص‌داده‌شده: ${detectedTrend.toUpperCase()}`,
    };

    onSavePattern(newPattern);
    setIsSuccessSave(true);
    setStatusMessage(
      isPersian
        ? `🎉 الگوی "${name}" با موفقیت ذخیره شد و در موتور جستجوی DNA فعال گردید.`
        : `🎉 Pattern "${name}" saved and added to DNA matching library.`
    );

    setTimeout(() => setIsSuccessSave(false), 3000);
  };

  // SVG sparkline path generator
  const generateSvgPath = (points: number[], width = 240, height = 70) => {
    if (!points || points.length < 2) return "";
    const minVal = Math.min(...points);
    const maxVal = Math.max(...points);
    const span = maxVal - minVal || 1;

    return points
      .map((val, idx) => {
        const x = (idx / (points.length - 1)) * (width - 16) + 8;
        const normY = (val - minVal) / span;
        const y = height - 8 - normY * (height - 16);
        return `${idx === 0 ? "M" : "L"} ${x.toFixed(1)} ${y.toFixed(1)}`;
      })
      .join(" ");
  };

  // Filtered patterns in library
  const filteredLibrary = savedPatterns.filter(
    (p) =>
      p.name.toLowerCase().includes(searchLibraryQuery.toLowerCase()) ||
      (p.category && p.category.toLowerCase().includes(searchLibraryQuery.toLowerCase())) ||
      (p.notes && p.notes.toLowerCase().includes(searchLibraryQuery.toLowerCase()))
  );

  return (
    <div
      className="flex flex-col gap-5 text-slate-200"
      onPaste={handlePaste}
      tabIndex={0}
    >
      {/* Top Banner & Overview */}
      <div className="bg-gradient-to-r from-cyan-950/40 via-slate-900/60 to-purple-950/40 border border-cyan-500/30 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-lg backdrop-blur-md">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300 shrink-0 shadow-inner">
            <Sparkles className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
              <span>{t("imageExtractorTitle", "تشخیص و ثبت الگو از تصویر نمودار")}</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                DNA Vision v2
              </span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              {t(
                "imageExtractorDesc",
                "با آپلود عکس یا اسکرین‌شات چارت، هوش الگوریتمی روند را استخراج کرده و به عنوان الگوی اختصاصی در کتابخانه DNA ذخیره می‌کند تا در تمام جستجوها تطبیق داده شود."
              )}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileInput}
            accept="image/png,image/jpeg,image/jpg,image/webp"
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md transition-all cursor-pointer active:scale-95"
          >
            <Upload className="w-4 h-4" />
            <span>{t("uploadChartImage", "آپلود تصویر چارت")}</span>
          </button>
        </div>
      </div>

      {/* Main Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Column: Image Canvas & Crop Area (7 Cols) */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex flex-col gap-3 shadow-md">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-cyan-400" />
                <h4 className="text-xs font-bold text-white">
                  {t("imageWorkspace", "محیط بصری و کادر استخراج")}
                </h4>
              </div>
              {imageObj && (
                <button
                  onClick={() => {
                    if (imageObj && crop) {
                      performExtraction(imageObj, crop, smoothingLevel);
                    }
                  }}
                  className="flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-semibold bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 rounded-lg transition-all cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>{t("reExtract", "استخراج مجدد")}</span>
                </button>
              )}
            </div>

            {/* Canvas Container or Dropzone */}
            <div
              ref={containerRef}
              className="relative min-h-[260px] max-h-[360px] bg-slate-950 border border-dashed border-slate-800 rounded-xl overflow-hidden flex items-center justify-center"
            >
              {imageSrc ? (
                <canvas
                  ref={canvasRef}
                  onMouseDown={handleMouseDown}
                  onMouseMove={handleMouseMove}
                  onMouseUp={handleMouseUp}
                  className="max-w-full max-h-[350px] object-contain cursor-crosshair select-none"
                />
              ) : (
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="flex flex-col items-center justify-center p-6 text-center gap-3 cursor-pointer hover:bg-slate-900/50 transition-colors w-full h-full"
                >
                  <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center">
                    <Upload className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-slate-200">
                      {t("dropOrPaste", "تصویر چارت را اینجا رها کنید یا کلیک کنید (یا Ctrl+V بزنید)")}
                    </p>
                    <p className="text-[10px] text-slate-500 mt-1">
                      پشتیبانی از فرمت‌های PNG، JPG، WebP، اسکرین‌شات تریدینگ‌ویو و متاتریدر
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Instructions */}
            <div className="flex items-center justify-between text-[11px] text-slate-400 px-1">
              <span>💡 {t("cropHint", "با ماوس روی نمودار بکشید تا کادر زرد/آبی تنظیم و الگو استخراج شود.")}</span>
              {crop && (
                <span className="font-mono text-[10px] text-cyan-400">
                  {crop.width} × {crop.height} px
                </span>
              )}
            </div>

            {/* Configurable Pattern Points / Resolution Slider */}
            <div className="p-3 bg-slate-950/80 border border-slate-800/80 rounded-xl flex flex-col gap-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                  <span>
                    {isPersian
                      ? "تعداد نقاط شباهت و تفکیک الگو:"
                      : "Pattern Points Resolution:"}
                  </span>
                </span>
                <span className="font-mono font-bold text-cyan-300 text-xs px-2 py-0.5 rounded bg-cyan-950/60 border border-cyan-800/50">
                  {pointCount} pts
                </span>
              </div>
              <div className="flex items-center gap-3">
                <input
                  type="range"
                  min="20"
                  max="1000"
                  step="10"
                  value={pointCount}
                  onChange={(e) => {
                    const val = parseInt(e.target.value);
                    setPointCount(val);
                    if (imageObj && crop) {
                      performExtraction(imageObj, crop, smoothingLevel, val);
                    }
                  }}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>
              <div className="flex items-center gap-1.5 flex-wrap pt-0.5">
                {[50, 80, 150, 300, 500, 750, 1000].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => {
                      setPointCount(preset);
                      if (imageObj && crop) {
                        performExtraction(imageObj, crop, smoothingLevel, preset);
                      }
                    }}
                    className={`px-2 py-0.5 text-[10px] font-mono rounded border transition-all cursor-pointer ${
                      pointCount === preset
                        ? "bg-cyan-500 text-slate-950 font-bold border-cyan-300"
                        : "bg-slate-900 text-slate-400 hover:text-slate-200 border-slate-800"
                    }`}
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Extracted Curve Preview & Trend Analytics */}
          {extractedPoints && (
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex flex-col gap-3 shadow-md">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                  <h4 className="text-xs font-bold text-white">
                    {t("extractedDnaCurve", "DNA و روند تشخیص‌داده‌شده")}
                  </h4>
                </div>

                {/* Trend Badge */}
                <div
                  className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border ${
                    detectedTrend === "up"
                      ? "bg-emerald-500/20 border-emerald-500/40 text-emerald-300"
                      : detectedTrend === "down"
                      ? "bg-rose-500/20 border-rose-500/40 text-rose-300"
                      : "bg-amber-500/20 border-amber-500/40 text-amber-300"
                  }`}
                >
                  {detectedTrend === "up" ? (
                    <TrendingUp className="w-3.5 h-3.5" />
                  ) : detectedTrend === "down" ? (
                    <TrendingDown className="w-3.5 h-3.5" />
                  ) : (
                    <Minus className="w-3.5 h-3.5" />
                  )}
                  <span>
                    {detectedTrend === "up"
                      ? "روند صعودی (Bullish)"
                      : detectedTrend === "down"
                      ? "روند نزولی (Bearish)"
                      : "روند خنثی (Range)"}
                  </span>
                </div>
              </div>

              {/* Sparkline Graphic */}
              <div className="h-20 w-full bg-slate-950/90 border border-slate-800/80 rounded-xl p-2 relative flex items-center justify-center overflow-hidden">
                <svg className="w-full h-full overflow-visible">
                  <defs>
                    <linearGradient id="dnaExtractGrad" x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%" stopColor="#06b6d4" />
                      <stop offset="100%" stopColor="#10b981" />
                    </linearGradient>
                  </defs>
                  <path
                    d={generateSvgPath(extractedPoints, 500, 70)}
                    fill="none"
                    stroke="url(#dnaExtractGrad)"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </div>

              {/* Trend Statistics Grid */}
              {trendStats && (
                <div className="grid grid-cols-3 gap-2 text-center text-xs">
                  <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">شیب نمودار (Slope)</span>
                    <span
                      className={`font-mono font-bold ${
                        trendStats.slope > 0
                          ? "text-emerald-400"
                          : trendStats.slope < 0
                          ? "text-rose-400"
                          : "text-amber-400"
                      }`}
                    >
                      {trendStats.slope > 0 ? `+${trendStats.slope}` : trendStats.slope}
                    </span>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">نقاط داده (Resolution)</span>
                    <span className="font-mono font-bold text-cyan-300">
                      {extractedPoints.length} pts
                    </span>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">نوسان‌پذیری (Volatility)</span>
                    <span className="font-mono font-bold text-purple-300">
                      {trendStats.volatility}
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right Column: Pattern Registration Form & Actions (5 Cols) */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col gap-4 shadow-md">
            <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
              <Save className="w-4 h-4 text-cyan-400" />
              <h4 className="text-xs font-bold text-white">
                {t("patternMetadata", "مشخصات و ثبت الگو در کتابخانه")}
              </h4>
            </div>

            {/* Pattern Name Field */}
            <div className="flex flex-col gap-1.5">
              <label className="text-[11px] font-semibold text-slate-300 flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5 text-cyan-400" />
                <span>{t("patternName", "نام الگو:")}</span>
              </label>
              <input
                type="text"
                value={patternName}
                onChange={(e) => setPatternName(e.target.value)}
                placeholder="مثال: دابل باتم طلا، الگوی سر و شانه، پرچم صعودی..."
                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none transition-all"
              />
            </div>

            {/* Category Selector */}
            <div className="flex flex-col gap-1.5">
              <label className="text-[11px] font-semibold text-slate-300 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-purple-400" />
                <span>{t("category", "دسته‌بندی الگو:")}</span>
              </label>
              <select
                value={patternCategory}
                onChange={(e) => setPatternCategory(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none transition-all"
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            {/* Notes / Strategy */}
            <div className="flex flex-col gap-1.5">
              <label className="text-[11px] font-semibold text-slate-300 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-amber-400" />
                <span>{t("strategyNotes", "توضیحات و استراتژی ترید:")}</span>
              </label>
              <textarea
                value={patternNotes}
                onChange={(e) => setPatternNotes(e.target.value)}
                rows={2}
                placeholder="یادداشت در مورد نقطه ورود، تارگت، شرایط تایید یا شکست الگو..."
                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none transition-all resize-none"
              />
            </div>

            {/* Status Alert */}
            {statusMessage && (
              <div
                className={`p-3 rounded-xl text-xs border ${
                  statusMessage.includes("✅") || statusMessage.includes("🎉")
                    ? "bg-emerald-950/40 border-emerald-500/40 text-emerald-300"
                    : statusMessage.includes("⚠️")
                    ? "bg-amber-950/40 border-amber-500/40 text-amber-300"
                    : "bg-rose-950/40 border-rose-500/40 text-rose-300"
                }`}
              >
                {statusMessage}
              </div>
            )}

            {/* Primary Action Buttons */}
            <div className="flex flex-col gap-2 pt-1">
              <button
                onClick={handleSavePattern}
                disabled={!extractedPoints}
                className={`w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-bold shadow-lg transition-all cursor-pointer ${
                  extractedPoints
                    ? "bg-gradient-to-r from-cyan-500 to-emerald-500 hover:from-cyan-400 hover:to-emerald-400 text-slate-950 active:scale-98"
                    : "bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700"
                }`}
              >
                {isSuccessSave ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-slate-950" />
                    <span>{t("savedSuccess", "الگو با موفقیت ثبت شد!")}</span>
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    <span>{t("saveToLibraryBtn", "ثبت در کتابخانه الگوهای من (Save to DNA Library)")}</span>
                  </>
                )}
              </button>

              {extractedPoints && (
                <button
                  onClick={() => {
                    const name = patternName || "الگوی استخراج‌شده از تصویر";
                    onApplyAsActiveReference(extractedPoints, name);
                    if (onRunSearchWithPattern) {
                      onRunSearchWithPattern(extractedPoints, name);
                    }
                  }}
                  className="w-full flex items-center justify-center gap-2 py-2 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 text-xs font-semibold transition-all cursor-pointer active:scale-98"
                >
                  <Search className="w-3.5 h-3.5" />
                  <span>{t("setAsActiveAndSearch", "تعیین به عنوان الگوی فعال و جستجو در نمادها")}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Section: User's Saved DNA Library & Quick Actions */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col gap-4 shadow-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <Layers className="w-4 h-4 text-cyan-400" />
            <div>
              <h4 className="text-xs font-bold text-white flex items-center gap-2">
                <span>{t("savedPatternsHeader", "الگوهای ثبت‌شده در کتابخانه DNA شما")}</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                  {savedPatterns.length} الگو
                </span>
              </h4>
              <p className="text-[11px] text-slate-400 mt-0.5">
                این الگوها در تمامی جستجوها و تطبیق‌های آینده به همراه فایل‌های نمادها مورد بررسی قرار می‌گیرند.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5 pointer-events-none" />
              <input
                type="text"
                value={searchLibraryQuery}
                onChange={(e) => setSearchLibraryQuery(e.target.value)}
                placeholder="فیلتر در الگوهای من..."
                className="bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 w-44 sm:w-56"
              />
            </div>
          </div>
        </div>

        {/* Patterns Cards Grid */}
        {filteredLibrary.length === 0 ? (
          <div className="p-8 text-center text-slate-500 text-xs flex flex-col items-center gap-2">
            <AlertCircle className="w-6 h-6 text-slate-600" />
            <span>الگویی مطابق جستجو یافت نشد.</span>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {filteredLibrary.map((pat) => {
              const isSelected = activePreviewId === pat.id;
              return (
                <div
                  key={pat.id}
                  className={`bg-slate-950 border rounded-xl p-3.5 flex flex-col justify-between gap-3 transition-all duration-200 hover:border-cyan-500/60 ${
                    isSelected ? "border-cyan-500 bg-cyan-950/10 shadow-lg" : "border-slate-800"
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h5 className="text-xs font-bold text-white line-clamp-1">{pat.name}</h5>
                      <span className="text-[10px] text-slate-400 block mt-0.5">
                        {pat.category || "سفارشی"} • {pat.createdAt || "ثبت شده"}
                      </span>
                    </div>

                    <button
                      onClick={() => onDeletePattern(pat.id)}
                      className="p-1 text-slate-500 hover:text-rose-400 hover:bg-rose-950/30 rounded-lg transition-colors cursor-pointer"
                      title="حذف الگو"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Sparkline */}
                  <div className="h-14 w-full bg-slate-900/80 rounded-lg p-1.5 flex items-center justify-center border border-slate-800/60">
                    <svg className="w-full h-full overflow-visible">
                      <path
                        d={generateSvgPath(pat.normalizedPoints || pat.points, 200, 50)}
                        fill="none"
                        stroke="#38bdf8"
                        strokeWidth="2"
                        strokeLinecap="round"
                      />
                    </svg>
                  </div>

                  {pat.notes && (
                    <p className="text-[10px] text-slate-400 line-clamp-1 italic">
                      "{pat.notes}"
                    </p>
                  )}

                  {/* Action Buttons */}
                  <div className="flex items-center gap-2 pt-1 border-t border-slate-800/60">
                    <button
                      onClick={() => onApplyAsActiveReference(pat.normalizedPoints || pat.points, pat.name)}
                      className="flex-1 flex items-center justify-center gap-1.5 py-1.5 bg-cyan-950/60 hover:bg-cyan-900/80 text-cyan-300 border border-cyan-700/50 rounded-lg text-[11px] font-semibold transition-all cursor-pointer"
                    >
                      <Check className="w-3 h-3" />
                      <span>انتخاب به عنوان مرجع</span>
                    </button>

                    {onRunSearchWithPattern && (
                      <button
                        onClick={() => {
                          onApplyAsActiveReference(pat.normalizedPoints || pat.points, pat.name);
                          onRunSearchWithPattern(pat.normalizedPoints || pat.points, pat.name);
                        }}
                        className="flex items-center justify-center p-1.5 bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 rounded-lg transition-all cursor-pointer"
                        title="جستجوی فوری این الگو در تمام نمادها"
                      >
                        <Play className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
