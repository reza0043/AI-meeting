import React from "react";
import {
  Image as ImageIcon,
  Trash2,
  Crop,
  Play,
  Square,
  Sliders,
  TrendingUp,
  TrendingDown,
  Minus,
  Layers,
  Sparkles,
  Database,
} from "lucide-react";
import { TrendBreakdown } from "../engine/types";
import { LanguageCode, getTranslation } from "../i18n/languages";
import { ThemeId, getTheme } from "../theme/themes";

interface SidebarControlsProps {
  cropperSlot?: React.ReactNode;
  onSelectImageClick: () => void;
  onClearAll: () => void;
  onExtractPattern: () => void;
  onOpenPriceScaleModal?: () => void;
  onStartAnalysis: () => void;
  onStopAnalysis: () => void;
  isAnalyzing: boolean;
  progressPercent: number;
  hasImage: boolean;
  hasPattern: boolean;
  hasDatasets: boolean;
  trendBreakdown: TrendBreakdown | null;
  futureCandles?: number;
  // Datasets, Candles, Patterns info
  selectedDatasetsCount: number;
  totalCandlesCount: number;
  customPatternsCount?: number;
  extractorPointCount?: number;
  patternAnalysisSlot?: React.ReactNode;
  // Theme & Language
  activeTheme: ThemeId;
  onOpenSettings?: (tab?: string) => void;
  activeLanguage: LanguageCode;
}

export const SidebarControls: React.FC<SidebarControlsProps> = ({
  cropperSlot,
  onSelectImageClick,
  onClearAll,
  onExtractPattern,
  onOpenPriceScaleModal,
  onStartAnalysis,
  onStopAnalysis,
  isAnalyzing,
  progressPercent,
  hasImage,
  hasPattern,
  hasDatasets,
  trendBreakdown,
  futureCandles = 70,
  selectedDatasetsCount,
  totalCandlesCount,
  customPatternsCount = 0,
  extractorPointCount = 500,
  patternAnalysisSlot,
  activeTheme,
  onOpenSettings,
  activeLanguage,
}) => {
  const t = (key: string, fallback?: string) => getTranslation(activeLanguage, key, fallback);
  const theme = getTheme(activeTheme);
  const isPersian = activeLanguage === "fa" || activeLanguage === "ar";

  return (
    <aside
      id="sidebar-controls"
      className="w-full backdrop-blur-xl border rounded-2xl p-3 flex flex-col gap-2.5 shadow-xl h-full overflow-y-auto transition-colors duration-200"
      style={{
        backgroundColor: `${theme.colors.sidebarBg}f0`,
        borderColor: theme.colors.border,
        color: theme.colors.text,
      }}
    >
      {/* Cropper Slot (Image Workspace) */}
      {cropperSlot && (
        <div className="w-full">
          {cropperSlot}
        </div>
      )}

      {/* 1. Remote Deck Control Bar: Icon-only Single Row (مثل کلید کنترل ضبط و تلویزیون) */}
      <div
        id="remote-control-deck"
        className="w-full border rounded-xl p-1.5 flex items-center justify-between gap-1 shadow-md backdrop-blur-md transition-colors"
        style={{
          backgroundColor: `${theme.colors.subpanelBg}ee`,
          borderColor: theme.colors.borderSubtle,
        }}
      >
        {/* 1. ورود تصویر چارت (Import Image) */}
        <button
          id="btn-import-image"
          onClick={onSelectImageClick}
          className="flex-1 h-9 rounded-lg flex items-center justify-center transition-all duration-150 border cursor-pointer active:scale-95 group relative"
          style={{
            backgroundColor: `${theme.colors.cardBg}bb`,
            borderColor: theme.colors.borderSubtle,
            color: theme.colors.secondary,
          }}
          title={isPersian ? "ورود تصویر چارت" : "Import Chart Image"}
          aria-label={isPersian ? "ورود تصویر چارت" : "Import Chart Image"}
        >
          <ImageIcon className="w-4 h-4 group-hover:scale-110 transition-transform" />
        </button>

        {/* 2. تراز قیمت (Price Scale Calibration) */}
        <button
          id="btn-price-scale"
          onClick={() => onOpenPriceScaleModal?.()}
          disabled={!hasImage}
          className="flex-1 h-9 rounded-lg flex items-center justify-center transition-all duration-150 border active:scale-95 group relative"
          style={{
            backgroundColor: hasImage ? `${theme.colors.secondary}20` : `${theme.colors.cardBg}40`,
            borderColor: hasImage ? `${theme.colors.secondary}50` : theme.colors.borderSubtle,
            color: hasImage ? theme.colors.secondary : theme.colors.textMuted,
            cursor: hasImage ? "pointer" : "not-allowed",
            opacity: hasImage ? 1 : 0.45,
          }}
          title={isPersian ? "تراز مقیاس قیمت" : "Price Scale Calibration"}
          aria-label={isPersian ? "تراز مقیاس قیمت" : "Price Scale Calibration"}
        >
          <Sliders className="w-4 h-4 group-hover:scale-110 transition-transform" />
        </button>

        {/* 3. استخراج مجدد الگو (Re-extract Pattern from Crop) */}
        <button
          id="btn-extract-pattern"
          onClick={onExtractPattern}
          disabled={!hasImage}
          className="flex-1 h-9 rounded-lg flex items-center justify-center transition-all duration-150 border active:scale-95 group relative"
          style={{
            backgroundColor: hasImage ? `${theme.colors.primary}20` : `${theme.colors.cardBg}40`,
            borderColor: hasImage ? `${theme.colors.primary}50` : theme.colors.borderSubtle,
            color: hasImage ? theme.colors.primary : theme.colors.textMuted,
            cursor: hasImage ? "pointer" : "not-allowed",
            opacity: hasImage ? 1 : 0.45,
          }}
          title={isPersian ? `استخراج مجدد الگو از برش (${extractorPointCount} نقطه)` : `Re-extract pattern from crop (${extractorPointCount} pts)`}
          aria-label={isPersian ? "استخراج مجدد الگو" : "Re-extract Pattern"}
        >
          <Crop className="w-4 h-4 group-hover:scale-110 transition-transform" />
        </button>

        {/* 4. شروع تحلیل DNA الگو (Start DNA Analysis) */}
        <button
          id="btn-start-analysis"
          onClick={onStartAnalysis}
          disabled={isAnalyzing || !hasPattern || !hasDatasets}
          className="flex-1 h-9 rounded-lg flex items-center justify-center transition-all duration-150 border active:scale-95 group relative shadow-sm"
          style={{
            backgroundColor: !isAnalyzing && hasPattern && hasDatasets ? theme.colors.primary : `${theme.colors.cardBg}40`,
            color: !isAnalyzing && hasPattern && hasDatasets ? theme.colors.primaryText : theme.colors.textMuted,
            borderColor: !isAnalyzing && hasPattern && hasDatasets ? `${theme.colors.primary}80` : theme.colors.borderSubtle,
            cursor: !isAnalyzing && hasPattern && hasDatasets ? "pointer" : "not-allowed",
            opacity: !isAnalyzing && hasPattern && hasDatasets ? 1 : 0.45,
          }}
          title={isPersian ? "شروع تحلیل DNA الگو" : "Start DNA Search"}
          aria-label={isPersian ? "شروع تحلیل DNA الگو" : "Start DNA Search"}
        >
          <Play className="w-4 h-4 fill-current group-hover:scale-110 transition-transform" />
        </button>

        {/* 5. توقف جستجو (Stop Analysis) */}
        <button
          id="btn-stop-analysis"
          onClick={onStopAnalysis}
          disabled={!isAnalyzing}
          className={`flex-1 h-9 rounded-lg flex items-center justify-center transition-all duration-150 border active:scale-95 group relative ${
            isAnalyzing
              ? "bg-red-600/90 hover:bg-red-500 border-red-400 text-white shadow-md shadow-red-950/50 cursor-pointer animate-pulse"
              : "border-slate-800 text-slate-600 opacity-40 cursor-not-allowed"
          }`}
          style={{
            backgroundColor: isAnalyzing ? undefined : `${theme.colors.cardBg}30`,
            borderColor: isAnalyzing ? undefined : theme.colors.borderSubtle,
          }}
          title={isPersian ? "توقف تحلیل (Stop)" : "Stop DNA Search"}
          aria-label={isPersian ? "توقف تحلیل" : "Stop DNA Search"}
        >
          <Square className="w-3.5 h-3.5 fill-current" />
        </button>

        {/* 6. پاکسازی محیط (Clear All) */}
        <button
          id="btn-clear-all"
          onClick={onClearAll}
          className="flex-1 h-9 rounded-lg flex items-center justify-center bg-rose-950/30 hover:bg-rose-900/50 active:bg-rose-950/70 border border-rose-900/40 hover:border-rose-700 text-rose-300 hover:text-rose-100 transition-all duration-150 cursor-pointer active:scale-95 group relative"
          title={isPersian ? "پاکسازی محیط و داده‌ها" : "Clear All"}
          aria-label={isPersian ? "پاکسازی محیط" : "Clear All"}
        >
          <Trash2 className="w-4 h-4 group-hover:scale-110 transition-transform" />
        </button>
      </div>

      {/* 2. Progress Bar & Percentage */}
      <div
        className="backdrop-blur-md border rounded-xl p-2.5 flex flex-col gap-1.5"
        style={{
          backgroundColor: `${theme.colors.subpanelBg}bb`,
          borderColor: theme.colors.borderSubtle,
        }}
      >
        <div className="flex items-center justify-between text-[11px] font-semibold" style={{ color: theme.colors.text }}>
          <span>{t("scanProgress", "پیشرفت اسکن")}</span>
          <span className="font-mono font-bold" style={{ color: theme.colors.primary }}>{progressPercent}%</span>
        </div>
        <div
          className="w-full h-2 rounded-full overflow-hidden border"
          style={{
            backgroundColor: theme.colors.bg,
            borderColor: theme.colors.borderSubtle,
          }}
        >
          <div
            className="h-full transition-all duration-200 rounded-full"
            style={{
              width: `${progressPercent}%`,
              backgroundColor: theme.colors.primary,
            }}
          />
        </div>
      </div>

      {/* 3 & 4. 2-Column Grid: Trend Summary & Data Inventory Cards */}
      <div className="grid grid-cols-2 gap-2">
        {/* 3. Post-Analysis Trend Summary Box (خلاصه روند نتایج - نصف عرض) */}
        <div
          id="trend-summary-box"
          className="backdrop-blur-md border rounded-xl p-2 flex flex-col justify-between gap-1.5"
          style={{
            backgroundColor: `${theme.colors.subpanelBg}bb`,
            borderColor: theme.colors.borderSubtle,
          }}
        >
          <div className="flex items-center justify-between border-b pb-1" style={{ borderColor: theme.colors.borderSubtle }}>
            <div className="flex items-center gap-1 font-bold text-[10px] sm:text-[11px] truncate" style={{ color: theme.colors.text }}>
              <span className="truncate">{isPersian ? "خلاصه روند" : "Trend Summary"}</span>
            </div>
            {onOpenSettings && (
              <button
                id="btn-manage-trend-search"
                onClick={() => onOpenSettings("algorithm")}
                className="text-[9px] font-semibold hover:underline cursor-pointer shrink-0"
                style={{ color: theme.colors.primary }}
                title={isPersian ? "تنظیم پارامترهای جستجو و افق آینده" : "Configure Search Parameters"}
              >
                {isPersian ? "مدیریت" : "Edit"}
              </button>
            )}
          </div>

          {/* Visual Multi-Color Bar */}
          <div
            className="w-full h-2.5 rounded overflow-hidden flex border shrink-0"
            style={{
              backgroundColor: theme.colors.bg,
              borderColor: theme.colors.borderSubtle,
            }}
          >
            {trendBreakdown && trendBreakdown.total > 0 ? (
              <>
                {trendBreakdown.pctUp > 0 && (
                  <div
                    className="h-full bg-emerald-500 transition-all"
                    style={{ width: `${trendBreakdown.pctUp}%` }}
                    title={`صعودی: ${trendBreakdown.pctUp.toFixed(1)}%`}
                  />
                )}
                {trendBreakdown.pctDown > 0 && (
                  <div
                    className="h-full bg-rose-500 transition-all"
                    style={{ width: `${trendBreakdown.pctDown}%` }}
                    title={`نزولی: ${trendBreakdown.pctDown.toFixed(1)}%`}
                  />
                )}
                {trendBreakdown.pctRange > 0 && (
                  <div
                    className="h-full bg-slate-600 transition-all"
                    style={{ width: `${trendBreakdown.pctRange}%` }}
                    title={`رنج: ${trendBreakdown.pctRange.toFixed(1)}%`}
                  />
                )}
              </>
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <span className="text-[8px]" style={{ color: theme.colors.textMuted }}>
                  —
                </span>
              </div>
            )}
          </div>

          {/* Trend Stats with Icons AND Labels (صعودی، نزولی، رنج) */}
          <div className="flex flex-col gap-1 text-[10px] sm:text-[11px]">
            {/* Bullish */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1 text-emerald-400">
                <TrendingUp className="w-3.5 h-3.5 shrink-0" />
                <span className="text-[10px] font-medium">{t("bullish", "صعودی")}</span>
              </div>
              <span className="font-mono font-bold text-emerald-400 text-[10px]">
                {trendBreakdown ? `${trendBreakdown.pctUp.toFixed(0)}%` : "—"}
              </span>
            </div>

            {/* Bearish */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1 text-rose-400">
                <TrendingDown className="w-3.5 h-3.5 shrink-0" />
                <span className="text-[10px] font-medium">{t("bearish", "نزولی")}</span>
              </div>
              <span className="font-mono font-bold text-rose-400 text-[10px]">
                {trendBreakdown ? `${trendBreakdown.pctDown.toFixed(0)}%` : "—"}
              </span>
            </div>

            {/* Range */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1 text-slate-400">
                <Minus className="w-3.5 h-3.5 shrink-0" />
                <span className="text-[10px] font-medium">{t("range", "رنج")}</span>
              </div>
              <span className="font-mono font-bold text-slate-300 text-[10px]">
                {trendBreakdown ? `${trendBreakdown.pctRange.toFixed(0)}%` : "—"}
              </span>
            </div>
          </div>

          {/* Future Candles Footnote (تعداد کندل پیش رو) */}
          <div
            className="text-[9px] border-t pt-1 flex items-center justify-between font-sans"
            style={{
              borderColor: theme.colors.borderSubtle,
              color: theme.colors.textMuted,
            }}
          >
            <span className="truncate">{isPersian ? "تعداد کندل پیش رو:" : "Future candles:"}</span>
            <span className="font-mono font-bold text-cyan-400">{futureCandles}</span>
          </div>
        </div>

        {/* 4. Data & Patterns Inventory Box (دیتا و الگوها - نصف عرض) */}
        <div
          id="sidebar-dataset-stats-card"
          className="backdrop-blur-md border rounded-xl p-2 flex flex-col justify-between gap-1.5"
          style={{
            backgroundColor: `${theme.colors.subpanelBg}cc`,
            borderColor: theme.colors.borderSubtle,
          }}
        >
          <div className="flex items-center justify-between border-b pb-1" style={{ borderColor: theme.colors.borderSubtle }}>
            <div className="flex items-center gap-1 font-bold text-[10px] sm:text-[11px] truncate" style={{ color: theme.colors.text }}>
              <Database className="w-3 h-3 shrink-0" style={{ color: theme.colors.primary }} />
              <span className="truncate">{isPersian ? "دیتا و الگوها" : "Data & Patterns"}</span>
            </div>
            {onOpenSettings && (
              <button
                onClick={() => onOpenSettings("datasets")}
                className="text-[9px] font-semibold hover:underline cursor-pointer shrink-0"
                style={{ color: theme.colors.primary }}
              >
                {isPersian ? "مدیریت" : "Edit"}
              </button>
            )}
          </div>

          <div className="flex flex-col gap-1.5 text-[10px] sm:text-[11px]">
            {/* Active Datasets Count */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1" style={{ color: theme.colors.textMuted }}>
                <Layers className="w-3 h-3 text-cyan-400 shrink-0" />
                <span className="text-[10px]">{isPersian ? "دیتاست فعال:" : "Datasets:"}</span>
              </div>
              <span className="font-mono font-bold text-[10px]" style={{ color: theme.colors.text }}>
                {selectedDatasetsCount}
              </span>
            </div>

            {/* Total Candles */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1" style={{ color: theme.colors.textMuted }}>
                <TrendingUp className="w-3 h-3 text-emerald-400 shrink-0" />
                <span className="text-[10px]">{isPersian ? "کل کندل‌ها:" : "Candles:"}</span>
              </div>
              <span className="font-mono font-bold text-[10px] text-emerald-300">
                {totalCandlesCount > 0 ? totalCandlesCount.toLocaleString() : "۰"}
              </span>
            </div>

            {/* Library Patterns */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1" style={{ color: theme.colors.textMuted }}>
                <Sparkles className="w-3 h-3 text-purple-400 shrink-0" />
                <span className="text-[10px]">{isPersian ? "الگوها:" : "Patterns:"}</span>
              </div>
              <span className="font-mono font-bold text-[10px] text-purple-300">
                {customPatternsCount}
              </span>
            </div>
          </div>

          {/* Extra spacer / status indicator for symmetry */}
          <div
            className="text-[9px] border-t pt-1 flex items-center justify-between"
            style={{
              borderColor: theme.colors.borderSubtle,
              color: theme.colors.textMuted,
            }}
          >
            <span>{isPersian ? "وضعیت دیتابیس:" : "Database:"}</span>
            <span className="font-bold text-emerald-400 text-[9px]">{isPersian ? "آماده" : "Ready"}</span>
          </div>
        </div>
      </div>

      {/* 5. Pattern Analysis Full Module (Chart Overlay & Extrema/Scenario Stats) */}
      {patternAnalysisSlot && (
        <div className="w-full flex flex-col gap-2.5">
          {patternAnalysisSlot}
        </div>
      )}
    </aside>
  );
};
