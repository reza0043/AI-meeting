import React, { useState } from "react";
import {
  Table,
  TrendingUp,
  TrendingDown,
  Minus,
  Maximize2,
  ExternalLink,
  Search,
  Filter,
  Eye,
  Sparkles,
  Layers,
  Play,
  Check,
} from "lucide-react";
import { MatchResult, CustomPatternMatch } from "../engine/types";
import { LanguageCode, getTranslation } from "../i18n/languages";
import { ThemeId, getTheme } from "../theme/themes";

interface ResultsTableProps {
  results: MatchResult[];
  customMatches?: CustomPatternMatch[];
  selectedIndex: number | null;
  referencePrice?: number | null;
  onUpdateReferencePrice?: (price: number | null) => void;
  futureCandlesCount?: number;
  onSelectResult: (index: number) => void;
  onOpenCandleChart: (result: MatchResult) => void;
  onApplyCustomPattern?: (points: number[], name: string) => void;
  activeLanguage: LanguageCode;
  activeTheme: ThemeId;
}

export const ResultsTable: React.FC<ResultsTableProps> = ({
  results,
  customMatches = [],
  selectedIndex,
  referencePrice,
  onUpdateReferencePrice,
  futureCandlesCount = 20,
  onSelectResult,
  onOpenCandleChart,
  onApplyCustomPattern,
  activeLanguage,
  activeTheme,
}) => {
  const [activeTab, setActiveTab] = useState<"market" | "custom">("market");
  const [searchTerm, setSearchTerm] = useState("");
  const [filterTrend, setFilterTrend] = useState<"all" | "up" | "down" | "range">("all");
  const [expandedRow, setExpandedRow] = useState<number | null>(null);

  const t = (key: string, fallback?: string) => getTranslation(activeLanguage, key, fallback);
  const theme = getTheme(activeTheme);
  const isPersian = activeLanguage === "fa" || activeLanguage === "ar";

  const formatPriceNum = (val?: number | null, decimals = 2) => {
    if (val === undefined || val === null || isNaN(val)) return "—";
    return Number(val).toLocaleString("en-US", {
      minimumFractionDigits: val < 10 ? Math.max(2, decimals) : 2,
      maximumFractionDigits: val < 10 ? 4 : 2,
    });
  };

  const filteredResults = results.filter((r) => {
    const matchesSearch =
      r.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.fileName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.startTime.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTrend = filterTrend === "all" || r.trend === filterTrend;
    return matchesSearch && matchesTrend;
  });

  const filteredCustomMatches = customMatches.filter((c) => {
    const matchesSearch =
      c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (c.category && c.category.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesTrend = filterTrend === "all" || c.trend === filterTrend;
    return matchesSearch && matchesTrend;
  });

  const selectedResult =
    selectedIndex !== null && results[selectedIndex]
      ? results[selectedIndex]
      : results[0] || null;

  // SVG sparkline path generator for custom patterns
  const generateSvgPath = (points: number[], width = 160, height = 36) => {
    if (!points || points.length < 2) return "";
    const minVal = Math.min(...points);
    const maxVal = Math.max(...points);
    const span = maxVal - minVal || 1;

    return points
      .map((val, idx) => {
        const x = (idx / (points.length - 1)) * (width - 10) + 5;
        const normY = (val - minVal) / span;
        const y = height - 5 - normY * (height - 10);
        return `${idx === 0 ? "M" : "L"} ${x.toFixed(1)} ${y.toFixed(1)}`;
      })
      .join(" ");
  };

  return (
    <div
      id="results-table-card"
      className="border rounded-2xl p-4 flex flex-col gap-3 shadow-lg w-full min-h-[380px] backdrop-blur-xl transition-colors duration-200"
      style={{
        backgroundColor: `${theme.colors.cardBg}f0`,
        borderColor: theme.colors.border,
        color: theme.colors.text,
      }}
    >
      {/* Table Header & Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b pb-2.5" style={{ borderColor: theme.colors.borderSubtle }}>
        <div className="flex items-center gap-2">
          {/* Market Matches Tab */}
          <button
            onClick={() => setActiveTab("market")}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === "market"
                ? "bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 shadow-sm"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/40"
            }`}
          >
            <Table className="w-3.5 h-3.5" />
            <span>{t("resultsTitle", "نتایج در نمادها")}</span>
            <span
              className="px-1.5 py-0.2 text-[10px] font-mono rounded-full border"
              style={{
                backgroundColor: theme.colors.subpanelBg,
                borderColor: theme.colors.borderSubtle,
                color: theme.colors.textMuted,
              }}
            >
              {filteredResults.length}
            </span>
          </button>

          {/* Custom Patterns Library Matches Tab */}
          <button
            onClick={() => setActiveTab("custom")}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === "custom"
                ? "bg-purple-500/20 text-purple-300 border border-purple-400/40 shadow-sm"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/40"
            }`}
          >
            <Layers className="w-3.5 h-3.5 text-purple-400" />
            <span>{isPersian ? "الگوهای مشابه در کتابخانه من" : "Matches in My DNA Library"}</span>
            <span
              className="px-1.5 py-0.2 text-[10px] font-mono rounded-full border"
              style={{
                backgroundColor: theme.colors.subpanelBg,
                borderColor: theme.colors.borderSubtle,
                color: customMatches.length > 0 ? theme.colors.primary : theme.colors.textMuted,
              }}
            >
              {customMatches.length}
            </span>
          </button>
        </div>

        {/* Selected Result Quick Action & Filters */}
        <div className="flex flex-wrap items-center gap-2">
          {activeTab === "market" && selectedResult && (
            <button
              onClick={() => onOpenCandleChart(selectedResult)}
              className="flex items-center gap-1.5 px-3 py-1 border text-xs font-semibold rounded-lg shadow-sm backdrop-blur-md transition-all duration-150 cursor-pointer active:scale-[0.98]"
              style={{
                backgroundColor: `${theme.colors.primary}20`,
                borderColor: `${theme.colors.primary}40`,
                color: theme.colors.primary,
              }}
              title={t("interactiveCandlestick", "Open Candlestick Chart Window")}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>
                {t("interactiveCandlestick", "Candles")} (#{selectedResult.rank})
              </span>
            </button>
          )}

          {/* Trend Filter */}
          <select
            value={filterTrend}
            onChange={(e) => setFilterTrend(e.target.value as any)}
            className="border text-xs rounded-lg px-2.5 py-1 focus:outline-none backdrop-blur-md cursor-pointer"
            style={{
              backgroundColor: theme.colors.subpanelBg,
              borderColor: theme.colors.borderSubtle,
              color: theme.colors.text,
            }}
          >
            <option value="all" style={{ backgroundColor: theme.colors.cardBg, color: theme.colors.text }}>{t("allTrends", "All Trends")}</option>
            <option value="up" style={{ backgroundColor: theme.colors.cardBg, color: theme.colors.text }}>{t("bullish", "Bullish Only")}</option>
            <option value="down" style={{ backgroundColor: theme.colors.cardBg, color: theme.colors.text }}>{t("bearish", "Bearish Only")}</option>
            <option value="range" style={{ backgroundColor: theme.colors.cardBg, color: theme.colors.text }}>{t("range", "Range Only")}</option>
          </select>

          {/* Search Box */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2" style={{ color: theme.colors.textMuted }} />
            <input
              type="text"
              placeholder={t("filter", "Filter...")}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="border text-xs rounded-lg pl-8 pr-2.5 py-1 w-32 md:w-36 focus:outline-none backdrop-blur-md"
              style={{
                backgroundColor: theme.colors.subpanelBg,
                borderColor: theme.colors.borderSubtle,
                color: theme.colors.text,
              }}
            />
          </div>
        </div>
      </div>

      {/* Subtitle / Tip */}
      <p className="text-[11px]" style={{ color: theme.colors.textMuted }}>
        {activeTab === "market"
          ? `💡 ${t("resultsSubtitle", "روی ردیف‌ها کلیک کنید تا در چارت بالا مقایسه شوند یا دکمه «مشاهده» را برای پنجره کندلی کامل بزنید.")}`
          : `💡 در این بخش الگوهای ثبت‌شده توسط شما که با الگوی در حال جستجو شباهت دارند نمایش داده می‌شوند.`}
      </p>

      {/* TAB 1: Market Matches Table */}
      {activeTab === "market" && (
        <div
          className="flex-1 overflow-x-auto overflow-y-auto max-h-[440px] border rounded-xl"
          style={{
            backgroundColor: theme.colors.bg,
            borderColor: theme.colors.border,
          }}
        >
          {filteredResults.length > 0 ? (
            <table className="w-full text-left rtl:text-right text-xs border-collapse">
              <thead
                className="uppercase text-[10px] font-semibold sticky top-0 z-10 border-b backdrop-blur-md"
                style={{
                  backgroundColor: `${theme.colors.headerBg}f0`,
                  borderColor: theme.colors.borderSubtle,
                  color: theme.colors.textMuted,
                }}
              >
                <tr>
                  <th className="py-2.5 px-3 text-center w-12">{t("rank", "Rank")}</th>
                  <th className="py-2.5 px-3 text-center">{t("similarity", "Similarity")}</th>
                  <th className="py-2.5 px-3">{t("symbolTf", "Symbol / TF")}</th>
                  <th className="py-2.5 px-3">{isPersian ? "نقطه قیمتی در تاریخ" : "Hist. Price"}</th>
                  {referencePrice != null && referencePrice > 0 && (
                    <th className="py-2.5 px-3 text-center">{isPersian ? "قیمت بر مبنای مرجع" : "Ref Projected"}</th>
                  )}
                  <th className="py-2.5 px-3">{isPersian ? "قیمت‌های آینده (بر اساس روند)" : "Future Targets (by Trend)"}</th>
                  <th className="py-2.5 px-3 text-center">{t("futureTrend", "Future Trend")}</th>
                  <th className="py-2.5 px-3 text-center w-24">{t("viewChart", "Candles")}</th>
                </tr>
              </thead>
              <tbody className="divide-y font-mono" style={{ borderColor: theme.colors.borderSubtle }}>
                {filteredResults.map((result, idx) => {
                  const originalIndex = results.indexOf(result);
                  const isSelected = selectedIndex === originalIndex;
                  const isTop1 = result.rank === 1;

                  return (
                    <tr
                      key={`${result.fileName}_${result.startIndex}_${idx}`}
                      onClick={() => onSelectResult(originalIndex)}
                      onDoubleClick={() => onOpenCandleChart(result)}
                      className="cursor-pointer transition-colors select-none"
                      style={{
                        backgroundColor: isSelected
                          ? `${theme.colors.primary}25`
                          : isTop1
                          ? `${theme.colors.primary}10`
                          : idx % 2 === 0
                          ? `${theme.colors.subpanelBg}40`
                          : "transparent",
                        color: isSelected ? theme.colors.primary : theme.colors.text,
                      }}
                    >
                      {/* Rank */}
                      <td className="py-2.5 px-3 text-center font-bold">
                        {isTop1 ? (
                          <span
                            className="px-1.5 py-0.5 rounded text-[11px]"
                            style={{
                              backgroundColor: `${theme.colors.primary}20`,
                              color: theme.colors.primary,
                            }}
                          >
                            #1 ⭐
                          </span>
                        ) : (
                          `#${result.rank}`
                        )}
                      </td>

                      {/* Similarity */}
                      <td className="py-2.5 px-3 text-center">
                        <span
                          className="font-bold text-[11px] px-2 py-0.5 rounded-md border"
                          style={{
                            backgroundColor: `${theme.colors.primary}15`,
                            borderColor: `${theme.colors.primary}30`,
                            color: theme.colors.primary,
                          }}
                        >
                          {result.similarity.toFixed(2)}%
                        </span>
                      </td>

                      {/* Symbol / File */}
                      <td className="py-2.5 px-3 font-sans font-medium">
                        <div className="flex flex-col gap-0.5">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="font-bold text-xs" style={{ color: theme.colors.text }}>{result.symbol}</span>
                            <span
                              className="text-[10px] px-1.5 py-0.2 border rounded font-mono font-bold"
                              style={{
                                backgroundColor: result.datasetId?.startsWith("custom_dna_") ? "rgba(168, 85, 247, 0.2)" : theme.colors.subpanelBg,
                                borderColor: result.datasetId?.startsWith("custom_dna_") ? "rgba(168, 85, 247, 0.4)" : theme.colors.borderSubtle,
                                color: result.datasetId?.startsWith("custom_dna_") ? "#c084fc" : theme.colors.secondary,
                              }}
                            >
                              {result.datasetId?.startsWith("custom_dna_") ? "DNA" : result.timeframe}
                            </span>
                            {result.datasetId?.startsWith("custom_dna_") && (
                              <span className="text-[9px] px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 border border-purple-400/30 font-sans">
                                {isPersian ? "الگوی کتابخانه من" : "My Pattern"}
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {result.startTime}
                          </span>
                        </div>
                      </td>

                      {/* Historical End Price */}
                      <td className="py-2.5 px-3 font-mono text-xs">
                        <div className="flex flex-col">
                          <span className="font-bold text-slate-200">
                            {formatPriceNum(result.historicalEndPrice ?? result.pattern[result.pattern.length - 1])}
                          </span>
                          <span className="text-[10px] text-slate-500">
                            {isPersian ? "پایان الگو" : "Pattern End"}
                          </span>
                        </div>
                      </td>

                      {/* Ref Projected Price */}
                      {referencePrice != null && referencePrice > 0 && (
                        <td className="py-2.5 px-3 text-center font-mono text-xs">
                          {(() => {
                            const histEndPrice = result.historicalEndPrice ?? result.pattern[result.pattern.length - 1];
                            const futureLastPrice =
                              result.future && result.future.length > 0
                                ? result.future[result.future.length - 1]
                                : histEndPrice;
                            const netReturnPct =
                              histEndPrice > 0 ? ((futureLastPrice - histEndPrice) / histEndPrice) * 100 : 0;
                            const refProj = referencePrice * (1 + netReturnPct / 100);

                            return (
                              <div className="flex flex-col items-center">
                                <span className="font-bold text-emerald-400">
                                  {formatPriceNum(refProj)}
                                </span>
                                <span
                                  className={`text-[10px] font-bold ${
                                    netReturnPct >= 0 ? "text-emerald-400" : "text-rose-400"
                                  }`}
                                >
                                  {netReturnPct >= 0 ? `+${netReturnPct.toFixed(2)}%` : `${netReturnPct.toFixed(2)}%`}
                                </span>
                              </div>
                            );
                          })()}
                        </td>
                      )}

                      {/* Future Trend-Specific Extrema Prices (Peaks if Bullish, Valleys if Bearish) */}
                      <td className="py-2 px-3">
                        <div className="flex items-center gap-1.5 flex-wrap max-w-xs">
                          {(() => {
                            const isBullish = result.trend === "up";
                            const isBearish = result.trend === "down";
                            const relevantExtrema = isBullish
                              ? (result.futurePeaks && result.futurePeaks.length > 0
                                  ? result.futurePeaks
                                  : result.futureExtrema?.filter((e) => e.type === "peak") || []
                                ).slice(0, 4)
                              : isBearish
                              ? (result.futureValleys && result.futureValleys.length > 0
                                  ? result.futureValleys
                                  : result.futureExtrema?.filter((e) => e.type === "valley") || []
                                ).slice(0, 4)
                              : (result.futureExtrema || []).slice(0, 4);

                            if (!relevantExtrema || relevantExtrema.length === 0) {
                              return (
                                <span className="text-[10px] text-slate-500 italic">
                                  {isPersian ? "بدون اکسترمم" : "No extrema"}
                                </span>
                              );
                            }

                            return relevantExtrema.map((ext, eIdx) => {
                              const isPeak = ext.type === "peak";
                              const extProjPrice =
                                referencePrice && referencePrice > 0
                                  ? referencePrice * (1 + ext.percentChange / 100)
                                  : null;
                              const displayPrice = extProjPrice ?? ext.historicalPrice;

                              return (
                                <span
                                  key={eIdx}
                                  className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-mono border font-semibold ${
                                    isPeak
                                      ? "bg-emerald-950/40 text-emerald-300 border-emerald-500/30"
                                      : "bg-rose-950/40 text-rose-300 border-rose-500/30"
                                  }`}
                                  title={`${isPeak ? (isPersian ? "سقف" : "Peak") : (isPersian ? "کف" : "Valley")} ${eIdx + 1} (کندل +${ext.candleIndex}) | قیمت: ${formatPriceNum(displayPrice)}${extProjPrice ? ` (قیمت تاریخی: ${formatPriceNum(ext.historicalPrice)})` : ""}`}
                                >
                                  <span className="font-bold">{isPeak ? "▲" : "▼"}</span>
                                  <span className="text-[9px] text-slate-400 font-normal">+{ext.candleIndex}:</span>
                                  <span className="font-bold tracking-tight">{formatPriceNum(displayPrice)}</span>
                                </span>
                              );
                            });
                          })()}
                        </div>
                      </td>

                      {/* Trend */}
                      <td className="py-2.5 px-3 text-center">
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold ${
                            result.trend === "up"
                              ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                              : result.trend === "down"
                              ? "bg-rose-500/20 text-rose-400 border border-rose-500/30"
                              : "bg-slate-800 text-slate-400 border border-slate-700"
                          }`}
                        >
                          {result.trend === "up" && <TrendingUp className="w-3 h-3" />}
                          {result.trend === "down" && <TrendingDown className="w-3 h-3" />}
                          {result.trend === "range" && <Minus className="w-3 h-3" />}
                          <span>
                            {result.trend === "up"
                              ? t("bullish", "Bullish")
                              : result.trend === "down"
                              ? t("bearish", "Bearish")
                              : t("range", "Range")}
                          </span>
                        </span>
                      </td>

                      {/* Open Candles button */}
                      <td className="py-2 px-3 text-center">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onOpenCandleChart(result);
                          }}
                          className="flex items-center justify-center gap-1.5 px-2.5 py-1 rounded-lg border transition-all font-sans text-xs font-semibold cursor-pointer shadow-sm w-full active:scale-[0.98]"
                          style={{
                            backgroundColor: `${theme.colors.primary}20`,
                            borderColor: `${theme.colors.primary}40`,
                            color: theme.colors.primary,
                          }}
                          title={t("interactiveCandlestick", "View Candlestick & Future Chart")}
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>{t("viewChart", "View")}</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          ) : (
            <div className="flex flex-col items-center justify-center p-8 text-center gap-2" style={{ color: theme.colors.textMuted }}>
              <p className="text-xs">
                {results.length === 0
                  ? t("noResultsYet", "موردی یافت نشد یا هنوز تحلیلی اجرا نشده است. لطفاً یک تصویر وارد کرده و دکمه جستجو را بزنید.")
                  : t("noMatchesFilter", "موردی مطابق با فیلتر فعلی یافت نشد.")}
              </p>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: Custom DNA Library Matches */}
      {activeTab === "custom" && (
        <div
          className="flex-1 overflow-x-auto overflow-y-auto max-h-[440px] border rounded-xl p-3 flex flex-col gap-2.5"
          style={{
            backgroundColor: theme.colors.bg,
            borderColor: theme.colors.border,
          }}
        >
          {filteredCustomMatches.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {filteredCustomMatches.map((custom) => (
                <div
                  key={custom.patternId}
                  className="p-3 rounded-xl border flex flex-col justify-between gap-2.5 transition-all hover:border-cyan-500/60"
                  style={{
                    backgroundColor: `${theme.colors.cardBg}f0`,
                    borderColor: theme.colors.borderSubtle,
                  }}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                        <span>{custom.name}</span>
                        <span
                          className={`text-[9px] px-1.5 py-0.2 rounded-full font-bold border ${
                            custom.trend === "up"
                              ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
                              : custom.trend === "down"
                              ? "bg-rose-500/20 text-rose-300 border-rose-500/40"
                              : "bg-amber-500/20 text-amber-300 border-amber-500/40"
                          }`}
                        >
                          {custom.trend.toUpperCase()}
                        </span>
                      </h4>
                      <span className="text-[10px] text-slate-400 block mt-0.5">
                        {custom.category || "سفارشی"} • {custom.createdAt || "کتابخانه DNA"}
                      </span>
                    </div>

                    <div className="text-right shrink-0">
                      <span className="text-xs font-bold font-mono px-2 py-0.5 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-400/30 block">
                        {custom.similarity.toFixed(1)}% تطابق
                      </span>
                    </div>
                  </div>

                  {/* Sparkline */}
                  <div className="h-10 w-full bg-slate-950/80 rounded-lg p-1 flex items-center justify-center border border-slate-800">
                    <svg className="w-full h-full overflow-visible">
                      <path
                        d={generateSvgPath(custom.points, 220, 36)}
                        fill="none"
                        stroke="#06b6d4"
                        strokeWidth="2"
                        strokeLinecap="round"
                      />
                    </svg>
                  </div>

                  {custom.notes && (
                    <p className="text-[10px] text-slate-400 italic line-clamp-1">
                      "{custom.notes}"
                    </p>
                  )}

                  {/* Action Button */}
                  {onApplyCustomPattern && (
                    <button
                      onClick={() => onApplyCustomPattern(custom.points, custom.name)}
                      className="w-full flex items-center justify-center gap-1.5 py-1.5 bg-cyan-950/60 hover:bg-cyan-900/80 text-cyan-300 border border-cyan-700/50 rounded-lg text-[11px] font-semibold transition-all cursor-pointer active:scale-98"
                    >
                      <Play className="w-3 h-3 text-emerald-400" />
                      <span>جستجوی این الگو در میان فایل‌های نمادها</span>
                    </button>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center p-8 text-center gap-2" style={{ color: theme.colors.textMuted }}>
              <p className="text-xs">
                {customMatches.length === 0
                  ? isPersian
                    ? "هنوز الگوی مشابهی با این روند در کتابخانه شخصی شما ثبت نشده یا شباهت کمتر از حد آستانه است. می‌توانید از بخش تنظیمات > «تشخیص و ثبت الگو از تصویر» الگوی جدید اضافه کنید."
                    : "No matching patterns found in your saved library yet."
                  : t("noMatchesFilter", "موردی مطابق فیلتر یافت نشد.")}
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};


