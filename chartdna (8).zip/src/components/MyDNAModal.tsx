import React, { useState } from "react";
import {
  Activity,
  X,
  Plus,
  Trash2,
  Check,
  Download,
  Upload,
  Calendar,
  Layers,
  Sparkles,
} from "lucide-react";
import { MyDNAPattern } from "../engine/types";
import { PRESET_PATTERNS } from "../engine/presetPatterns";
import { LanguageCode, getTranslation } from "../i18n/languages";
import { ThemeId, getTheme } from "../theme/themes";

interface MyDNAModalProps {
  isOpen: boolean;
  onClose: () => void;
  savedPatterns: MyDNAPattern[];
  onApplyPattern: (pattern: number[], name: string) => void;
  onDeletePattern: (id: string) => void;
  onImportLibrary: (patterns: MyDNAPattern[]) => void;
  activeLanguage: LanguageCode;
  activeTheme?: ThemeId;
}

export const MyDNAModal: React.FC<MyDNAModalProps> = ({
  isOpen,
  onClose,
  savedPatterns,
  onApplyPattern,
  onDeletePattern,
  onImportLibrary,
  activeLanguage,
  activeTheme = "cyber-obsidian",
}) => {
  const [selectedId, setSelectedId] = useState<string | null>(
    savedPatterns[0]?.id || null
  );

  const t = (key: string, fallback?: string) => getTranslation(activeLanguage, key, fallback);
  const theme = getTheme(activeTheme);

  if (!isOpen) return null;

  const activePattern = savedPatterns.find((p) => p.id === selectedId) || savedPatterns[0];

  const handleExportJSON = () => {
    const jsonStr = JSON.stringify(savedPatterns, null, 2);
    const blob = new Blob([jsonStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `chartdna_my_library_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const parsed = JSON.parse(ev.target?.result as string);
        if (Array.isArray(parsed)) {
          onImportLibrary(parsed);
        }
      } catch (err) {
        console.error("Failed to import JSON library", err);
      }
    };
    reader.readAsText(file);
  };

  // Generate SVG path string from 1D points
  const generateSvgPath = (points: number[], width = 280, height = 120) => {
    if (!points || points.length < 2) return "";
    const minVal = Math.min(...points);
    const maxVal = Math.max(...points);
    const span = maxVal - minVal || 1;

    return points
      .map((val, idx) => {
        const x = (idx / (points.length - 1)) * (width - 20) + 10;
        const normY = (val - minVal) / span;
        const y = height - 10 - normY * (height - 20);
        return `${idx === 0 ? "M" : "L"} ${x.toFixed(1)} ${y.toFixed(1)}`;
      })
      .join(" ");
  };

  return (
    <div
      id="my-dna-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-black/80 backdrop-blur-sm"
    >
      <div
        className="border rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden"
        style={{
          backgroundColor: theme.colors.cardBg,
          borderColor: theme.colors.border,
          color: theme.colors.text,
        }}
      >
        {/* Header */}
        <div
          className="border-b px-5 py-3.5 flex items-center justify-between"
          style={{
            backgroundColor: theme.colors.headerBg,
            borderColor: theme.colors.borderSubtle,
          }}
        >
          <div className="flex items-center gap-3">
            <div
              className="w-9 h-9 rounded-xl border flex items-center justify-center"
              style={{
                backgroundColor: `${theme.colors.secondary}20`,
                color: theme.colors.secondary,
                borderColor: `${theme.colors.secondary}40`,
              }}
            >
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold" style={{ color: theme.colors.text }}>
                {t("myDnaLibrary", "My DNA Patterns Library")}
              </h2>
              <p className="text-xs" style={{ color: theme.colors.textMuted }}>
                {t("myDnaDesc", "Saved algorithmic signatures, extracted geometries, and custom user patterns")}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg border transition-colors cursor-pointer"
            style={{
              backgroundColor: theme.colors.subpanelBg,
              borderColor: theme.colors.borderSubtle,
              color: theme.colors.textMuted,
            }}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 flex-1 overflow-y-auto flex flex-col md:flex-row gap-5 text-xs">
          {/* Left: Pattern List */}
          <div className="w-full md:w-80 flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <span className="font-semibold" style={{ color: theme.colors.text }}>
                {t("storedPatterns", "Stored Patterns:")} ({savedPatterns.length})
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleExportJSON}
                  className="p-1.5 rounded border transition-colors cursor-pointer"
                  style={{
                    backgroundColor: theme.colors.subpanelBg,
                    borderColor: theme.colors.borderSubtle,
                    color: theme.colors.textMuted,
                  }}
                  title="Export library as JSON"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
                <label
                  className="p-1.5 rounded border transition-colors cursor-pointer flex items-center justify-center"
                  style={{
                    backgroundColor: theme.colors.subpanelBg,
                    borderColor: theme.colors.borderSubtle,
                    color: theme.colors.textMuted,
                  }}
                  title="Import JSON library"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <input
                    type="file"
                    accept=".json"
                    className="hidden"
                    onChange={handleImportJSON}
                  />
                </label>
              </div>
            </div>

            <div className="flex-1 max-h-[360px] overflow-y-auto flex flex-col gap-2 pr-1">
              {savedPatterns.map((p) => {
                const isSelected = selectedId === p.id;
                return (
                  <div
                    key={p.id}
                    onClick={() => setSelectedId(p.id)}
                    className="p-3 rounded-xl border transition-all cursor-pointer flex flex-col gap-1.5"
                    style={{
                      backgroundColor: isSelected
                        ? `${theme.colors.primary}20`
                        : theme.colors.subpanelBg,
                      borderColor: isSelected
                        ? theme.colors.primary
                        : theme.colors.borderSubtle,
                    }}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-xs" style={{ color: isSelected ? theme.colors.primary : theme.colors.text }}>
                        {p.name}
                      </span>
                      <span
                        className="text-[10px] px-1.5 py-0.5 rounded border"
                        style={{
                          backgroundColor: `${theme.colors.secondary}15`,
                          borderColor: `${theme.colors.secondary}30`,
                          color: theme.colors.secondary,
                        }}
                      >
                        {p.category || "General"}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[10px]" style={{ color: theme.colors.textMuted }}>
                      <span className="flex items-center gap-1 font-mono">
                        <Calendar className="w-3 h-3 opacity-60" />
                        {p.createdAt || "2024"}
                      </span>
                      <span className="font-mono">{p.points?.length || 80} pts</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right: Detailed Inspection & Waveform */}
          <div
            className="flex-1 flex flex-col gap-4 border rounded-xl p-4"
            style={{
              backgroundColor: theme.colors.subpanelBg,
              borderColor: theme.colors.borderSubtle,
            }}
          >
            {activePattern ? (
              <>
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-bold flex items-center gap-2" style={{ color: theme.colors.text }}>
                      <span>{activePattern.name}</span>
                      <span
                        className="text-[10px] font-normal px-2 py-0.5 rounded border"
                        style={{
                          backgroundColor: `${theme.colors.primary}15`,
                          borderColor: `${theme.colors.primary}30`,
                          color: theme.colors.primary,
                        }}
                      >
                        {activePattern.category || "Custom DNA"}
                      </span>
                    </h3>
                    <p className="text-xs mt-0.5" style={{ color: theme.colors.textMuted }}>
                      {activePattern.notes || "Mathematical curve pattern signature"}
                    </p>
                  </div>

                  <button
                    onClick={() => onDeletePattern(activePattern.id)}
                    className="p-1.5 rounded-lg border transition-colors cursor-pointer hover:bg-rose-950/40 hover:text-rose-400"
                    style={{
                      backgroundColor: theme.colors.cardBg,
                      borderColor: theme.colors.borderSubtle,
                      color: theme.colors.textMuted,
                    }}
                    title="Delete pattern from library"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                {/* SVG Visualizer */}
                <div
                  className="h-44 border rounded-xl flex items-center justify-center p-3 relative overflow-hidden"
                  style={{
                    backgroundColor: theme.colors.cardBg,
                    borderColor: theme.colors.borderSubtle,
                  }}
                >
                  <svg className="w-full h-full" viewBox="0 0 280 120" preserveAspectRatio="none">
                    <path
                      d={generateSvgPath(activePattern.points, 280, 120)}
                      fill="none"
                      stroke={theme.colors.secondary}
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </div>

                {/* Apply Button */}
                <div
                  className="flex items-center justify-end gap-3 mt-auto pt-3 border-t"
                  style={{ borderColor: theme.colors.borderSubtle }}
                >
                  <button
                    onClick={() => {
                      onApplyPattern(activePattern.points, activePattern.name);
                      onClose();
                    }}
                    className="flex items-center gap-2 px-5 py-2.5 font-bold text-xs rounded-xl shadow-lg transition-all cursor-pointer active:scale-[0.98]"
                    style={{
                      backgroundColor: theme.colors.primary,
                      color: theme.colors.primaryText,
                    }}
                  >
                    <Check className="w-4 h-4" />
                    <span>{t("applyAsReference", "Apply as Active Search DNA")}</span>
                  </button>
                </div>
              </>
            ) : (
              <div className="flex flex-col items-center justify-center h-full gap-2" style={{ color: theme.colors.textMuted }}>
                <Layers className="w-8 h-8 opacity-40" />
                <p>{t("noPatternSelected", "No pattern selected")}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

