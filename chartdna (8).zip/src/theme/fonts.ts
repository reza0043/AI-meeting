export type FontId =
  | "vazirmatn"
  | "ibm-plex"
  | "noto-sans"
  | "rubik"
  | "sahel"
  | "shabnam"
  | "jetbrains"
  | "inter"
  | "system";

export interface FontDefinition {
  id: FontId;
  name: {
    fa: string;
    en: string;
  };
  fontFamily: string;
  preview: string;
  category: "persian" | "latin" | "mono";
}

export const FONTS: FontDefinition[] = [
  {
    id: "vazirmatn",
    name: { fa: "وزیرمتن (پیش‌فرض)", en: "Vazirmatn (Default)" },
    fontFamily: "'Vazirmatn', system-ui, -apple-system, sans-serif",
    preview: "نمونه متن - Sample 123",
    category: "persian",
  },
  {
    id: "ibm-plex",
    name: { fa: "آی‌بی‌ام پلکس (IBM Plex)", en: "IBM Plex Arabic" },
    fontFamily: "'IBM Plex Sans Arabic', 'Vazirmatn', sans-serif",
    preview: "طراحی شیک سازمانی",
    category: "persian",
  },
  {
    id: "noto-sans",
    name: { fa: "نوتو سنس (Noto Sans)", en: "Noto Sans Arabic" },
    fontFamily: "'Noto Sans Arabic', 'Vazirmatn', sans-serif",
    preview: "خوانایی استاندارد بالا",
    category: "persian",
  },
  {
    id: "rubik",
    name: { fa: "روبیک مدرن (Rubik)", en: "Rubik Persian" },
    fontFamily: "'Rubik', 'Vazirmatn', sans-serif",
    preview: "لبه‌های نرم و گرد",
    category: "persian",
  },
  {
    id: "sahel",
    name: { fa: "ساحل (Sahel)", en: "Sahel" },
    fontFamily: "'Sahel', 'Vazirmatn', sans-serif",
    preview: "ساحل زیبا و خوانا",
    category: "persian",
  },
  {
    id: "shabnam",
    name: { fa: "شبنم (Shabnam)", en: "Shabnam" },
    fontFamily: "'Shabnam', 'Vazirmatn', sans-serif",
    preview: "شبنم تمیز و مهندسی",
    category: "persian",
  },
  {
    id: "jetbrains",
    name: { fa: "جت‌برینز مونو (تریدینگ)", en: "JetBrains Mono (Coding)" },
    fontFamily: "'JetBrains Mono', 'Fira Code', monospace",
    preview: "123.45 DTW & RSI [PRO]",
    category: "mono",
  },
  {
    id: "inter",
    name: { fa: "اینتر (Inter Global)", en: "Inter Global" },
    fontFamily: "'Inter', system-ui, -apple-system, sans-serif",
    preview: "Clean International UI",
    category: "latin",
  },
  {
    id: "system",
    name: { fa: "فونت سیستم (System UI)", en: "System UI" },
    fontFamily: "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Tahoma, sans-serif",
    preview: "فونت پیش‌فرض سیستم",
    category: "latin",
  },
];

const FONT_STORAGE_KEY = "chartdna_active_font";

export function loadSavedFont(): FontId {
  try {
    const saved = localStorage.getItem(FONT_STORAGE_KEY) as FontId;
    if (saved && FONTS.some((f) => f.id === saved)) {
      return saved;
    }
  } catch (e) {
    console.warn("Could not load font from storage", e);
  }
  return "vazirmatn";
}

export function saveFont(fontId: FontId): void {
  try {
    localStorage.setItem(FONT_STORAGE_KEY, fontId);
  } catch (e) {
    console.warn("Could not save font to storage", e);
  }
}

export function applyFontToDocument(fontId: FontId): void {
  const font = FONTS.find((f) => f.id === fontId) || FONTS[0];
  document.documentElement.style.setProperty("--app-font-family", font.fontFamily);
  document.body.style.fontFamily = font.fontFamily;
}
