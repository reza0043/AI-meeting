# -*- mode: python ; coding: utf-8 -*-
# فایل ساخت exe برای برنامه Chart DNA (نسخه اصلی، رابط گرافیکی Tkinter)
#
# مهم: این فایل را همیشه دقیقاً با این دستور بسازید:
#     python -m PyInstaller --noconfirm app.spec
# هرگز دستور «pyinstaller app.py» را مستقیم اجرا نکنید؛ آن دستور این
# فایل spec سفارشی (شامل آیکون، assets، و timeframe_builder.exe) را
# با یک نسخه‌ی پیش‌فرض و ناقص جایگزین می‌کند.
#
# خروجی این spec به‌صورت "onedir" است؛ یعنی نتیجه‌ی نهایی یک پوشه به
# نام dist\ChartDNA است که app.exe و تمام فایل‌های لازم داخل آن قرار
# دارند. این پوشه باید کامل (بدون جدا کردن هیچ فایلی) برای دوستتان
# ارسال شود.

a = Analysis(
    ['app.py'],
    pathex=[],
    binaries=[('dist/timeframe_builder.exe', '.')],
    datas=[
        ('assets', 'assets'),
        ('app_settings.json', '.'),
        ('chart_dna_settings.json', '.'),
    ],
    hiddenimports=[
        'PIL._tkinter_finder',
        'matplotlib.backends.backend_tkagg',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='app',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['assets/app_icon.ico'],
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='ChartDNA',
)
